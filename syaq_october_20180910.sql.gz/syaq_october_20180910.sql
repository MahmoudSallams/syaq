-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 13, 2018 at 01:39 PM
-- Server version: 5.7.24-0ubuntu0.16.04.1
-- PHP Version: 7.0.32-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `syaq_october_20180910`
--

-- --------------------------------------------------------

--
-- Table structure for table `backend_access_log`
--

CREATE TABLE `backend_access_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backend_access_log`
--

INSERT INTO `backend_access_log` (`id`, `user_id`, `ip_address`, `created_at`, `updated_at`) VALUES
(41, 1, '41.234.217.38', '2018-09-09 18:58:02', '2018-09-09 18:58:02'),
(42, 1, '41.234.217.38', '2018-09-09 19:03:11', '2018-09-09 19:03:11'),
(43, 1, '41.235.106.132', '2018-09-10 11:16:28', '2018-09-10 11:16:28'),
(44, 1, '41.235.106.132', '2018-09-10 11:17:34', '2018-09-10 11:17:34'),
(45, 1, '41.235.106.132', '2018-09-10 11:18:34', '2018-09-10 11:18:34'),
(46, 5, '41.235.106.132', '2018-09-10 11:49:58', '2018-09-10 11:49:58'),
(47, 1, '41.235.106.132', '2018-09-10 12:53:40', '2018-09-10 12:53:40');

-- --------------------------------------------------------

--
-- Table structure for table `backend_users`
--

CREATE TABLE `backend_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activation_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `persist_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_password_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `is_activated` tinyint(1) NOT NULL DEFAULT '0',
  `role_id` int(10) UNSIGNED DEFAULT NULL,
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backend_users`
--

INSERT INTO `backend_users` (`id`, `first_name`, `last_name`, `login`, `email`, `password`, `activation_code`, `persist_code`, `reset_password_code`, `permissions`, `is_activated`, `role_id`, `activated_at`, `last_login`, `created_at`, `updated_at`, `is_superuser`) VALUES
(1, 'Mostafa', 'El-Gazzar', 'admin', 'mostafa@worcbox.com', '$2y$10$jP9Cs9hJ1zBXxUyRSQjCbuKZAPUMGZ3nal2GsIEiXqeODivFD47bq', NULL, '$2y$10$xxT9J3oZBl.1qcDk03iYn.q62/gihe1jLNnkhND38Lkm8RkSfWFCe', NULL, '', 1, 2, NULL, '2018-09-10 12:53:39', '2018-08-14 08:42:05', '2018-09-10 12:53:39', 1),
(2, 'mm', 'mm', 'mmmm', 'mmm@mmm.mmm', '$2y$10$meMcNFRaDz1ZHcJe9uHn8uqT38G1MHMGTuBbc7Bd2dgCHuTl48XSG', NULL, NULL, NULL, '', 0, 4, NULL, '2018-09-06 11:49:29', '2018-09-03 10:52:31', '2018-09-06 11:54:59', 0),
(3, 'Aly', 'El-Degwy', 'reviewer', 'aly@mailinator.com', '$2y$10$0ik/6O/R9jQlD0qPft6iMuPBJBkW98bwNksUugXnyrkWr7k0QVH6S', NULL, NULL, NULL, '', 0, 5, NULL, '2018-09-09 12:21:18', '2018-09-05 11:28:56', '2018-09-09 18:59:13', 0),
(4, 'Mostafa', 'El-Gazzar', 'implementer', 'mostafa@mailinator.com', '$2y$10$PqfwMIyof4U1psSgZeKq1ugtTxwhwqhu.8t48cG1rprjMwCQCQOkG', NULL, '$2y$10$j2KGzLlNOZGq80W3mws2nuYhXb/xi01d9LaG59f5i1Hxab3Q1fDSu', NULL, '', 0, 4, NULL, '2018-09-09 16:39:38', '2018-09-05 11:29:33', '2018-09-09 18:59:01', 0),
(5, 'Sally', 'Mohamed', 'manager', 'manager@mailinator.com', '$2y$10$9XA5slAS80L33cSyYjAlnua1smvVdirsxxMOl.Igsnz0EDHfdmg1.', NULL, '$2y$10$vIT5rDSrU0zX/R8M97SR1OhnaZ0Fjm21ihuSPKspJE.UvHRQuCgTm', NULL, '', 0, 6, NULL, '2018-09-10 11:49:58', '2018-09-06 11:54:51', '2018-09-10 11:49:58', 0);

-- --------------------------------------------------------

--
-- Table structure for table `backend_users_groups`
--

CREATE TABLE `backend_users_groups` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `user_group_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backend_users_groups`
--

INSERT INTO `backend_users_groups` (`user_id`, `user_group_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `backend_user_groups`
--

CREATE TABLE `backend_user_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_new_user_default` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backend_user_groups`
--

INSERT INTO `backend_user_groups` (`id`, `name`, `created_at`, `updated_at`, `code`, `description`, `is_new_user_default`) VALUES
(1, 'Owners', '2018-08-14 08:42:04', '2018-08-14 08:42:04', 'owners', 'Default group for website owners.', 0);

-- --------------------------------------------------------

--
-- Table structure for table `backend_user_preferences`
--

CREATE TABLE `backend_user_preferences` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `namespace` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backend_user_preferences`
--

INSERT INTO `backend_user_preferences` (`id`, `user_id`, `namespace`, `group`, `item`, `value`) VALUES
(1, 1, 'backend', 'backend', 'preferences', '{\"locale\":\"en\",\"fallback_locale\":\"en\",\"timezone\":\"UTC\",\"editor_font_size\":\"16\",\"editor_word_wrap\":\"fluid\",\"editor_code_folding\":\"markbeginend\",\"editor_tab_size\":\"4\",\"editor_theme\":\"chrome\",\"editor_show_invisibles\":\"0\",\"editor_highlight_active_line\":\"1\",\"editor_use_hard_tabs\":\"1\",\"editor_show_gutter\":\"1\",\"editor_auto_closing\":\"1\",\"editor_autocompletion\":\"live\",\"editor_enable_snippets\":\"0\",\"editor_display_indent_guides\":\"0\",\"editor_show_print_margin\":\"0\",\"user_id\":\"1\"}'),
(2, 1, 'backend', 'reportwidgets', 'dashboard', '{\"welcome\":{\"class\":\"Backend\\\\ReportWidgets\\\\Welcome\",\"sortOrder\":50,\"configuration\":{\"ocWidgetWidth\":6}},\"systemStatus\":{\"class\":\"System\\\\ReportWidgets\\\\Status\",\"sortOrder\":60,\"configuration\":{\"ocWidgetWidth\":6}},\"activeTheme\":{\"class\":\"Cms\\\\ReportWidgets\\\\ActiveTheme\",\"sortOrder\":70,\"configuration\":{\"title\":\"Website\",\"ocWidgetWidth\":4,\"ocWidgetNewRow\":null}}}');

-- --------------------------------------------------------

--
-- Table structure for table `backend_user_roles`
--

CREATE TABLE `backend_user_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `is_system` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backend_user_roles`
--

INSERT INTO `backend_user_roles` (`id`, `name`, `code`, `description`, `permissions`, `is_system`, `created_at`, `updated_at`) VALUES
(1, 'Publisher', 'publisher', 'Site editor with access to publishing tools.', '', 1, '2018-08-14 08:42:04', '2018-08-14 08:42:04'),
(2, 'Developer', 'developer', 'Site administrator with access to developer tools.', '', 1, '2018-08-14 08:42:04', '2018-08-14 08:42:04'),
(3, 'mmmm', 'mmm', '', '{\"rainlab.pages.manage_pages\":\"1\",\"rainlab.pages.manage_menus\":\"1\",\"rainlab.pages.access_snippets\":\"1\",\"rainlab.pages.manage_content\":\"1\",\"worcbox.feature.list\":\"1\",\"worcbox.syaq.orders.implementer\":\"1\",\"worcbox.syaq.orders.edit\":\"1\"}', 0, '2018-09-03 10:51:51', '2018-09-04 08:19:50'),
(4, 'Implementer', 'orders-implementer', '', '{\"worcbox.syaq.orders.implementer\":\"1\",\"worcbox.syaq.orders.createAttachment\":\"1\"}', 0, '2018-09-04 07:15:56', '2018-09-06 11:24:35'),
(5, 'Reveiewer', 'reviewer', '', '{\"worcbox.syaq.orders.implementer\":\"1\",\"worcbox.syaq.orders.edit\":\"1\",\"worcbox.syaq.orders.addAttachmentNote\":\"1\"}', 0, '2018-09-05 11:26:14', '2018-09-06 11:25:01'),
(6, 'Content Manager', 'content-manager', '', '{\"worcbox.syaq.orders.implementer\":\"1\",\"worcbox.syaq.orders.edit\":\"1\",\"worcbox.syaq.orders.createAttachment\":\"1\",\"worcbox.syaq.orders.addAttachmentNote\":\"1\"}', 0, '2018-09-06 11:53:52', '2018-09-06 11:53:52');

-- --------------------------------------------------------

--
-- Table structure for table `backend_user_throttle`
--

CREATE TABLE `backend_user_throttle` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `is_suspended` tinyint(1) NOT NULL DEFAULT '0',
  `suspended_at` timestamp NULL DEFAULT NULL,
  `is_banned` tinyint(1) NOT NULL DEFAULT '0',
  `banned_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backend_user_throttle`
--

INSERT INTO `backend_user_throttle` (`id`, `user_id`, `ip_address`, `attempts`, `last_attempt_at`, `is_suspended`, `suspended_at`, `is_banned`, `banned_at`) VALUES
(15, 1, '41.234.217.38', 0, NULL, 0, NULL, 0, NULL),
(16, 1, '41.235.106.132', 0, NULL, 0, NULL, 0, NULL),
(17, 5, '41.235.106.132', 0, NULL, 0, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_theme_data`
--

CREATE TABLE `cms_theme_data` (
  `id` int(10) UNSIGNED NOT NULL,
  `theme` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_theme_logs`
--

CREATE TABLE `cms_theme_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `theme` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `old_content` longtext COLLATE utf8mb4_unicode_ci,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deferred_bindings`
--

CREATE TABLE `deferred_bindings` (
  `id` int(10) UNSIGNED NOT NULL,
  `master_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `master_field` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slave_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slave_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_bind` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `deferred_bindings`
--

INSERT INTO `deferred_bindings` (`id`, `master_type`, `master_field`, `slave_type`, `slave_id`, `session_key`, `is_bind`, `created_at`, `updated_at`) VALUES
(3, 'Worcbox\\Features\\Models\\Item', 'icon', 'System\\Models\\File', '3', '9cTRe5hdwZxDkdklB6cucDwfHOiP9pK67arnEfdH', 1, '2018-09-02 11:39:10', '2018-09-02 11:39:10'),
(4, 'Worcbox\\Features\\Models\\Item', 'icon', 'System\\Models\\File', '4', 'prkSOnpntY573AV0iYyyCdzP6WJoyPJ206VDwdKx', 1, '2018-09-02 11:41:46', '2018-09-02 11:41:46');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` int(10) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci,
  `failed_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `flynsarmy_sociallogin_user_providers`
--

CREATE TABLE `flynsarmy_sociallogin_user_providers` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `provider_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `provider_token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rainlab_user_mail_blockers`
--

CREATE TABLE `rainlab_user_mail_blockers` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci,
  `last_activity` int(11) DEFAULT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_event_logs`
--

CREATE TABLE `system_event_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `level` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `details` mediumtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_event_logs`
--

INSERT INTO `system_event_logs` (`id`, `level`, `message`, `details`, `created_at`, `updated_at`) VALUES
(362, 'error', 'ErrorException: file_put_contents(/var/www/html/workspace/syaq/storage/framework/cache/b6/f7/b6f78000ec2b2a34f2953146429c2c95c25347bf): failed to open stream: No such file or directory in /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Filesystem/Filesystem.php:122\nStack trace:\n#0 [internal function]: Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(2, \'file_put_conten...\', \'/var/www/html/w...\', 122, Array)\n#1 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Filesystem/Filesystem.php(122): file_put_contents(\'/var/www/html/w...\', \'1536519544a:1:{...\', 2)\n#2 /var/www/html/workspace/syaq/vendor/october/rain/src/Filesystem/Filesystem.php(220): Illuminate\\Filesystem\\Filesystem->put(\'/var/www/html/w...\', \'1536519544a:1:{...\', true)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cache/FileStore.php(65): October\\Rain\\Filesystem\\Filesystem->put(\'/var/www/html/w...\', \'1536519544a:1:{...\', true)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cache/Repository.php(195): Illuminate\\Cache\\FileStore->put(\'pages3557801717\', Array, 10)\n#5 /var/www/html/workspace/syaq/vendor/october/rain/src/Halcyon/MemoryRepository.php(61): Illuminate\\Cache\\Repository->put(\'pages3557801717\', Array, 10)\n#6 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cache/Repository.php(327): October\\Rain\\Halcyon\\MemoryRepository->put(\'pages3557801717\', Array, 10)\n#7 /var/www/html/workspace/syaq/vendor/october/rain/src/Halcyon/Builder.php(644): Illuminate\\Cache\\Repository->remember(\'pages3557801717\', 10, Object(Closure))\n#8 /var/www/html/workspace/syaq/vendor/october/rain/src/Halcyon/Builder.php(250): October\\Rain\\Halcyon\\Builder->getCached(Array)\n#9 /var/www/html/workspace/syaq/vendor/october/rain/src/Halcyon/Builder.php(238): October\\Rain\\Halcyon\\Builder->get()\n#10 /var/www/html/workspace/syaq/vendor/october/rain/src/Halcyon/Builder.php(228): October\\Rain\\Halcyon\\Builder->first()\n#11 /var/www/html/workspace/syaq/modules/cms/classes/CmsObject.php(121): October\\Rain\\Halcyon\\Builder->find(\'request.htm\')\n#12 /var/www/html/workspace/syaq/modules/cms/classes/CmsObject.php(144): Cms\\Classes\\CmsObject::loadCached(Object(Cms\\Classes\\Theme), \'request.htm\')\n#13 /var/www/html/workspace/syaq/modules/cms/classes/Theme.php(128): Cms\\Classes\\CmsObject::listInTheme(Object(Cms\\Classes\\Theme), false)\n#14 /var/www/html/workspace/syaq/modules/cms/classes/Router.php(232): Cms\\Classes\\Theme->listPages()\n#15 /var/www/html/workspace/syaq/modules/cms/classes/Router.php(203): Cms\\Classes\\Router->loadUrlMap()\n#16 /var/www/html/workspace/syaq/modules/cms/classes/Router.php(184): Cms\\Classes\\Router->getUrlMap()\n#17 /var/www/html/workspace/syaq/modules/cms/classes/Router.php(104): Cms\\Classes\\Router->getRouterObject()\n#18 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(158): Cms\\Classes\\Router->findByUrl(\'/\')\n#19 /var/www/html/workspace/syaq/modules/cms/classes/CmsController.php(50): Cms\\Classes\\Controller->run(\'/\')\n#20 [internal function]: Cms\\Classes\\CmsController->run(\'/\')\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Controller.php(54): call_user_func_array(Array, Array)\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction(\'run\', Array)\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch(Object(Illuminate\\Routing\\Route), Object(Cms\\Classes\\CmsController), \'run\')\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Route.php(169): Illuminate\\Routing\\Route->runController()\n#25 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(658): Illuminate\\Routing\\Route->run()\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#28 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#31 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#32 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#33 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#34 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#35 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#36 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#37 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#38 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#39 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#40 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#41 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#42 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#43 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#44 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#45 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#46 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#47 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#48 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#49 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#50 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#51 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#52 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#53 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#54 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#55 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#56 {main}', NULL, '2018-09-09 18:49:04', '2018-09-09 18:49:04'),
(363, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(ErrorException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(ErrorException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(ErrorException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(ErrorException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(ErrorException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(32): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(ErrorException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#28 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#31 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#32 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#33 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#34 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#35 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#36 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#37 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#38 {main}', NULL, '2018-09-09 18:49:04', '2018-09-09 18:49:04'),
(364, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#25 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#28 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#31 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#32 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#33 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#34 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#35 {main}', NULL, '2018-09-09 18:49:04', '2018-09-09 18:49:04'),
(365, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#22 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#28 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#31 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#32 {main}', NULL, '2018-09-09 18:49:04', '2018-09-09 18:49:04'),
(366, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#19 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#28 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#29 {main}', NULL, '2018-09-09 18:49:04', '2018-09-09 18:49:04'),
(367, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#16 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#26 {main}', NULL, '2018-09-09 18:49:04', '2018-09-09 18:49:04'),
(368, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#13 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#23 {main}', NULL, '2018-09-09 18:49:04', '2018-09-09 18:49:04');
INSERT INTO `system_event_logs` (`id`, `level`, `message`, `details`, `created_at`, `updated_at`) VALUES
(369, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(32): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#16 {main}', NULL, '2018-09-09 18:49:04', '2018-09-09 18:49:04'),
(370, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#13 {main}', NULL, '2018-09-09 18:49:05', '2018-09-09 18:49:05'),
(371, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(314): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(118): Illuminate\\Foundation\\Http\\Kernel->reportException(Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#10 {main}', NULL, '2018-09-09 18:49:05', '2018-09-09 18:49:05'),
(372, 'error', 'ErrorException: file_put_contents(/var/www/html/workspace/syaq/storage/framework/cache/76/6b/766b2d4dbabfe03aa448094c380aae3b4e252fd1): failed to open stream: No such file or directory in /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Filesystem/Filesystem.php:122\nStack trace:\n#0 [internal function]: Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(2, \'file_put_conten...\', \'/var/www/html/w...\', 122, Array)\n#1 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Filesystem/Filesystem.php(122): file_put_contents(\'/var/www/html/w...\', \'1536519969a:1:{...\', 2)\n#2 /var/www/html/workspace/syaq/vendor/october/rain/src/Filesystem/Filesystem.php(220): Illuminate\\Filesystem\\Filesystem->put(\'/var/www/html/w...\', \'1536519969a:1:{...\', true)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cache/FileStore.php(65): October\\Rain\\Filesystem\\Filesystem->put(\'/var/www/html/w...\', \'1536519969a:1:{...\', true)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cache/Repository.php(195): Illuminate\\Cache\\FileStore->put(\'content/static-...\', Array, 10)\n#5 /var/www/html/workspace/syaq/vendor/october/rain/src/Halcyon/MemoryRepository.php(61): Illuminate\\Cache\\Repository->put(\'content/static-...\', Array, 10)\n#6 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cache/Repository.php(327): October\\Rain\\Halcyon\\MemoryRepository->put(\'content/static-...\', Array, 10)\n#7 /var/www/html/workspace/syaq/vendor/october/rain/src/Halcyon/Builder.php(644): Illuminate\\Cache\\Repository->remember(\'content/static-...\', 10, Object(Closure))\n#8 /var/www/html/workspace/syaq/vendor/october/rain/src/Halcyon/Builder.php(250): October\\Rain\\Halcyon\\Builder->getCached(Array)\n#9 /var/www/html/workspace/syaq/vendor/october/rain/src/Halcyon/Builder.php(238): October\\Rain\\Halcyon\\Builder->get()\n#10 /var/www/html/workspace/syaq/vendor/october/rain/src/Halcyon/Builder.php(228): October\\Rain\\Halcyon\\Builder->first()\n#11 /var/www/html/workspace/syaq/modules/cms/classes/CmsObject.php(121): October\\Rain\\Halcyon\\Builder->find(\'about.htm\')\n#12 /var/www/html/workspace/syaq/modules/cms/classes/CmsObject.php(144): Cms\\Classes\\CmsObject::loadCached(Object(Cms\\Classes\\Theme), \'about.htm\')\n#13 /var/www/html/workspace/syaq/plugins/rainlab/pages/classes/PageList.php(40): Cms\\Classes\\CmsObject::listInTheme(Object(Cms\\Classes\\Theme), false)\n#14 /var/www/html/workspace/syaq/plugins/rainlab/pages/classes/Router.php(112): RainLab\\Pages\\Classes\\PageList->listPages()\n#15 /var/www/html/workspace/syaq/plugins/rainlab/pages/classes/Router.php(86): RainLab\\Pages\\Classes\\Router->loadUrlMap()\n#16 /var/www/html/workspace/syaq/plugins/rainlab/pages/classes/Router.php(57): RainLab\\Pages\\Classes\\Router->getUrlMap()\n#17 /var/www/html/workspace/syaq/plugins/rainlab/pages/classes/Controller.php(42): RainLab\\Pages\\Classes\\Router->findByUrl(\'/\')\n#18 /var/www/html/workspace/syaq/plugins/rainlab/pages/Plugin.php(117): RainLab\\Pages\\Classes\\Controller->initCmsPage(\'/\')\n#19 [internal function]: RainLab\\Pages\\Plugin->RainLab\\Pages\\{closure}(\'/\', Object(Cms\\Classes\\Router))\n#20 /var/www/html/workspace/syaq/vendor/october/rain/src/Events/Dispatcher.php(233): call_user_func_array(Object(Closure), Array)\n#21 /var/www/html/workspace/syaq/vendor/october/rain/src/Events/Dispatcher.php(197): October\\Rain\\Events\\Dispatcher->dispatch(\'cms.router.befo...\', Array, true)\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): October\\Rain\\Events\\Dispatcher->fire(\'cms.router.befo...\', Array, true)\n#23 /var/www/html/workspace/syaq/modules/cms/classes/Router.php(83): Illuminate\\Support\\Facades\\Facade::__callStatic(\'fire\', Array)\n#24 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(158): Cms\\Classes\\Router->findByUrl(\'/\')\n#25 /var/www/html/workspace/syaq/modules/cms/classes/CmsController.php(50): Cms\\Classes\\Controller->run(\'/\')\n#26 [internal function]: Cms\\Classes\\CmsController->run(\'/\')\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Controller.php(54): call_user_func_array(Array, Array)\n#28 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction(\'run\', Array)\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch(Object(Illuminate\\Routing\\Route), Object(Cms\\Classes\\CmsController), \'run\')\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Route.php(169): Illuminate\\Routing\\Route->runController()\n#31 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(658): Illuminate\\Routing\\Route->run()\n#32 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#33 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#34 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#35 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#36 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#37 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#38 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#39 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#40 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#41 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#42 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#43 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#44 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#45 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#46 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#47 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#48 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#49 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#50 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#51 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#52 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#53 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#54 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#55 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#56 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#57 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#58 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#59 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#60 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#61 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#62 {main}', NULL, '2018-09-09 18:56:09', '2018-09-09 18:56:09'),
(373, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(ErrorException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(ErrorException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(ErrorException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(ErrorException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(ErrorException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(32): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(ErrorException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#28 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#31 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#32 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#33 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#34 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#35 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#36 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#37 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#38 {main}', NULL, '2018-09-09 18:56:09', '2018-09-09 18:56:09'),
(374, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#25 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#28 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#31 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#32 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#33 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#34 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#35 {main}', NULL, '2018-09-09 18:56:09', '2018-09-09 18:56:09'),
(375, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#22 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#28 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#31 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#32 {main}', NULL, '2018-09-09 18:56:09', '2018-09-09 18:56:09'),
(376, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#19 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#28 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#29 {main}', NULL, '2018-09-09 18:56:09', '2018-09-09 18:56:09');
INSERT INTO `system_event_logs` (`id`, `level`, `message`, `details`, `created_at`, `updated_at`) VALUES
(377, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#16 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#26 {main}', NULL, '2018-09-09 18:56:09', '2018-09-09 18:56:09'),
(378, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#13 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#23 {main}', NULL, '2018-09-09 18:56:09', '2018-09-09 18:56:09'),
(379, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(32): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#16 {main}', NULL, '2018-09-09 18:56:09', '2018-09-09 18:56:09'),
(380, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#13 {main}', NULL, '2018-09-09 18:56:09', '2018-09-09 18:56:09'),
(381, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(314): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(118): Illuminate\\Foundation\\Http\\Kernel->reportException(Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#10 {main}', NULL, '2018-09-09 18:56:09', '2018-09-09 18:56:09'),
(382, 'error', 'ErrorException: file_put_contents(/var/www/html/workspace/syaq/storage/framework/cache/76/6b/766b2d4dbabfe03aa448094c380aae3b4e252fd1): failed to open stream: No such file or directory in /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Filesystem/Filesystem.php:122\nStack trace:\n#0 [internal function]: Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(2, \'file_put_conten...\', \'/var/www/html/w...\', 122, Array)\n#1 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Filesystem/Filesystem.php(122): file_put_contents(\'/var/www/html/w...\', \'1536519979a:1:{...\', 2)\n#2 /var/www/html/workspace/syaq/vendor/october/rain/src/Filesystem/Filesystem.php(220): Illuminate\\Filesystem\\Filesystem->put(\'/var/www/html/w...\', \'1536519979a:1:{...\', true)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cache/FileStore.php(65): October\\Rain\\Filesystem\\Filesystem->put(\'/var/www/html/w...\', \'1536519979a:1:{...\', true)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cache/Repository.php(195): Illuminate\\Cache\\FileStore->put(\'content/static-...\', Array, 10)\n#5 /var/www/html/workspace/syaq/vendor/october/rain/src/Halcyon/MemoryRepository.php(61): Illuminate\\Cache\\Repository->put(\'content/static-...\', Array, 10)\n#6 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cache/Repository.php(327): October\\Rain\\Halcyon\\MemoryRepository->put(\'content/static-...\', Array, 10)\n#7 /var/www/html/workspace/syaq/vendor/october/rain/src/Halcyon/Builder.php(644): Illuminate\\Cache\\Repository->remember(\'content/static-...\', 10, Object(Closure))\n#8 /var/www/html/workspace/syaq/vendor/october/rain/src/Halcyon/Builder.php(250): October\\Rain\\Halcyon\\Builder->getCached(Array)\n#9 /var/www/html/workspace/syaq/vendor/october/rain/src/Halcyon/Builder.php(238): October\\Rain\\Halcyon\\Builder->get()\n#10 /var/www/html/workspace/syaq/vendor/october/rain/src/Halcyon/Builder.php(228): October\\Rain\\Halcyon\\Builder->first()\n#11 /var/www/html/workspace/syaq/modules/cms/classes/CmsObject.php(121): October\\Rain\\Halcyon\\Builder->find(\'about.htm\')\n#12 /var/www/html/workspace/syaq/modules/cms/classes/CmsObject.php(144): Cms\\Classes\\CmsObject::loadCached(Object(Cms\\Classes\\Theme), \'about.htm\')\n#13 /var/www/html/workspace/syaq/plugins/rainlab/pages/classes/PageList.php(40): Cms\\Classes\\CmsObject::listInTheme(Object(Cms\\Classes\\Theme), false)\n#14 /var/www/html/workspace/syaq/plugins/rainlab/pages/classes/Router.php(112): RainLab\\Pages\\Classes\\PageList->listPages()\n#15 /var/www/html/workspace/syaq/plugins/rainlab/pages/classes/Router.php(86): RainLab\\Pages\\Classes\\Router->loadUrlMap()\n#16 /var/www/html/workspace/syaq/plugins/rainlab/pages/classes/Router.php(57): RainLab\\Pages\\Classes\\Router->getUrlMap()\n#17 /var/www/html/workspace/syaq/plugins/rainlab/pages/classes/Controller.php(42): RainLab\\Pages\\Classes\\Router->findByUrl(\'/\')\n#18 /var/www/html/workspace/syaq/plugins/rainlab/pages/Plugin.php(117): RainLab\\Pages\\Classes\\Controller->initCmsPage(\'/\')\n#19 [internal function]: RainLab\\Pages\\Plugin->RainLab\\Pages\\{closure}(\'/\', Object(Cms\\Classes\\Router))\n#20 /var/www/html/workspace/syaq/vendor/october/rain/src/Events/Dispatcher.php(233): call_user_func_array(Object(Closure), Array)\n#21 /var/www/html/workspace/syaq/vendor/october/rain/src/Events/Dispatcher.php(197): October\\Rain\\Events\\Dispatcher->dispatch(\'cms.router.befo...\', Array, true)\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): October\\Rain\\Events\\Dispatcher->fire(\'cms.router.befo...\', Array, true)\n#23 /var/www/html/workspace/syaq/modules/cms/classes/Router.php(83): Illuminate\\Support\\Facades\\Facade::__callStatic(\'fire\', Array)\n#24 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(158): Cms\\Classes\\Router->findByUrl(\'/\')\n#25 /var/www/html/workspace/syaq/modules/cms/classes/CmsController.php(50): Cms\\Classes\\Controller->run(\'/\')\n#26 [internal function]: Cms\\Classes\\CmsController->run(\'/\')\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Controller.php(54): call_user_func_array(Array, Array)\n#28 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction(\'run\', Array)\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch(Object(Illuminate\\Routing\\Route), Object(Cms\\Classes\\CmsController), \'run\')\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Route.php(169): Illuminate\\Routing\\Route->runController()\n#31 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(658): Illuminate\\Routing\\Route->run()\n#32 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#33 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#34 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#35 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#36 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#37 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#38 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#39 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#40 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#41 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#42 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#43 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#44 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#45 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#46 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#47 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#48 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#49 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#50 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#51 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#52 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#53 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#54 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#55 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#56 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#57 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#58 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#59 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#60 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#61 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#62 {main}', NULL, '2018-09-09 18:56:19', '2018-09-09 18:56:19'),
(383, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(ErrorException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(ErrorException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(ErrorException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(ErrorException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(ErrorException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(32): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(ErrorException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#28 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#31 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#32 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#33 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#34 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#35 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#36 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#37 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#38 {main}', NULL, '2018-09-09 18:56:19', '2018-09-09 18:56:19'),
(384, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#25 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#28 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#31 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#32 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#33 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#34 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#35 {main}', NULL, '2018-09-09 18:56:19', '2018-09-09 18:56:19');
INSERT INTO `system_event_logs` (`id`, `level`, `message`, `details`, `created_at`, `updated_at`) VALUES
(385, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#22 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#28 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#31 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#32 {main}', NULL, '2018-09-09 18:56:19', '2018-09-09 18:56:19'),
(386, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#19 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#28 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#29 {main}', NULL, '2018-09-09 18:56:19', '2018-09-09 18:56:19'),
(387, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#16 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#26 {main}', NULL, '2018-09-09 18:56:20', '2018-09-09 18:56:20'),
(388, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#13 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#23 {main}', NULL, '2018-09-09 18:56:20', '2018-09-09 18:56:20'),
(389, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(32): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#16 {main}', NULL, '2018-09-09 18:56:20', '2018-09-09 18:56:20'),
(390, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(81): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(55): Illuminate\\Routing\\Pipeline->handleException(Object(Illuminate\\Http\\Request), Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#13 {main}', NULL, '2018-09-09 18:56:20', '2018-09-09 18:56:20'),
(391, 'error', 'UnexpectedValueException: The stream or file \"/var/www/html/workspace/syaq/storage/logs/system.log\" could not be opened: failed to open stream: Permission denied in /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/StreamHandler.php:107\nStack trace:\n#0 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Handler/AbstractProcessingHandler.php(37): Monolog\\Handler\\StreamHandler->write(Array)\n#1 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(337): Monolog\\Handler\\AbstractProcessingHandler->handle(Array)\n#2 /var/www/html/workspace/syaq/vendor/monolog/monolog/src/Monolog/Logger.php(616): Monolog\\Logger->addRecord(400, Object(UnexpectedValueException), Array)\n#3 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(203): Monolog\\Logger->error(Object(UnexpectedValueException), Array)\n#4 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Log/Writer.php(114): Illuminate\\Log\\Writer->writeLog(\'error\', Object(UnexpectedValueException), Array)\n#5 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Support/Facades/Facade.php(221): Illuminate\\Log\\Writer->error(Object(UnexpectedValueException))\n#6 /var/www/html/workspace/syaq/vendor/october/rain/src/Foundation/Exception/Handler.php(50): Illuminate\\Support\\Facades\\Facade::__callStatic(\'error\', Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(314): October\\Rain\\Foundation\\Exception\\Handler->report(Object(UnexpectedValueException))\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(118): Illuminate\\Foundation\\Http\\Kernel->reportException(Object(UnexpectedValueException))\n#9 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#10 {main}', NULL, '2018-09-09 18:56:20', '2018-09-09 18:56:20'),
(392, 'error', 'ErrorException: Trying to get property of non-object in /var/www/html/workspace/syaq/modules/cms/classes/CodeParser.php(293) : eval()\'d code:7\nStack trace:\n#0 /var/www/html/workspace/syaq/modules/cms/classes/CodeParser.php(293) : eval()\'d code(7): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(8, \'Trying to get p...\', \'/var/www/html/w...\', 7, Array)\n#1 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(426): Cms5b9574350a70f100759868_9dc13e55d62911cb28faaeaf6092149dClass->onStart()\n#2 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(348): Cms\\Classes\\Controller->execPageCycle()\n#3 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(211): Cms\\Classes\\Controller->runPage(Object(Cms\\Classes\\Page))\n#4 /var/www/html/workspace/syaq/modules/cms/classes/CmsController.php(50): Cms\\Classes\\Controller->run(\'running-orders\')\n#5 [internal function]: Cms\\Classes\\CmsController->run(\'running-orders\')\n#6 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Controller.php(54): call_user_func_array(Array, Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction(\'run\', Array)\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch(Object(Illuminate\\Routing\\Route), Object(Cms\\Classes\\CmsController), \'run\')\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Route.php(169): Illuminate\\Routing\\Route->runController()\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(658): Illuminate\\Routing\\Route->run()\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#28 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#31 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#32 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#33 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#34 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#35 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#36 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#37 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#38 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#39 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#40 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#41 {main}', NULL, '2018-09-09 19:27:49', '2018-09-09 19:27:49'),
(393, 'error', 'ErrorException: Trying to get property of non-object in /var/www/html/workspace/syaq/modules/cms/classes/CodeParser.php(293) : eval()\'d code:7\nStack trace:\n#0 /var/www/html/workspace/syaq/modules/cms/classes/CodeParser.php(293) : eval()\'d code(7): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(8, \'Trying to get p...\', \'/var/www/html/w...\', 7, Array)\n#1 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(426): Cms5b95749831407360925154_741ed10e32299b8b6d9d19b4b0d932ffClass->onStart()\n#2 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(348): Cms\\Classes\\Controller->execPageCycle()\n#3 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(211): Cms\\Classes\\Controller->runPage(Object(Cms\\Classes\\Page))\n#4 /var/www/html/workspace/syaq/modules/cms/classes/CmsController.php(50): Cms\\Classes\\Controller->run(\'finished-orders\')\n#5 [internal function]: Cms\\Classes\\CmsController->run(\'finished-orders\')\n#6 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Controller.php(54): call_user_func_array(Array, Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction(\'run\', Array)\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch(Object(Illuminate\\Routing\\Route), Object(Cms\\Classes\\CmsController), \'run\')\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Route.php(169): Illuminate\\Routing\\Route->runController()\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(658): Illuminate\\Routing\\Route->run()\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#28 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#31 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#32 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#33 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#34 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#35 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#36 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#37 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#38 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#39 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#40 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#41 {main}', NULL, '2018-09-09 19:29:28', '2018-09-09 19:29:28');
INSERT INTO `system_event_logs` (`id`, `level`, `message`, `details`, `created_at`, `updated_at`) VALUES
(394, 'error', 'ErrorException: Trying to get property of non-object in /var/www/html/workspace/syaq/storage/cms/cache/51/00/account.htm.php:27\nStack trace:\n#0 /var/www/html/workspace/syaq/storage/cms/cache/51/00/account.htm.php(27): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(8, \'Trying to get p...\', \'/var/www/html/w...\', 27, Array)\n#1 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(731): Cms5b9573e1597da153479061_bcb03b0fdb8cc3b92dca47d9bc740543Class->onSubmit()\n#2 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(623): Cms\\Classes\\Controller->runAjaxHandler(\'onSubmit\')\n#3 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(328): Cms\\Classes\\Controller->execAjaxHandlers()\n#4 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(211): Cms\\Classes\\Controller->runPage(Object(Cms\\Classes\\Page))\n#5 /var/www/html/workspace/syaq/modules/cms/classes/CmsController.php(50): Cms\\Classes\\Controller->run(\'account\')\n#6 [internal function]: Cms\\Classes\\CmsController->run(\'account\')\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Controller.php(54): call_user_func_array(Array, Array)\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction(\'run\', Array)\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch(Object(Illuminate\\Routing\\Route), Object(Cms\\Classes\\CmsController), \'run\')\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Route.php(169): Illuminate\\Routing\\Route->runController()\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(658): Illuminate\\Routing\\Route->run()\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#28 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#31 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#32 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#33 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#34 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#35 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#36 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#37 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#38 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#39 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#40 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#41 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#42 {main}', NULL, '2018-09-09 19:36:12', '2018-09-09 19:36:12'),
(395, 'error', 'ErrorException: Trying to get property of non-object in /var/www/html/workspace/syaq/storage/cms/cache/51/00/account.htm.php:27\nStack trace:\n#0 /var/www/html/workspace/syaq/storage/cms/cache/51/00/account.htm.php(27): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(8, \'Trying to get p...\', \'/var/www/html/w...\', 27, Array)\n#1 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(731): Cms5b9573e1597da153479061_bcb03b0fdb8cc3b92dca47d9bc740543Class->onSubmit()\n#2 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(623): Cms\\Classes\\Controller->runAjaxHandler(\'onSubmit\')\n#3 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(328): Cms\\Classes\\Controller->execAjaxHandlers()\n#4 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(211): Cms\\Classes\\Controller->runPage(Object(Cms\\Classes\\Page))\n#5 /var/www/html/workspace/syaq/modules/cms/classes/CmsController.php(50): Cms\\Classes\\Controller->run(\'account\')\n#6 [internal function]: Cms\\Classes\\CmsController->run(\'account\')\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Controller.php(54): call_user_func_array(Array, Array)\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction(\'run\', Array)\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch(Object(Illuminate\\Routing\\Route), Object(Cms\\Classes\\CmsController), \'run\')\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Route.php(169): Illuminate\\Routing\\Route->runController()\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(658): Illuminate\\Routing\\Route->run()\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#28 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#31 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#32 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#33 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#34 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#35 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#36 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#37 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#38 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#39 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#40 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#41 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#42 {main}', NULL, '2018-09-09 19:36:15', '2018-09-09 19:36:15'),
(396, 'error', 'ErrorException: Trying to get property of non-object in /var/www/html/workspace/syaq/storage/cms/cache/ff/9a/running-orders.htm.php:7\nStack trace:\n#0 /var/www/html/workspace/syaq/storage/cms/cache/ff/9a/running-orders.htm.php(7): Illuminate\\Foundation\\Bootstrap\\HandleExceptions->handleError(8, \'Trying to get p...\', \'/var/www/html/w...\', 7, Array)\n#1 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(426): Cms5b9574350a70f100759868_9dc13e55d62911cb28faaeaf6092149dClass->onStart()\n#2 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(348): Cms\\Classes\\Controller->execPageCycle()\n#3 /var/www/html/workspace/syaq/modules/cms/classes/Controller.php(211): Cms\\Classes\\Controller->runPage(Object(Cms\\Classes\\Page))\n#4 /var/www/html/workspace/syaq/modules/cms/classes/CmsController.php(50): Cms\\Classes\\Controller->run(\'running-orders\')\n#5 [internal function]: Cms\\Classes\\CmsController->run(\'running-orders\')\n#6 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Controller.php(54): call_user_func_array(Array, Array)\n#7 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/ControllerDispatcher.php(45): Illuminate\\Routing\\Controller->callAction(\'run\', Array)\n#8 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Route.php(212): Illuminate\\Routing\\ControllerDispatcher->dispatch(Object(Illuminate\\Routing\\Route), Object(Cms\\Classes\\CmsController), \'run\')\n#9 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Route.php(169): Illuminate\\Routing\\Route->runController()\n#10 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(658): Illuminate\\Routing\\Route->run()\n#11 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Routing\\Router->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#12 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Middleware/SubstituteBindings.php(41): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#13 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Routing\\Middleware\\SubstituteBindings->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#14 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#15 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/View/Middleware/ShareErrorsFromSession.php(49): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#16 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\View\\Middleware\\ShareErrorsFromSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#17 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#18 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Session/Middleware/StartSession.php(63): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#19 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Session\\Middleware\\StartSession->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#20 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#21 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/AddQueuedCookiesToResponse.php(37): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#22 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#23 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#24 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Cookie/Middleware/EncryptCookies.php(59): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#25 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Cookie\\Middleware\\EncryptCookies->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#26 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#27 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#28 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(660): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#29 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(635): Illuminate\\Routing\\Router->runRouteWithinStack(Object(Illuminate\\Routing\\Route), Object(Illuminate\\Http\\Request))\n#30 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Router.php(601): Illuminate\\Routing\\Router->runRoute(Object(Illuminate\\Http\\Request), Object(Illuminate\\Routing\\Route))\n#31 /var/www/html/workspace/syaq/vendor/october/rain/src/Router/CoreRouter.php(20): Illuminate\\Routing\\Router->dispatchToRoute(Object(Illuminate\\Http\\Request))\n#32 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(176): October\\Rain\\Router\\CoreRouter->dispatch(Object(Illuminate\\Http\\Request))\n#33 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(30): Illuminate\\Foundation\\Http\\Kernel->Illuminate\\Foundation\\Http\\{closure}(Object(Illuminate\\Http\\Request))\n#34 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Middleware/CheckForMaintenanceMode.php(46): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#35 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(149): Illuminate\\Foundation\\Http\\Middleware\\CheckForMaintenanceMode->handle(Object(Illuminate\\Http\\Request), Object(Closure))\n#36 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Routing/Pipeline.php(53): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Http\\Request))\n#37 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(102): Illuminate\\Routing\\Pipeline->Illuminate\\Routing\\{closure}(Object(Illuminate\\Http\\Request))\n#38 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(151): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#39 /var/www/html/workspace/syaq/vendor/laravel/framework/src/Illuminate/Foundation/Http/Kernel.php(116): Illuminate\\Foundation\\Http\\Kernel->sendRequestThroughRouter(Object(Illuminate\\Http\\Request))\n#40 /var/www/html/workspace/syaq/index.php(43): Illuminate\\Foundation\\Http\\Kernel->handle(Object(Illuminate\\Http\\Request))\n#41 {main}', NULL, '2018-09-10 09:50:42', '2018-09-10 09:50:42');

-- --------------------------------------------------------

--
-- Table structure for table `system_files`
--

CREATE TABLE `system_files` (
  `id` int(10) UNSIGNED NOT NULL,
  `disk_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int(11) NOT NULL,
  `content_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_files`
--

INSERT INTO `system_files` (`id`, `disk_name`, `file_name`, `file_size`, `content_type`, `title`, `description`, `field`, `attachment_id`, `attachment_type`, `is_public`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, '5b8bd4bd0869d480499582.png', 'logo-syaq.png', 20181, 'image/png', NULL, NULL, 'logo', '1', 'Backend\\Models\\BrandSetting', 1, 1, '2018-09-02 10:17:01', '2018-09-02 10:17:20'),
(6, '5b8bf754a7b01365387590.png', 'shape@2x-1.png', 1392, 'image/png', NULL, NULL, 'icon', '2', 'Worcbox\\Features\\Models\\Item', 1, 6, '2018-09-02 12:44:36', '2018-09-02 12:44:37'),
(7, '5b8bf76b221a9522281692.png', 'power@2x-1.png', 2622, 'image/png', NULL, NULL, 'icon', '3', 'Worcbox\\Features\\Models\\Item', 1, 7, '2018-09-02 12:44:59', '2018-09-02 12:45:00'),
(8, '5b8bf77fd61f1604909012.png', 'target-2-2@2x-1.png', 6701, 'image/png', NULL, NULL, 'icon', '4', 'Worcbox\\Features\\Models\\Item', 1, 8, '2018-09-02 12:45:19', '2018-09-02 12:45:20'),
(9, '5b8bf7a3c4172064231692.png', 'add-anchor-point@2x-1.png', 1710, 'image/png', NULL, NULL, 'icon', '5', 'Worcbox\\Features\\Models\\Item', 1, 9, '2018-09-02 12:45:55', '2018-09-02 12:45:56'),
(10, '5b8bf7b309e8a534225531.png', 'time@2x-1.png', 3420, 'image/png', NULL, NULL, 'icon', '6', 'Worcbox\\Features\\Models\\Item', 1, 10, '2018-09-02 12:46:11', '2018-09-02 12:46:11'),
(11, '5b8bf7c5ba790432220240.png', 'shape_2@2x-1.png', 3098, 'image/png', NULL, NULL, 'icon', '7', 'Worcbox\\Features\\Models\\Item', 1, 11, '2018-09-02 12:46:29', '2018-09-02 12:46:30'),
(12, '5b8d126f1be3e627420569.png', 'group-2@2x.png', 127149, 'image/png', NULL, NULL, 'icon', '8', 'Worcbox\\Features\\Models\\Item', 1, 12, '2018-09-03 08:52:31', '2018-09-03 08:52:35'),
(13, '5b8d1ae74cbda375337558.png', 'group-2@2x.png', 127149, 'image/png', NULL, NULL, 'icon', '9', 'Worcbox\\Features\\Models\\Item', 1, 13, '2018-09-03 09:28:39', '2018-09-03 09:28:40'),
(14, '5b95252522d66834199847.jpg', 'man-629062_960_720.jpg', 73564, 'image/jpeg', NULL, NULL, 'icon', '10', 'Worcbox\\Features\\Models\\Item', 1, 14, '2018-09-09 11:50:29', '2018-09-09 11:50:31'),
(15, '5b9527fb94f90896697648.xlsx', 'PHP Course Content.xlsx', 6299, 'application/octet-stream', NULL, NULL, 'content', '1', 'Worcbox\\Syaq\\Models\\OrderAttachment', 1, 15, '2018-09-09 12:02:35', '2018-09-09 12:02:38'),
(16, '5b952a8b08234681638579.jpg', 'ben-knapen-906550_960_720.jpg', 104691, 'image/jpeg', NULL, NULL, 'icon', '11', 'Worcbox\\Features\\Models\\Item', 1, 16, '2018-09-09 12:13:31', '2018-09-09 12:13:32'),
(17, '5b952c2aa0ee3882106302.docx', 'RoboMind_syllabus.docx', 12819, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', NULL, NULL, 'content', '2', 'Worcbox\\Syaq\\Models\\OrderAttachment', 1, 17, '2018-09-09 12:20:26', '2018-09-09 12:20:28'),
(18, '5b952def00ed5976671076.docx', 'RoboMind_syllabus.docx', 12819, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', NULL, NULL, 'content', '3', 'Worcbox\\Syaq\\Models\\OrderAttachment', 1, 18, '2018-09-09 12:27:59', '2018-09-09 12:28:00'),
(19, '5b9530393fe09326092196.docx', 'Clear goals-technical.docx', 13145, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', NULL, NULL, 'content', '5', 'Worcbox\\Syaq\\Models\\OrderAttachment', 1, 19, '2018-09-09 12:37:45', '2018-09-09 12:37:47'),
(20, '5b965af08625c781672309.png', 'Screen Shot 2018-09-09 at 7.45.26 PM.png', 269904, 'image/png', NULL, NULL, 'content', '6', 'Worcbox\\Syaq\\Models\\OrderAttachment', 1, 20, '2018-09-10 11:52:16', '2018-09-10 11:52:47');

-- --------------------------------------------------------

--
-- Table structure for table `system_mail_layouts`
--

CREATE TABLE `system_mail_layouts` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_html` text COLLATE utf8mb4_unicode_ci,
  `content_text` text COLLATE utf8mb4_unicode_ci,
  `content_css` text COLLATE utf8mb4_unicode_ci,
  `is_locked` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_mail_layouts`
--

INSERT INTO `system_mail_layouts` (`id`, `name`, `code`, `content_html`, `content_text`, `content_css`, `is_locked`, `created_at`, `updated_at`) VALUES
(1, 'Default layout', 'default', '<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n</head>\n<body>\n    <style type=\"text/css\" media=\"screen\">\n        {{ brandCss|raw }}\n        {{ css|raw }}\n    </style>\n\n    <table class=\"wrapper layout-default\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n\n        <!-- Header -->\n        {% partial \'header\' body %}\n            {{ subject|raw }}\n        {% endpartial %}\n\n        <tr>\n            <td align=\"center\">\n                <table class=\"content\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                    <!-- Email Body -->\n                    <tr>\n                        <td class=\"body\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                            <table class=\"inner-body\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\">\n                                <!-- Body content -->\n                                <tr>\n                                    <td class=\"content-cell\">\n                                        {{ content|raw }}\n                                    </td>\n                                </tr>\n                            </table>\n                        </td>\n                    </tr>\n                </table>\n            </td>\n        </tr>\n\n        <!-- Footer -->\n        {% partial \'footer\' body %}\n            &copy; {{ \"now\"|date(\"Y\") }} {{ appName }}. All rights reserved.\n        {% endpartial %}\n\n    </table>\n\n</body>\n</html>', '{{ content|raw }}', '@media only screen and (max-width: 600px) {\n    .inner-body {\n        width: 100% !important;\n    }\n\n    .footer {\n        width: 100% !important;\n    }\n}\n\n@media only screen and (max-width: 500px) {\n    .button {\n        width: 100% !important;\n    }\n}', 1, '2018-08-14 08:42:04', '2018-08-14 08:42:04'),
(2, 'System layout', 'system', '<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n</head>\n<body>\n    <style type=\"text/css\" media=\"screen\">\n        {{ brandCss|raw }}\n        {{ css|raw }}\n    </style>\n\n    <table class=\"wrapper layout-system\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n        <tr>\n            <td align=\"center\">\n                <table class=\"content\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                    <!-- Email Body -->\n                    <tr>\n                        <td class=\"body\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                            <table class=\"inner-body\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\">\n                                <!-- Body content -->\n                                <tr>\n                                    <td class=\"content-cell\">\n                                        {{ content|raw }}\n\n                                        <!-- Subcopy -->\n                                        {% partial \'subcopy\' body %}\n                                            **This is an automatic message. Please do not reply to it.**\n                                        {% endpartial %}\n                                    </td>\n                                </tr>\n                            </table>\n                        </td>\n                    </tr>\n                </table>\n            </td>\n        </tr>\n    </table>\n\n</body>\n</html>', '{{ content|raw }}\n\n\n---\nThis is an automatic message. Please do not reply to it.', '@media only screen and (max-width: 600px) {\n    .inner-body {\n        width: 100% !important;\n    }\n\n    .footer {\n        width: 100% !important;\n    }\n}\n\n@media only screen and (max-width: 500px) {\n    .button {\n        width: 100% !important;\n    }\n}', 1, '2018-08-14 08:42:04', '2018-08-14 08:42:04');

-- --------------------------------------------------------

--
-- Table structure for table `system_mail_partials`
--

CREATE TABLE `system_mail_partials` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_html` text COLLATE utf8mb4_unicode_ci,
  `content_text` text COLLATE utf8mb4_unicode_ci,
  `is_custom` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_mail_partials`
--

INSERT INTO `system_mail_partials` (`id`, `name`, `code`, `content_html`, `content_text`, `is_custom`, `created_at`, `updated_at`) VALUES
(1, 'Header', 'header', '<tr>\n    <td class=\"header\">\n        {% if url %}\n            <a href=\"{{ url }}\">\n                {{ body }}\n            </a>\n        {% else %}\n            <span>\n                {{ body }}\n            </span>\n        {% endif %}\n    </td>\n</tr>', '*** {{ body|trim }} <{{ url }}>', 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(2, 'Footer', 'footer', '<tr>\n    <td>\n        <table class=\"footer\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\">\n            <tr>\n                <td class=\"content-cell\" align=\"center\">\n                    {{ body|md_safe }}\n                </td>\n            </tr>\n        </table>\n    </td>\n</tr>', '-------------------\n{{ body|trim }}', 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(3, 'Button', 'button', '<table class=\"action\" align=\"center\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n    <tr>\n        <td align=\"center\">\n            <table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n                <tr>\n                    <td align=\"center\">\n                        <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n                            <tr>\n                                <td>\n                                    <a href=\"{{ url }}\" class=\"button button-{{ type ?: \'primary\' }}\" target=\"_blank\">\n                                        {{ body }}\n                                    </a>\n                                </td>\n                            </tr>\n                        </table>\n                    </td>\n                </tr>\n            </table>\n        </td>\n    </tr>\n</table>', '{{ body|trim }} <{{ url }}>', 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(4, 'Panel', 'panel', '<table class=\"panel\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n    <tr>\n        <td class=\"panel-content\">\n            <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                <tr>\n                    <td class=\"panel-item\">\n                        {{ body|md_safe }}\n                    </td>\n                </tr>\n            </table>\n        </td>\n    </tr>\n</table>', '{{ body|trim }}', 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(5, 'Table', 'table', '<div class=\"table\">\n    {{ body|md_safe }}\n</div>', '{{ body|trim }}', 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(6, 'Subcopy', 'subcopy', '<table class=\"subcopy\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n    <tr>\n        <td>\n            {{ body|md_safe }}\n        </td>\n    </tr>\n</table>', '-----\n{{ body|trim }}', 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(7, 'Promotion', 'promotion', '<table class=\"promotion\" align=\"center\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n    <tr>\n        <td align=\"center\">\n            {{ body|md_safe }}\n        </td>\n    </tr>\n</table>', '{{ body|trim }}', 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08');

-- --------------------------------------------------------

--
-- Table structure for table `system_mail_templates`
--

CREATE TABLE `system_mail_templates` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `content_html` text COLLATE utf8mb4_unicode_ci,
  `content_text` text COLLATE utf8mb4_unicode_ci,
  `layout_id` int(11) DEFAULT NULL,
  `is_custom` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_mail_templates`
--

INSERT INTO `system_mail_templates` (`id`, `code`, `subject`, `description`, `content_html`, `content_text`, `layout_id`, `is_custom`, `created_at`, `updated_at`) VALUES
(1, 'rainlab.user::mail.activate', NULL, 'Activate a new user', NULL, NULL, 1, 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(2, 'rainlab.user::mail.welcome', NULL, 'User confirmed their account', NULL, NULL, 1, 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(3, 'rainlab.user::mail.restore', NULL, 'User requests a password reset', NULL, NULL, 1, 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(4, 'rainlab.user::mail.new_user', NULL, 'Notify admins of a new sign up', NULL, NULL, 2, 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(5, 'rainlab.user::mail.reactivate', NULL, 'User has reactivated their account', NULL, NULL, 1, 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(6, 'rainlab.user::mail.invite', NULL, 'Invite a new user to the website', NULL, NULL, 1, 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(7, 'backend::mail.invite', NULL, 'Invite new admin to the site', NULL, NULL, 2, 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(8, 'backend::mail.restore', NULL, 'Reset an admin password', NULL, NULL, 2, 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(9, 'worcbox.orders.confirm::mail.message', 'تم استلام الطلب', 'Message of confirming order through email.', '{{ name }}\r\n\r\nتم استلام طلبكم وجارى العمل عليه', '', 1, 1, '2018-09-09 08:08:34', '2018-09-09 08:09:34'),
(10, 'worcbox.syaq.contact::mail.message', '{{ subject }}', 'A message sent from contact us form', 'الاسم\r\n{{ name }}\r\n\r\nالبريد الإلكترونى\r\n{{ email }}\r\n\r\nعنوان الرسالة\r\n{{ subject }}\r\n\r\nنص الرسالة\r\n{{ body }}', '', 1, 1, '2018-09-09 09:14:36', '2018-09-09 09:14:36'),
(11, 'worcbox.orders.finished::mail.message', 'تم الانتهاء من الطلب', 'Sending attachment with the finished order', 'تم الانتهاء من طلبكم .. يرجى تحميله من الملحقات', '', 1, 1, '2018-09-09 12:59:25', '2018-09-09 12:59:25');

-- --------------------------------------------------------

--
-- Table structure for table `system_parameters`
--

CREATE TABLE `system_parameters` (
  `id` int(10) UNSIGNED NOT NULL,
  `namespace` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_parameters`
--

INSERT INTO `system_parameters` (`id`, `namespace`, `group`, `item`, `value`) VALUES
(1, 'system', 'update', 'count', '1'),
(2, 'system', 'core', 'hash', '\"d4a4e1f641e333ff5c26037f86cfe619\"'),
(3, 'system', 'core', 'build', '\"437\"'),
(4, 'system', 'update', 'retry', '1536664597'),
(5, 'cms', 'theme', 'active', '\"syaq\"');

-- --------------------------------------------------------

--
-- Table structure for table `system_plugin_history`
--

CREATE TABLE `system_plugin_history` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_plugin_history`
--

INSERT INTO `system_plugin_history` (`id`, `code`, `type`, `version`, `detail`, `created_at`) VALUES
(1, 'October.Demo', 'comment', '1.0.1', 'First version of Demo', '2018-08-14 08:42:04'),
(45, 'RainLab.Pages', 'comment', '1.0.1', 'Implemented the static pages management and the Static Page component.', '2018-09-02 09:23:18'),
(46, 'RainLab.Pages', 'comment', '1.0.2', 'Fixed the page preview URL.', '2018-09-02 09:23:18'),
(47, 'RainLab.Pages', 'comment', '1.0.3', 'Implemented menus.', '2018-09-02 09:23:18'),
(48, 'RainLab.Pages', 'comment', '1.0.4', 'Implemented the content block management and placeholder support.', '2018-09-02 09:23:18'),
(49, 'RainLab.Pages', 'comment', '1.0.5', 'Added support for the Sitemap plugin.', '2018-09-02 09:23:18'),
(50, 'RainLab.Pages', 'comment', '1.0.6', 'Minor updates to the internal API.', '2018-09-02 09:23:18'),
(51, 'RainLab.Pages', 'comment', '1.0.7', 'Added the Snippets feature.', '2018-09-02 09:23:18'),
(52, 'RainLab.Pages', 'comment', '1.0.8', 'Minor improvements to the code.', '2018-09-02 09:23:18'),
(53, 'RainLab.Pages', 'comment', '1.0.9', 'Fixes issue where Snippet tab is missing from the Partials form.', '2018-09-02 09:23:18'),
(54, 'RainLab.Pages', 'comment', '1.0.10', 'Add translations for various locales.', '2018-09-02 09:23:18'),
(55, 'RainLab.Pages', 'comment', '1.0.11', 'Fixes issue where placeholders tabs were missing from Page form.', '2018-09-02 09:23:18'),
(56, 'RainLab.Pages', 'comment', '1.0.12', 'Implement Media Manager support.', '2018-09-02 09:23:18'),
(57, 'RainLab.Pages', 'script', '1.1.0', 'snippets_rename_viewbag_properties.php', '2018-09-02 09:23:18'),
(58, 'RainLab.Pages', 'comment', '1.1.0', 'Adds meta title and description to pages. Adds |staticPage filter.', '2018-09-02 09:23:18'),
(59, 'RainLab.Pages', 'comment', '1.1.1', 'Add support for Syntax Fields.', '2018-09-02 09:23:18'),
(60, 'RainLab.Pages', 'comment', '1.1.2', 'Static Breadcrumbs component now respects the hide from navigation setting.', '2018-09-02 09:23:18'),
(61, 'RainLab.Pages', 'comment', '1.1.3', 'Minor back-end styling fix.', '2018-09-02 09:23:18'),
(62, 'RainLab.Pages', 'comment', '1.1.4', 'Minor fix to the StaticPage component API.', '2018-09-02 09:23:18'),
(63, 'RainLab.Pages', 'comment', '1.1.5', 'Fixes bug when using syntax fields.', '2018-09-02 09:23:18'),
(64, 'RainLab.Pages', 'comment', '1.1.6', 'Minor styling fix to the back-end UI.', '2018-09-02 09:23:18'),
(65, 'RainLab.Pages', 'comment', '1.1.7', 'Improved menu item form to include CSS class, open in a new window and hidden flag.', '2018-09-02 09:23:18'),
(66, 'RainLab.Pages', 'comment', '1.1.8', 'Improved the output of snippet partials when saved.', '2018-09-02 09:23:18'),
(67, 'RainLab.Pages', 'comment', '1.1.9', 'Minor update to snippet inspector internal API.', '2018-09-02 09:23:18'),
(68, 'RainLab.Pages', 'comment', '1.1.10', 'Fixes a bug where selecting a layout causes permanent unsaved changes.', '2018-09-02 09:23:18'),
(69, 'RainLab.Pages', 'comment', '1.1.11', 'Add support for repeater syntax field.', '2018-09-02 09:23:18'),
(70, 'RainLab.Pages', 'comment', '1.2.0', 'Added support for translations, UI updates.', '2018-09-02 09:23:18'),
(71, 'RainLab.Pages', 'comment', '1.2.1', 'Use nice titles when listing the content files.', '2018-09-02 09:23:18'),
(72, 'RainLab.Pages', 'comment', '1.2.2', 'Minor styling update.', '2018-09-02 09:23:19'),
(73, 'RainLab.Pages', 'comment', '1.2.3', 'Snippets can now be moved by dragging them.', '2018-09-02 09:23:19'),
(74, 'RainLab.Pages', 'comment', '1.2.4', 'Fixes a bug where the cursor is misplaced when editing text files.', '2018-09-02 09:23:19'),
(75, 'RainLab.Pages', 'comment', '1.2.5', 'Fixes a bug where the parent page is lost upon changing a page layout.', '2018-09-02 09:23:19'),
(76, 'RainLab.Pages', 'comment', '1.2.6', 'Shared view variables are now passed to static pages.', '2018-09-02 09:23:19'),
(77, 'RainLab.Pages', 'comment', '1.2.7', 'Fixes issue with duplicating properties when adding multiple snippets on the same page.', '2018-09-02 09:23:19'),
(78, 'RainLab.Pages', 'comment', '1.2.8', 'Fixes a bug where creating a content block without extension doesn\'t save the contents to file.', '2018-09-02 09:23:19'),
(79, 'RainLab.Pages', 'comment', '1.2.9', 'Add conditional support for translating page URLs.', '2018-09-02 09:23:19'),
(80, 'RainLab.Pages', 'comment', '1.2.10', 'Streamline generation of URLs to use the new Cms::url helper.', '2018-09-02 09:23:19'),
(81, 'RainLab.Pages', 'comment', '1.2.11', 'Implements repeater usage with translate plugin.', '2018-09-02 09:23:19'),
(82, 'RainLab.Pages', 'comment', '1.2.12', 'Fixes minor issue when using snippets and switching the application locale.', '2018-09-02 09:23:19'),
(83, 'RainLab.Pages', 'comment', '1.2.13', 'Fixes bug when AJAX is used on a page that does not yet exist.', '2018-09-02 09:23:19'),
(84, 'RainLab.Pages', 'comment', '1.2.14', 'Add theme logging support for changes made to menus.', '2018-09-02 09:23:19'),
(85, 'RainLab.Pages', 'comment', '1.2.15', 'Back-end navigation sort order updated.', '2018-09-02 09:23:19'),
(86, 'RainLab.Pages', 'comment', '1.2.16', 'Fixes a bug when saving a template that has been modified outside of the CMS (mtime mismatch).', '2018-09-02 09:23:19'),
(87, 'RainLab.Pages', 'comment', '1.2.17', 'Changes locations of custom fields to secondary tabs instead of the primary Settings area. New menu search ability on adding menu items', '2018-09-02 09:23:19'),
(88, 'RainLab.Pages', 'comment', '1.2.18', 'Fixes cache-invalidation issues when RainLab.Translate is not installed. Added Greek & Simplified Chinese translations. Removed deprecated calls. Allowed saving HTML in snippet properties. Added support for the MediaFinder in menu items.', '2018-09-02 09:23:19'),
(171, 'RainLab.Builder', 'comment', '1.0.1', 'Initialize plugin.', '2018-09-02 11:21:40'),
(172, 'RainLab.Builder', 'comment', '1.0.2', 'Fixes the problem with selecting a plugin. Minor localization corrections. Configuration files in the list and form behaviors are now autocomplete.', '2018-09-02 11:21:40'),
(173, 'RainLab.Builder', 'comment', '1.0.3', 'Improved handling of the enum data type.', '2018-09-02 11:21:40'),
(174, 'RainLab.Builder', 'comment', '1.0.4', 'Added user permissions to work with the Builder.', '2018-09-02 11:21:40'),
(175, 'RainLab.Builder', 'comment', '1.0.5', 'Fixed permissions registration.', '2018-09-02 11:21:40'),
(176, 'RainLab.Builder', 'comment', '1.0.6', 'Fixed front-end record ordering in the Record List component.', '2018-09-02 11:21:40'),
(177, 'RainLab.Builder', 'comment', '1.0.7', 'Builder settings are now protected with user permissions. The database table column list is scrollable now. Minor code cleanup.', '2018-09-02 11:21:40'),
(178, 'RainLab.Builder', 'comment', '1.0.8', 'Added the Reorder Controller behavior.', '2018-09-02 11:21:40'),
(179, 'RainLab.Builder', 'comment', '1.0.9', 'Minor API and UI updates.', '2018-09-02 11:21:40'),
(180, 'RainLab.Builder', 'comment', '1.0.10', 'Minor styling update.', '2018-09-02 11:21:40'),
(181, 'RainLab.Builder', 'comment', '1.0.11', 'Fixed a bug where clicking placeholder in a repeater would open Inspector. Fixed a problem with saving forms with repeaters in tabs. Minor style fix.', '2018-09-02 11:21:40'),
(182, 'RainLab.Builder', 'comment', '1.0.12', 'Added support for the Trigger property to the Media Finder widget configuration. Names of form fields and list columns definition files can now contain underscores.', '2018-09-02 11:21:40'),
(183, 'RainLab.Builder', 'comment', '1.0.13', 'Minor styling fix on the database editor.', '2018-09-02 11:21:40'),
(184, 'RainLab.Builder', 'comment', '1.0.14', 'Added support for published_at timestamp field', '2018-09-02 11:21:40'),
(185, 'RainLab.Builder', 'comment', '1.0.15', 'Fixed a bug where saving a localization string in Inspector could cause a JavaScript error. Added support for Timestamps and Soft Deleting for new models.', '2018-09-02 11:21:40'),
(186, 'RainLab.Builder', 'comment', '1.0.16', 'Fixed a bug when saving a form with the Repeater widget in a tab could create invalid fields in the form\'s outside area. Added a check that prevents creating localization strings inside other existing strings.', '2018-09-02 11:21:40'),
(187, 'RainLab.Builder', 'comment', '1.0.17', 'Added support Trigger attribute support for RecordFinder and Repeater form widgets.', '2018-09-02 11:21:40'),
(188, 'RainLab.Builder', 'comment', '1.0.18', 'Fixes a bug where \'::class\' notations in a model class definition could prevent the model from appearing in the Builder model list. Added emptyOption property support to the dropdown form control.', '2018-09-02 11:21:40'),
(189, 'RainLab.Builder', 'comment', '1.0.19', 'Added a feature allowing to add all database columns to a list definition. Added max length validation for database table and column names.', '2018-09-02 11:21:40'),
(190, 'RainLab.Builder', 'comment', '1.0.20', 'Fixes a bug where form the builder could trigger the \"current.hasAttribute is not a function\" error.', '2018-09-02 11:21:40'),
(191, 'RainLab.Builder', 'comment', '1.0.21', 'Back-end navigation sort order updated.', '2018-09-02 11:21:40'),
(192, 'RainLab.Builder', 'comment', '1.0.22', 'Added scopeValue property to the RecordList component.', '2018-09-02 11:21:40'),
(206, 'RainLab.User', 'script', '1.0.1', 'create_users_table.php', '2018-09-02 11:24:49'),
(207, 'RainLab.User', 'script', '1.0.1', 'create_throttle_table.php', '2018-09-02 11:24:49'),
(208, 'RainLab.User', 'comment', '1.0.1', 'Initialize plugin.', '2018-09-02 11:24:49'),
(209, 'RainLab.User', 'comment', '1.0.2', 'Seed tables.', '2018-09-02 11:24:49'),
(210, 'RainLab.User', 'comment', '1.0.3', 'Translated hard-coded text to language strings.', '2018-09-02 11:24:49'),
(211, 'RainLab.User', 'comment', '1.0.4', 'Improvements to user-interface for Location manager.', '2018-09-02 11:24:49'),
(212, 'RainLab.User', 'comment', '1.0.5', 'Added contact details for users.', '2018-09-02 11:24:49'),
(213, 'RainLab.User', 'script', '1.0.6', 'create_mail_blockers_table.php', '2018-09-02 11:24:50'),
(214, 'RainLab.User', 'comment', '1.0.6', 'Added Mail Blocker utility so users can block specific mail templates.', '2018-09-02 11:24:50'),
(215, 'RainLab.User', 'comment', '1.0.7', 'Add back-end Settings page.', '2018-09-02 11:24:50'),
(216, 'RainLab.User', 'comment', '1.0.8', 'Updated the Settings page.', '2018-09-02 11:24:50'),
(217, 'RainLab.User', 'comment', '1.0.9', 'Adds new welcome mail message for users and administrators.', '2018-09-02 11:24:50'),
(218, 'RainLab.User', 'comment', '1.0.10', 'Adds administrator-only activation mode.', '2018-09-02 11:24:50'),
(219, 'RainLab.User', 'script', '1.0.11', 'users_add_login_column.php', '2018-09-02 11:24:50'),
(220, 'RainLab.User', 'comment', '1.0.11', 'Users now have an optional login field that defaults to the email field.', '2018-09-02 11:24:50'),
(221, 'RainLab.User', 'script', '1.0.12', 'users_rename_login_to_username.php', '2018-09-02 11:24:50'),
(222, 'RainLab.User', 'comment', '1.0.12', 'Create a dedicated setting for choosing the login mode.', '2018-09-02 11:24:50'),
(223, 'RainLab.User', 'comment', '1.0.13', 'Minor fix to the Account sign in logic.', '2018-09-02 11:24:50'),
(224, 'RainLab.User', 'comment', '1.0.14', 'Minor improvements to the code.', '2018-09-02 11:24:50'),
(225, 'RainLab.User', 'script', '1.0.15', 'users_add_surname.php', '2018-09-02 11:24:50'),
(226, 'RainLab.User', 'comment', '1.0.15', 'Adds last name column to users table (surname).', '2018-09-02 11:24:50'),
(227, 'RainLab.User', 'comment', '1.0.16', 'Require permissions for settings page too.', '2018-09-02 11:24:50'),
(228, 'RainLab.User', 'comment', '1.1.0', '!!! Profile fields and Locations have been removed.', '2018-09-02 11:24:50'),
(229, 'RainLab.User', 'script', '1.1.1', 'create_user_groups_table.php', '2018-09-02 11:24:50'),
(230, 'RainLab.User', 'script', '1.1.1', 'seed_user_groups_table.php', '2018-09-02 11:24:50'),
(231, 'RainLab.User', 'comment', '1.1.1', 'Users can now be added to groups.', '2018-09-02 11:24:50'),
(232, 'RainLab.User', 'comment', '1.1.2', 'A raw URL can now be passed as the redirect property in the Account component.', '2018-09-02 11:24:50'),
(233, 'RainLab.User', 'comment', '1.1.3', 'Adds a super user flag to the users table, reserved for future use.', '2018-09-02 11:24:50'),
(234, 'RainLab.User', 'comment', '1.1.4', 'User list can be filtered by the group they belong to.', '2018-09-02 11:24:50'),
(235, 'RainLab.User', 'comment', '1.1.5', 'Adds a new permission to hide the User settings menu item.', '2018-09-02 11:24:50'),
(236, 'RainLab.User', 'script', '1.2.0', 'users_add_deleted_at.php', '2018-09-02 11:24:50'),
(237, 'RainLab.User', 'comment', '1.2.0', 'Users can now deactivate their own accounts.', '2018-09-02 11:24:50'),
(238, 'RainLab.User', 'comment', '1.2.1', 'New feature for checking if a user is recently active/online.', '2018-09-02 11:24:50'),
(239, 'RainLab.User', 'comment', '1.2.2', 'Add bulk action button to user list.', '2018-09-02 11:24:50'),
(240, 'RainLab.User', 'comment', '1.2.3', 'Included some descriptive paragraphs in the Reset Password component markup.', '2018-09-02 11:24:50'),
(241, 'RainLab.User', 'comment', '1.2.4', 'Added a checkbox for blocking all mail sent to the user.', '2018-09-02 11:24:50'),
(242, 'RainLab.User', 'script', '1.2.5', 'update_timestamp_nullable.php', '2018-09-02 11:24:50'),
(243, 'RainLab.User', 'comment', '1.2.5', 'Database maintenance. Updated all timestamp columns to be nullable.', '2018-09-02 11:24:50'),
(244, 'RainLab.User', 'script', '1.2.6', 'users_add_last_seen.php', '2018-09-02 11:24:51'),
(245, 'RainLab.User', 'comment', '1.2.6', 'Add a dedicated last seen column for users.', '2018-09-02 11:24:51'),
(246, 'RainLab.User', 'comment', '1.2.7', 'Minor fix to user timestamp attributes.', '2018-09-02 11:24:51'),
(247, 'RainLab.User', 'comment', '1.2.8', 'Add date range filter to users list. Introduced a logout event.', '2018-09-02 11:24:51'),
(248, 'RainLab.User', 'comment', '1.2.9', 'Add invitation mail for new accounts created in the back-end.', '2018-09-02 11:24:51'),
(249, 'RainLab.User', 'script', '1.3.0', 'users_add_guest_flag.php', '2018-09-02 11:24:51'),
(250, 'RainLab.User', 'script', '1.3.0', 'users_add_superuser_flag.php', '2018-09-02 11:24:51'),
(251, 'RainLab.User', 'comment', '1.3.0', 'Introduced guest user accounts.', '2018-09-02 11:24:51'),
(252, 'RainLab.User', 'comment', '1.3.1', 'User notification variables can now be extended.', '2018-09-02 11:24:51'),
(253, 'RainLab.User', 'comment', '1.3.2', 'Minor fix to the Auth::register method.', '2018-09-02 11:24:51'),
(254, 'RainLab.User', 'comment', '1.3.3', 'Allow prevention of concurrent user sessions via the user settings.', '2018-09-02 11:24:51'),
(255, 'RainLab.User', 'comment', '1.3.4', 'Added force secure protocol property to the account component.', '2018-09-02 11:24:51'),
(256, 'RainLab.User', 'comment', '1.4.0', '!!! The Notifications tab in User settings has been removed.', '2018-09-02 11:24:51'),
(257, 'RainLab.User', 'comment', '1.4.1', 'Added support for user impersonation.', '2018-09-02 11:24:51'),
(258, 'RainLab.User', 'comment', '1.4.2', 'Fixes security bug in Password Reset component.', '2018-09-02 11:24:51'),
(259, 'RainLab.User', 'comment', '1.4.3', 'Fixes session handling for AJAX requests.', '2018-09-02 11:24:51'),
(260, 'RainLab.User', 'comment', '1.4.4', 'Fixes bug where impersonation touches the last seen timestamp.', '2018-09-02 11:24:51'),
(261, 'RainLab.User', 'comment', '1.4.5', 'Added token fallback process to Account / Reset Password components when parameter is missing.', '2018-09-02 11:24:51'),
(262, 'RainLab.User', 'comment', '1.4.6', 'Fixes Auth::register method signature mismatch with core OctoberCMS Auth library', '2018-09-02 11:24:51'),
(265, 'Worcbox.Features', 'comment', '1.0.1', 'Initialize plugin.', '2018-09-02 11:26:26'),
(266, 'Worcbox.Features', 'script', '1.0.2', 'builder_table_create_worcbox_features_.php', '2018-09-02 11:26:58'),
(267, 'Worcbox.Features', 'comment', '1.0.2', 'Created table worcbox_features_', '2018-09-02 11:26:58'),
(268, 'Worcbox.Features', 'script', '1.0.3', 'builder_table_update_worcbox_features_items.php', '2018-09-02 11:27:45'),
(269, 'Worcbox.Features', 'comment', '1.0.3', 'Updated table worcbox_features_', '2018-09-02 11:27:45'),
(270, 'Worcbox.Features', 'script', '1.0.4', 'builder_table_update_worcbox_features_items_2.php', '2018-09-02 11:37:42'),
(271, 'Worcbox.Features', 'comment', '1.0.4', 'Updated table worcbox_features_items', '2018-09-02 11:37:42'),
(272, 'Worcbox.Features', 'script', '1.0.5', 'builder_table_update_worcbox_features_items_3.php', '2018-09-02 11:45:55'),
(273, 'Worcbox.Features', 'comment', '1.0.5', 'Updated table worcbox_features_items', '2018-09-02 11:45:55'),
(274, 'Worcbox.Syaq', 'comment', '1.0.1', 'Initialize plugin.', '2018-09-02 13:52:25'),
(275, 'Worcbox.Syaq', 'script', '1.0.2', 'builder_table_create_worcbox_syaq_services.php', '2018-09-02 14:00:35'),
(276, 'Worcbox.Syaq', 'comment', '1.0.2', 'Created table worcbox_syaq_services', '2018-09-02 14:00:35'),
(278, 'Worcbox.Features', 'script', '1.0.6', 'builder_table_update_worcbox_features_items_4.php', '2018-09-03 08:27:58'),
(279, 'Worcbox.Features', 'comment', '1.0.6', 'Updated table worcbox_features_items', '2018-09-03 08:27:58'),
(280, 'Worcbox.Packages', 'comment', '1.0.1', 'Initialize plugin.', '2018-09-03 10:18:44'),
(281, 'Worcbox.Packages', 'script', '1.0.2', 'builder_table_create_worcbox_packages_items.php', '2018-09-03 10:22:25'),
(282, 'Worcbox.Packages', 'comment', '1.0.2', 'Created table worcbox_packages_items', '2018-09-03 10:22:25'),
(283, 'Worcbox.Syaq', 'script', '1.0.3', 'builder_table_create_worcbox_syaq_orders.php', '2018-09-03 10:40:21'),
(284, 'Worcbox.Syaq', 'comment', '1.0.3', 'Created table worcbox_syaq_orders', '2018-09-03 10:40:21'),
(285, 'Worcbox.Syaq', 'script', '1.0.4', 'builder_table_create_worcbox_syaq_fields.php', '2018-09-03 10:41:13'),
(286, 'Worcbox.Syaq', 'comment', '1.0.4', 'Created table worcbox_syaq_fields', '2018-09-03 10:41:13'),
(287, 'Worcbox.Syaq', 'script', '1.0.5', 'builder_table_update_worcbox_syaq_orders.php', '2018-09-03 10:41:25'),
(288, 'Worcbox.Syaq', 'comment', '1.0.5', 'Updated table worcbox_syaq_orders', '2018-09-03 10:41:25'),
(289, 'Worcbox.Syaq', 'script', '1.0.6', 'builder_table_create_worcbox_syaq_audience_genders.php', '2018-09-03 10:42:05'),
(290, 'Worcbox.Syaq', 'comment', '1.0.6', 'Created table worcbox_syaq_audience_genders', '2018-09-03 10:42:05'),
(291, 'Worcbox.Syaq', 'script', '1.0.7', 'builder_table_update_worcbox_syaq_fields.php', '2018-09-03 10:42:11'),
(292, 'Worcbox.Syaq', 'comment', '1.0.7', 'Updated table worcbox_syaq_fields', '2018-09-03 10:42:11'),
(293, 'Worcbox.Syaq', 'script', '1.0.8', 'builder_table_create_worcbox_syaq_.php', '2018-09-03 10:42:40'),
(294, 'Worcbox.Syaq', 'comment', '1.0.8', 'Created table worcbox_syaq_', '2018-09-03 10:42:40'),
(295, 'Worcbox.Syaq', 'script', '1.0.9', 'builder_table_create_worcbox_syaq_title_fields.php', '2018-09-03 10:43:09'),
(296, 'Worcbox.Syaq', 'comment', '1.0.9', 'Created table worcbox_syaq_title_fields', '2018-09-03 10:43:09'),
(297, 'Worcbox.Syaq', 'script', '1.0.10', 'builder_table_create_worcbox_syaq_typing_modes.php', '2018-09-03 10:43:39'),
(298, 'Worcbox.Syaq', 'comment', '1.0.10', 'Created table worcbox_syaq_typing_modes', '2018-09-03 10:43:39'),
(299, 'Worcbox.Syaq', 'script', '1.0.11', 'builder_table_update_worcbox_syaq_speech_formats.php', '2018-09-03 10:44:12'),
(300, 'Worcbox.Syaq', 'comment', '1.0.11', 'Updated table worcbox_syaq_', '2018-09-03 10:44:12'),
(301, 'Worcbox.Syaq', 'script', '1.0.12', 'builder_table_update_worcbox_syaq_orders_2.php', '2018-09-03 10:45:02'),
(302, 'Worcbox.Syaq', 'comment', '1.0.12', 'Updated table worcbox_syaq_orders', '2018-09-03 10:45:02'),
(303, 'Worcbox.Syaq', 'script', '1.0.13', 'builder_table_update_worcbox_syaq_orders_3.php', '2018-09-03 10:58:28'),
(304, 'Worcbox.Syaq', 'comment', '1.0.13', 'Updated table worcbox_syaq_orders', '2018-09-03 10:58:28'),
(305, 'Worcbox.Syaq', 'script', '1.0.14', 'builder_table_update_worcbox_syaq_services.php', '2018-09-03 12:35:33'),
(306, 'Worcbox.Syaq', 'comment', '1.0.14', 'Updated table worcbox_syaq_services', '2018-09-03 12:35:33'),
(307, 'Worcbox.Features', 'script', '1.0.7', 'builder_table_update_worcbox_features_items_5.php', '2018-09-04 08:04:50'),
(308, 'Worcbox.Features', 'comment', '1.0.7', 'Updated table worcbox_features_items', '2018-09-04 08:04:50'),
(309, 'Worcbox.Features', 'script', '1.0.8', 'builder_table_update_worcbox_features_items_6.php', '2018-09-04 08:07:27'),
(310, 'Worcbox.Features', 'comment', '1.0.8', 'Updated table worcbox_features_items', '2018-09-04 08:07:27'),
(311, 'Worcbox.Syaq', 'script', '1.0.15', 'builder_table_update_worcbox_syaq_orders_4.php', '2018-09-04 08:56:54'),
(312, 'Worcbox.Syaq', 'comment', '1.0.15', 'Updated table worcbox_syaq_orders', '2018-09-04 08:56:54'),
(313, 'Worcbox.Syaq', 'script', '1.0.16', 'builder_table_update_worcbox_syaq_orders_5.php', '2018-09-05 08:47:29'),
(314, 'Worcbox.Syaq', 'comment', '1.0.16', 'Updated table worcbox_syaq_orders', '2018-09-05 08:47:29'),
(315, 'Worcbox.Syaq', 'script', '1.0.17', 'builder_table_update_worcbox_syaq_orders_6.php', '2018-09-05 08:49:20'),
(316, 'Worcbox.Syaq', 'comment', '1.0.17', 'Updated table worcbox_syaq_orders', '2018-09-05 08:49:20'),
(317, 'Worcbox.Syaq', 'script', '1.0.18', 'builder_table_update_worcbox_syaq_orders_7.php', '2018-09-05 09:33:42'),
(318, 'Worcbox.Syaq', 'comment', '1.0.18', 'Updated table worcbox_syaq_orders', '2018-09-05 09:33:42'),
(319, 'Worcbox.Syaq', 'script', '1.0.19', 'builder_table_create_worcbox_syaq_order_attachments.php', '2018-09-05 12:23:22'),
(320, 'Worcbox.Syaq', 'comment', '1.0.19', 'Created table worcbox_syaq_order_attachments', '2018-09-05 12:23:22'),
(321, 'Worcbox.Syaq', 'script', '1.0.20', 'builder_table_update_worcbox_syaq_orders_8.php', '2018-09-05 13:43:20'),
(322, 'Worcbox.Syaq', 'comment', '1.0.20', 'Updated table worcbox_syaq_orders', '2018-09-05 13:43:20'),
(323, 'Worcbox.Syaq', 'script', '1.0.21', 'builder_table_update_worcbox_syaq_order_attachments.php', '2018-09-06 08:20:42'),
(324, 'Worcbox.Syaq', 'comment', '1.0.21', 'Updated table worcbox_syaq_order_attachments', '2018-09-06 08:20:42'),
(325, 'Worcbox.Packages', 'script', '1.0.3', 'builder_table_update_worcbox_packages_items.php', '2018-09-06 14:29:53'),
(326, 'Worcbox.Packages', 'comment', '1.0.3', 'Updated table worcbox_packages_items', '2018-09-06 14:29:53'),
(327, 'Worcbox.StaticData', 'comment', '1.0.1', 'Initialize plugin.', '2018-09-09 09:36:41'),
(328, 'Worcbox.StaticData', 'script', '1.0.2', 'builder_table_create_worcbox_staticdata_lookups.php', '2018-09-09 09:38:02'),
(329, 'Worcbox.StaticData', 'comment', '1.0.2', 'Created table worcbox_staticdata_lookups', '2018-09-09 09:38:02'),
(330, 'Worcbox.StaticData', 'script', '1.0.3', 'builder_table_update_worcbox_staticdata_lookups.php', '2018-09-09 09:38:50'),
(331, 'Worcbox.StaticData', 'comment', '1.0.3', 'Updated table worcbox_staticdata_lookups', '2018-09-09 09:38:50'),
(332, 'Flynsarmy.SocialLogin', 'script', '1.0.1', 'create_flynsarmy_sociallogin_user_providers.php', '2018-09-09 15:41:37'),
(333, 'Flynsarmy.SocialLogin', 'comment', '1.0.1', 'First version of SocialLogin', '2018-09-09 15:41:37'),
(334, 'Flynsarmy.SocialLogin', 'comment', '1.0.2', 'Require RainLab.User', '2018-09-09 15:41:37'),
(335, 'Flynsarmy.SocialLogin', 'comment', '1.0.3', 'Fixed RainLab.User integration', '2018-09-09 15:41:37'),
(336, 'Flynsarmy.SocialLogin', 'comment', '1.0.4', 'User registration bug fix', '2018-09-09 15:41:37'),
(337, 'Flynsarmy.SocialLogin', 'comment', '1.0.5', 'Fix password confirmation error', '2018-09-09 15:41:37'),
(338, 'Flynsarmy.SocialLogin', 'comment', '1.0.6', 'Add login details when registering users', '2018-09-09 15:41:37'),
(339, 'Flynsarmy.SocialLogin', 'comment', '1.0.7', 'Rename login to username to match RainLab.Users latest update', '2018-09-09 15:41:37'),
(340, 'Flynsarmy.SocialLogin', 'comment', '1.0.8', 'RC compatibility update', '2018-09-09 15:41:37'),
(341, 'Flynsarmy.SocialLogin', 'comment', '1.0.9', 'Google login fix', '2018-09-09 15:41:37'),
(342, 'Flynsarmy.SocialLogin', 'comment', '1.0.10', 'Don\'t add multiple Google associations to users', '2018-09-09 15:41:37'),
(343, 'Flynsarmy.SocialLogin', 'comment', '1.0.11', 'Modified table key name', '2018-09-09 15:41:37'),
(344, 'Flynsarmy.SocialLogin', 'comment', '1.0.12', 'Update login providers', '2018-09-09 15:41:37'),
(345, 'Flynsarmy.SocialLogin', 'comment', '1.0.13', 'Deprecated code fix, settings page fix', '2018-09-09 15:41:37'),
(346, 'Flynsarmy.SocialLogin', 'comment', '1.0.14', 'Singleton trait fix', '2018-09-09 15:41:37'),
(347, 'Flynsarmy.SocialLogin', 'comment', '1.0.15', 'Compatibility fix with RainLab.GoogleAnalytics', '2018-09-09 15:41:37'),
(348, 'Flynsarmy.SocialLogin', 'script', '1.0.16', 'update_provider_settings_locations_1016.php', '2018-09-09 15:41:37'),
(349, 'Flynsarmy.SocialLogin', 'comment', '1.0.16', '!!! Important update with breaking changes.', '2018-09-09 15:41:37'),
(350, 'Flynsarmy.SocialLogin', 'comment', '1.0.17', 'Fixed issue registering new users', '2018-09-09 15:41:37'),
(351, 'Flynsarmy.SocialLogin', 'comment', '1.0.18', '!!! Requires October build 420 or higher.', '2018-09-09 15:41:37'),
(352, 'Flynsarmy.SocialLogin', 'comment', '1.0.19', 'Add backend permission requirement', '2018-09-09 15:41:37'),
(353, 'Flynsarmy.SocialLogin', 'script', '1.0.20', 'Prevent users from registering when Allow user registration is OFF (Thanks to Kurt Jensen)', '2018-09-09 15:41:37'),
(354, 'Flynsarmy.SocialLogin', 'script', '1.0.20', 'Grab user profile picture on account registration (Thanks to kdoonboli)', '2018-09-09 15:41:37'),
(355, 'Flynsarmy.SocialLogin', 'script', '1.0.20', 'Fix redirects on custom login (Thanks to kdoonboli)', '2018-09-09 15:41:37'),
(356, 'Flynsarmy.SocialLogin', 'comment', '1.0.20', 'Upgrade to latest socialite', '2018-09-09 15:41:37'),
(357, 'Flynsarmy.SocialLogin', 'script', '1.0.21', 'Remove deprecated Facebook scope', '2018-09-09 15:41:37'),
(358, 'Flynsarmy.SocialLogin', 'comment', '1.0.21', 'Update socialite', '2018-09-09 15:41:37');

-- --------------------------------------------------------

--
-- Table structure for table `system_plugin_versions`
--

CREATE TABLE `system_plugin_versions` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `is_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `is_frozen` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_plugin_versions`
--

INSERT INTO `system_plugin_versions` (`id`, `code`, `version`, `created_at`, `is_disabled`, `is_frozen`) VALUES
(1, 'October.Demo', '1.0.1', '2018-08-14 08:42:04', 0, 0),
(3, 'RainLab.Pages', '1.2.18', '2018-09-02 09:23:19', 0, 0),
(7, 'RainLab.Builder', '1.0.22', '2018-09-02 11:21:40', 0, 0),
(9, 'RainLab.User', '1.4.6', '2018-09-02 11:24:51', 0, 0),
(10, 'Worcbox.Features', '1.0.8', '2018-09-04 08:07:27', 0, 0),
(11, 'Worcbox.Syaq', '1.0.21', '2018-09-06 08:20:42', 0, 0),
(13, 'Worcbox.Packages', '1.0.3', '2018-09-06 14:29:53', 0, 0),
(14, 'Worcbox.StaticData', '1.0.3', '2018-09-09 09:38:50', 0, 0),
(15, 'Flynsarmy.SocialLogin', '1.0.21', '2018-09-09 15:41:37', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `system_request_logs`
--

CREATE TABLE `system_request_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `status_code` int(11) DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer` text COLLATE utf8mb4_unicode_ci,
  `count` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_revisions`
--

CREATE TABLE `system_revisions` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cast` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_value` text COLLATE utf8mb4_unicode_ci,
  `new_value` text COLLATE utf8mb4_unicode_ci,
  `revisionable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revisionable_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `item` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `item`, `value`) VALUES
(1, 'backend_brand_settings', '{\"app_name\":\"Syaq\",\"app_tagline\":\"Syaq\",\"primary_color\":\"#34495e\",\"secondary_color\":\"#e67e22\",\"accent_color\":\"#3498db\",\"menu_mode\":\"inline\",\"custom_css\":\"\"}'),
(2, 'rainlab_builder_settings', '{\"author_name\":\"Worcbox\",\"author_namespace\":\"Worcbox\"}'),
(3, 'user_settings', '{\"require_activation\":\"1\",\"activate_mode\":\"auto\",\"use_throttle\":\"1\",\"block_persistence\":\"0\",\"allow_registration\":\"1\",\"login_attribute\":\"email\"}'),
(4, 'system_mail_settings', '{\"send_mode\":\"smtp\",\"sender_name\":\"Syaq\",\"sender_email\":\"noreply@syaq.com\",\"sendmail_path\":\"\\/usr\\/sbin\\/sendmail -bs\",\"smtp_address\":\"smtp.gmail.com\",\"smtp_port\":\"587\",\"smtp_user\":\"syaq.app@gmail.com\",\"smtp_password\":\"Syaq@pp2018\",\"smtp_authorization\":\"1\",\"smtp_encryption\":\"tls\",\"mailgun_domain\":\"\",\"mailgun_secret\":\"\",\"mandrill_secret\":\"\",\"ses_key\":\"\",\"ses_secret\":\"\",\"ses_region\":\"\"}'),
(5, 'flynsarmy_sociallogin_settings', '{\"providers\":[]}');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activation_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `persist_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_password_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `is_activated` tinyint(1) NOT NULL DEFAULT '0',
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `last_seen` timestamp NULL DEFAULT NULL,
  `is_guest` tinyint(1) NOT NULL DEFAULT '0',
  `is_superuser` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `activation_code`, `persist_code`, `reset_password_code`, `permissions`, `is_activated`, `activated_at`, `last_login`, `created_at`, `updated_at`, `username`, `surname`, `deleted_at`, `last_seen`, `is_guest`, `is_superuser`) VALUES
(1, 'مصطفى الجزار', 'mostafa@worcbox.com', '$2y$10$depXlZF2SimQT11XRLz5VOKlkCFkzEsCmrrOzr1dBj0r34LawkOPa', NULL, NULL, NULL, NULL, 1, '2018-09-02 11:36:39', '2018-09-09 18:57:23', '2018-09-02 11:36:00', '2018-09-09 18:57:35', 'mostafa@mailinator.com', '', NULL, '2018-09-09 18:57:24', 0, 0),
(2, 'Aly', 'aly@mailinator.com', '$2y$10$c74NFInXsF0rWYcJIuL7TuA.O.mZTc30vq8zIMlrA5VJTKHRfo7iy', NULL, NULL, NULL, NULL, 1, '2018-09-02 12:36:36', '2018-09-02 12:36:37', '2018-09-02 12:36:36', '2018-09-02 12:37:14', 'aly@mailinator.com', NULL, NULL, NULL, 0, 0),
(3, 'Ibraheem', 'ibraheem@mailinator.com', '$2y$10$ZWC7m7IaAvwO1iRMrA6K0el7ozlzbU8CtPEgJp/rFU3a6DGpgXqUC', NULL, NULL, NULL, NULL, 1, '2018-09-02 12:37:46', '2018-09-02 12:37:46', '2018-09-02 12:37:46', '2018-09-02 12:38:00', 'ibraheem@mailinator.com', NULL, NULL, NULL, 0, 0),
(4, 'Durra', 'durra@mailinator.com', '$2y$10$CSPhr7YQ0c1Ki0CiH4NZYOtK37OBxzCkYbbSEqFHt62gfGYndlTim', NULL, '$2y$10$/dZv3dT5DM3l5LmVcLcLke2UN1X32Tvao7h4N0Jae7rtrXOJYzzMO', NULL, NULL, 1, '2018-09-04 11:11:18', '2018-09-04 11:28:56', '2018-09-02 12:38:19', '2018-09-04 11:28:56', 'durra@mailinator.com', '', NULL, '2018-09-04 11:25:22', 0, 0),
(5, 'Aly El-Degwy', 'aly.eldegwy@gmail.com', '$2y$10$5GOXFHVRS28u0hW3AmmVIecHKHNnYNgZWkNfKz8pQAlGNmHrOCqNq', NULL, NULL, NULL, NULL, 1, '2018-09-04 11:51:52', '2018-09-10 09:48:27', '2018-09-04 11:51:52', '2018-09-10 09:48:48', 'aly.eldegwy@gmail.com', NULL, NULL, '2018-09-10 09:48:28', 0, 0),
(6, '', 'root@sdfsdfss.ss', '$2y$10$5EcVlv8IlcV70JEo4A8jYeUxhw9VKxhExcGUZkDxJAV.BAUIeHJHC', NULL, NULL, NULL, NULL, 1, '2018-09-09 10:45:49', '2018-09-09 10:45:49', '2018-09-09 10:45:48', '2018-09-09 10:45:54', 'root@sdfsdfss.ss', NULL, NULL, NULL, 0, 0),
(7, 'ss', 'll@ll.com', '$2y$10$MHquwrKaiM.D1XpEsrwSc.4wHASClPRPHlhdMXLU4JvHH.eAr7hQS', NULL, NULL, NULL, NULL, 1, '2018-09-09 19:26:06', '2018-09-10 09:57:21', '2018-09-09 19:26:06', '2018-09-10 09:59:06', 'll@ll.com', NULL, NULL, '2018-09-10 09:57:22', 0, 0),
(8, 'hdhdh', 'hhh@hhh.hhh', '$2y$10$IDvc6o1ATotkeIDF0.1cLOGgjJaVPZFOMfNhtEOmbpZXMSdEf8dHy', NULL, '$2y$10$pkeeP8Q7UgVEtw3jHPi6bepGSQBTXk2NlceZtTePHFSiNiJuHROeC', NULL, NULL, 1, '2018-09-10 09:49:11', '2018-09-10 09:49:13', '2018-09-10 09:49:11', '2018-09-10 09:49:13', 'hhh@hhh.hhh', NULL, NULL, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `user_group_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE `user_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`id`, `name`, `code`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Guest', 'guest', 'Default group for guest users.', '2018-09-02 11:24:50', '2018-09-02 11:24:50'),
(2, 'Registered', 'registered', 'Default group for registered users.', '2018-09-02 11:24:50', '2018-09-02 11:24:50');

-- --------------------------------------------------------

--
-- Table structure for table `user_throttle`
--

CREATE TABLE `user_throttle` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `is_suspended` tinyint(1) NOT NULL DEFAULT '0',
  `suspended_at` timestamp NULL DEFAULT NULL,
  `is_banned` tinyint(1) NOT NULL DEFAULT '0',
  `banned_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_throttle`
--

INSERT INTO `user_throttle` (`id`, `user_id`, `ip_address`, `attempts`, `last_attempt_at`, `is_suspended`, `suspended_at`, `is_banned`, `banned_at`) VALUES
(1, 1, '127.0.0.1', 0, NULL, 0, NULL, 0, NULL),
(2, 2, '127.0.0.1', 0, NULL, 0, NULL, 0, NULL),
(3, 3, '127.0.0.1', 0, NULL, 0, NULL, 0, NULL),
(4, 4, '127.0.0.1', 0, NULL, 0, NULL, 0, NULL),
(5, 5, '192.168.1.130', 0, NULL, 0, NULL, 0, NULL),
(6, 5, '::1', 0, '2018-09-09 10:22:35', 0, NULL, 0, NULL),
(7, 1, '192.168.1.108', 0, '2018-09-09 16:16:20', 0, NULL, 0, NULL),
(8, 6, '::1', 0, NULL, 0, NULL, 0, NULL),
(9, 1, '41.234.217.38', 0, NULL, 0, NULL, 0, NULL),
(10, 7, '41.234.217.38', 0, NULL, 0, NULL, 0, NULL),
(11, 5, '41.235.106.132', 0, NULL, 0, NULL, 0, NULL),
(12, 8, '41.235.106.132', 0, NULL, 0, NULL, 0, NULL),
(13, 7, '41.235.106.132', 0, NULL, 0, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_features_items`
--

CREATE TABLE `worcbox_features_items` (
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_features_items`
--

INSERT INTO `worcbox_features_items` (`title`, `description`, `id`, `type`, `sort_order`) VALUES
('جودة محتوى عالية', 'احصل على محتوى أصلي وضع بأسلوب وعناوين مثيرة للاهتمام تجعل القراء يتشوقون إلى معرفة المزيد عنك وعن شركتك.', 2, 'feature', 2),
('السرعة', 'سلم الطلب الان وسيعمل عليه فريقنا لتسليمه بسرعة البرق.', 3, 'feature', 3),
('التحرير مرارا بدون عدد محصور', 'نحن نحترم أنك تعرف عملاءك بشكل أفضل من أي شخص آخر، والتفاصيل الصغيرة التي تجعل نشاطك التجاري فريدًا. إذا كنت تشعر أن المحتوى الذي كتبناه يحتاج إلى تحرير جيد، فكل ما عليك هو إعلامنا وسنستمر في تحسينه حتى تصبح راضيًا.', 4, 'feature', 4),
('بالعمل معنا دون عقود او التزامات وحرية أكبر', 'مع عدم وجود التزامات تعاقدية تأتي حرية إنشاء محتوى من الدرجة الأولى عندما تريد، بالطريقة التي تريدها. لا توجد التزامات ولا تكاليف خفية مع الخدمات لدينا. نحن دائما هنا لنبهر جمهورك المستهدف عندما تحتاجنا.', 5, 'feature', 5),
('متوفرين للخدمة على مدار الساعة', 'نعمل على مدار الساعة وستجدنا عندما تحتاجنا دائما.', 6, 'feature', 6),
('كتاب محتوى مؤهلين', 'فريقنا محترف في فن التقاط الكلمات المكتوبة بشكل صحيح وتحويلها إلى زخرفة نصية ترتبط بالمستهلكين وتقنعهم بخدماتك.', 7, 'feature', 7),
('كتابة التدوينات', 'تتيح لك المدونات المكتوبة ببراعة التفاعل مع القراء في موضوعك. سواء كانت تحاورية أو تثقيفية أو تعليمية أو حتى مدفوعة بالمبيعات وترويجية، نعي المفهوم الذي تريد قوله ونساعدك في تقديمه\r\nعلى ماذا تحصل مع كل تدوين؟\r\n\r\nإدارة كاملة للمدونة: البحث والكتابة والصور والنشر-\r\nتدوينات مكتوبة من قبل خبراء متخصصين في كتابة التدوينات-\r\nالأسلوب المناسب والنغمة-\r\nالمحتوى الذي سيتواصل ويقنع جمهورك المستهدف-\r\nمحتوى صحيح نحويًا-\r\nمحتوى محسن بمحرك البحث باستخدام الكلمات الرئيسية المناسبة-\r\nتنسيق المحتوى السليم-\r\nالتسليم في وقت المحدد بأي شكل تحتاجه (.doc ، .pdf ، إلخ.)', 8, 'tab', 8),
('كتابة المقالات', 'لوريم إيبسوم(Lorem Ipsum) هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر عندما قامت مطبعة مجهولة برص مجموعة من الأحرف بشكل عشوائي أخذتها من نص، لتكوّن كتيّب بمثابة دليل أو مرجع شكلي لهذه الأحرف. خمسة قرون من الزمن لم تقضي على هذا النص، بل انه حتى صار مستخدماً وبشكله الأصلي في الطباعة والتنضيد الإلكتروني. انتشر بشكل كبير في ستينيّات هذا القرن مع إصدار رقائق \"ليتراسيت\" (Letraset) البلاستيكية تحوي مقاطع من هذا النص، وعاد لينتشر مرة أخرى مؤخراَ مع ظهور برامج النشر الإلكتروني مثل \"ألدوس بايج مايكر\" (Aldus PageMaker) والتي حوت أيضاً على نسخ من نص لوريم إيبسوم.', 9, 'tab', 1),
('على الدجوى', 'محرر', 10, 'team', 10),
('شخص جديد', 'مراجع', 11, 'team', 11);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_packages_items`
--

CREATE TABLE `worcbox_packages_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `line_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_packages_items`
--

INSERT INTO `worcbox_packages_items` (`id`, `title`, `description`, `price`, `line_1`, `line_2`, `line_3`) VALUES
(1, 'باقة احترافية', 'هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام \"هنا يوجد محتوى نصي، هنا يوجد محتوى نصي\" فتجعلها تبدو (أي الأحرف) وكأنها نص مقروء. العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل إفتراضي كنموذج عن النص، وإذا قمت بإدخال \"lorem ipsum\" في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.', 550, 'عشرة تدوينات اسبوعية', 'اوصف منتجاتك بإحترافية', 'بدون عقود'),
(2, 'باقة الشركات', 'هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام \"هنا يوجد محتوى نصي، هنا يوجد محتوى نصي\" فتجعلها تبدو (أي الأحرف) وكأنها نص مقروء. العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل إفتراضي كنموذج عن النص، وإذا قمت بإدخال \"lorem ipsum\" في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.', 248, 'تدوينتين اسبوعيتين لموقعك', 'اوصف منتجاتك بإحترافية', 'ابرز الجمل الدعائية الجديدة'),
(3, 'باقة الرياديين', 'هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام \"هنا يوجد محتوى نصي، هنا يوجد محتوى نصي\" فتجعلها تبدو (أي الأحرف) وكأنها نص مقروء. العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل إفتراضي كنموذج عن النص، وإذا قمت بإدخال \"lorem ipsum\" في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.', 150, 'محتوى اخترافى لشركتك', 'اوصف منتجاتك بإحترافية', 'ابرز الجمل الدعائية الجديدة');

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_staticdata_lookups`
--

CREATE TABLE `worcbox_staticdata_lookups` (
  `id` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `key` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_staticdata_lookups`
--

INSERT INTO `worcbox_staticdata_lookups` (`id`, `code`, `key`, `value`) VALUES
(2, 'contact.ksa.address', 'الرذايا، المملكة العربية السعودية', 'الرذايا، المملكة العربية السعودية'),
(3, 'contact.ksa.phone', '+9715422222', '+9715422222'),
(4, 'contact.ksa.fax', '+96655555', '+96655555'),
(5, 'contact.ksa.email', 'contact@siyaq.com', 'contact@siyaq.com'),
(6, 'contact.egypt.address', 'جامعة الدول العربية، الدقى، الجيزة', 'جامعة الدول العربية، الدقى، الجيزة'),
(7, 'contact.egypt.phone', '+20102456587', '+20102456587'),
(8, 'contact.egypt.fax', '+2025642155', '+2025642155'),
(9, 'contact.egypt.email', 'info@siyaq.com', 'info@siyaq.com'),
(10, 'footer.links.facebook', 'http://facebook.com', 'http://facebook.com'),
(11, 'footer.links.twitter', 'http://twitter.com', 'http://twitter.com'),
(12, 'footer.links.google', 'http://google.com', 'http://google.com'),
(13, 'footer.links.tumblr', 'https://www.tumblr.com/', 'https://www.tumblr.com/'),
(14, 'footer.about', 'عن سياق', 'سياق هو اول منصة عربية لتقديم خدمات انشاء المحتوى بشكل احترافى، سواءً تريد ان محتوى لمدونتك، لموقعك أو تفضل المقالات لأغراض التسويق');

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_syaq_audience_genders`
--

CREATE TABLE `worcbox_syaq_audience_genders` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_syaq_audience_genders`
--

INSERT INTO `worcbox_syaq_audience_genders` (`id`, `name`, `active`) VALUES
(1, 'ذكور', 1);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_syaq_fields`
--

CREATE TABLE `worcbox_syaq_fields` (
  `id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_syaq_fields`
--

INSERT INTO `worcbox_syaq_fields` (`id`, `name`, `active`) VALUES
(1, 'تكنولوجيا', 1);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_syaq_orders`
--

CREATE TABLE `worcbox_syaq_orders` (
  `id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `words_count` int(11) NOT NULL,
  `days_count` int(11) NOT NULL,
  `high_quality` tinyint(1) NOT NULL,
  `topic` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_id` int(11) NOT NULL,
  `audience_gender_id` int(11) DEFAULT NULL,
  `speech_format_id` int(11) DEFAULT NULL,
  `title_field_id` int(11) DEFAULT NULL,
  `typing_mode_id` int(11) DEFAULT NULL,
  `audience_identification` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewer_user_id` int(11) DEFAULT NULL,
  `implementer_user_id` int(11) DEFAULT NULL,
  `express` tinyint(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total` double NOT NULL DEFAULT '0',
  `test` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_syaq_orders`
--

INSERT INTO `worcbox_syaq_orders` (`id`, `service_id`, `quantity`, `words_count`, `days_count`, `high_quality`, `topic`, `field_id`, `audience_gender_id`, `speech_format_id`, `title_field_id`, `typing_mode_id`, `audience_identification`, `notes`, `created_at`, `updated_at`, `status`, `reviewer_user_id`, `implementer_user_id`, `express`, `user_id`, `total`, `test`) VALUES
(5, 2, 1, 200, 12, 0, 'd', 1, 1, 2, 1, 2, 'dd', '', '2018-09-09 19:26:13', '2018-09-10 11:52:47', 'implementation_done', NULL, NULL, 0, 7, 10, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_syaq_order_attachments`
--

CREATE TABLE `worcbox_syaq_order_attachments` (
  `id` int(10) UNSIGNED NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `implementer_user_id` int(11) NOT NULL,
  `reviewer_user_id` int(11) DEFAULT NULL,
  `order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_syaq_order_attachments`
--

INSERT INTO `worcbox_syaq_order_attachments` (`id`, `note`, `created_at`, `updated_at`, `implementer_user_id`, `reviewer_user_id`, `order_id`) VALUES
(6, NULL, '2018-09-10 11:52:47', '2018-09-10 11:52:47', 5, NULL, 5);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_syaq_services`
--

CREATE TABLE `worcbox_syaq_services` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `minimum_words_count` int(10) UNSIGNED NOT NULL,
  `basic_cost` double NOT NULL,
  `basic_duration_in_days` int(10) UNSIGNED NOT NULL,
  `express_cost` double DEFAULT NULL,
  `express_duration_in_days` int(10) UNSIGNED DEFAULT NULL,
  `high_quality_cost` double DEFAULT NULL,
  `extra_block_words_count` int(10) UNSIGNED DEFAULT NULL,
  `extra_block_cost` double DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_syaq_services`
--

INSERT INTO `worcbox_syaq_services` (`id`, `name`, `description`, `minimum_words_count`, `basic_cost`, `basic_duration_in_days`, `express_cost`, `express_duration_in_days`, `high_quality_cost`, `extra_block_words_count`, `extra_block_cost`, `active`) VALUES
(1, 'وصف منتج', 'وصف وصف منتج', 300, 50, 21, 10, 10, 15, 10, 13, 1),
(2, 'مقال صحفى', 'وصف مقال صحفى', 200, 10, 12, 15, 5, 8, 25, 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_syaq_speech_formats`
--

CREATE TABLE `worcbox_syaq_speech_formats` (
  `id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_syaq_speech_formats`
--

INSERT INTO `worcbox_syaq_speech_formats` (`id`, `name`, `active`) VALUES
(1, 'عربية فصحى', 1),
(2, 'عامية', 1);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_syaq_title_fields`
--

CREATE TABLE `worcbox_syaq_title_fields` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_syaq_title_fields`
--

INSERT INTO `worcbox_syaq_title_fields` (`id`, `name`, `active`) VALUES
(1, 'عنوان نصى', 1),
(2, 'تعبئة جماهير', 1);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_syaq_typing_modes`
--

CREATE TABLE `worcbox_syaq_typing_modes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_syaq_typing_modes`
--

INSERT INTO `worcbox_syaq_typing_modes` (`id`, `name`, `active`) VALUES
(1, 'كتابة حرة', 1),
(2, 'عمودية', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `backend_access_log`
--
ALTER TABLE `backend_access_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `backend_users`
--
ALTER TABLE `backend_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login_unique` (`login`),
  ADD UNIQUE KEY `email_unique` (`email`),
  ADD KEY `act_code_index` (`activation_code`),
  ADD KEY `reset_code_index` (`reset_password_code`),
  ADD KEY `admin_role_index` (`role_id`);

--
-- Indexes for table `backend_users_groups`
--
ALTER TABLE `backend_users_groups`
  ADD PRIMARY KEY (`user_id`,`user_group_id`);

--
-- Indexes for table `backend_user_groups`
--
ALTER TABLE `backend_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name_unique` (`name`),
  ADD KEY `code_index` (`code`);

--
-- Indexes for table `backend_user_preferences`
--
ALTER TABLE `backend_user_preferences`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_item_index` (`user_id`,`namespace`,`group`,`item`);

--
-- Indexes for table `backend_user_roles`
--
ALTER TABLE `backend_user_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `role_unique` (`name`),
  ADD KEY `role_code_index` (`code`);

--
-- Indexes for table `backend_user_throttle`
--
ALTER TABLE `backend_user_throttle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `backend_user_throttle_user_id_index` (`user_id`),
  ADD KEY `backend_user_throttle_ip_address_index` (`ip_address`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD UNIQUE KEY `cache_key_unique` (`key`);

--
-- Indexes for table `cms_theme_data`
--
ALTER TABLE `cms_theme_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cms_theme_data_theme_index` (`theme`);

--
-- Indexes for table `cms_theme_logs`
--
ALTER TABLE `cms_theme_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cms_theme_logs_type_index` (`type`),
  ADD KEY `cms_theme_logs_theme_index` (`theme`),
  ADD KEY `cms_theme_logs_user_id_index` (`user_id`);

--
-- Indexes for table `deferred_bindings`
--
ALTER TABLE `deferred_bindings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deferred_bindings_master_type_index` (`master_type`),
  ADD KEY `deferred_bindings_master_field_index` (`master_field`),
  ADD KEY `deferred_bindings_slave_type_index` (`slave_type`),
  ADD KEY `deferred_bindings_slave_id_index` (`slave_id`),
  ADD KEY `deferred_bindings_session_key_index` (`session_key`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flynsarmy_sociallogin_user_providers`
--
ALTER TABLE `flynsarmy_sociallogin_user_providers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `provider_id_token_index` (`provider_id`,`provider_token`),
  ADD KEY `flynsarmy_sociallogin_user_providers_user_id_index` (`user_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_reserved_at_index` (`queue`,`reserved_at`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rainlab_user_mail_blockers`
--
ALTER TABLE `rainlab_user_mail_blockers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rainlab_user_mail_blockers_email_index` (`email`),
  ADD KEY `rainlab_user_mail_blockers_template_index` (`template`),
  ADD KEY `rainlab_user_mail_blockers_user_id_index` (`user_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `system_event_logs`
--
ALTER TABLE `system_event_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `system_event_logs_level_index` (`level`);

--
-- Indexes for table `system_files`
--
ALTER TABLE `system_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `system_files_field_index` (`field`),
  ADD KEY `system_files_attachment_id_index` (`attachment_id`),
  ADD KEY `system_files_attachment_type_index` (`attachment_type`);

--
-- Indexes for table `system_mail_layouts`
--
ALTER TABLE `system_mail_layouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_mail_partials`
--
ALTER TABLE `system_mail_partials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_mail_templates`
--
ALTER TABLE `system_mail_templates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `system_mail_templates_layout_id_index` (`layout_id`);

--
-- Indexes for table `system_parameters`
--
ALTER TABLE `system_parameters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_index` (`namespace`,`group`,`item`);

--
-- Indexes for table `system_plugin_history`
--
ALTER TABLE `system_plugin_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `system_plugin_history_code_index` (`code`),
  ADD KEY `system_plugin_history_type_index` (`type`);

--
-- Indexes for table `system_plugin_versions`
--
ALTER TABLE `system_plugin_versions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `system_plugin_versions_code_index` (`code`);

--
-- Indexes for table `system_request_logs`
--
ALTER TABLE `system_request_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_revisions`
--
ALTER TABLE `system_revisions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `system_revisions_revisionable_id_revisionable_type_index` (`revisionable_id`,`revisionable_type`),
  ADD KEY `system_revisions_user_id_index` (`user_id`),
  ADD KEY `system_revisions_field_index` (`field`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `system_settings_item_index` (`item`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_login_unique` (`username`),
  ADD KEY `users_activation_code_index` (`activation_code`),
  ADD KEY `users_reset_password_code_index` (`reset_password_code`),
  ADD KEY `users_login_index` (`username`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`user_id`,`user_group_id`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_groups_code_index` (`code`);

--
-- Indexes for table `user_throttle`
--
ALTER TABLE `user_throttle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_throttle_user_id_index` (`user_id`),
  ADD KEY `user_throttle_ip_address_index` (`ip_address`);

--
-- Indexes for table `worcbox_features_items`
--
ALTER TABLE `worcbox_features_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_packages_items`
--
ALTER TABLE `worcbox_packages_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_staticdata_lookups`
--
ALTER TABLE `worcbox_staticdata_lookups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_syaq_audience_genders`
--
ALTER TABLE `worcbox_syaq_audience_genders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_syaq_fields`
--
ALTER TABLE `worcbox_syaq_fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_syaq_orders`
--
ALTER TABLE `worcbox_syaq_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_syaq_order_attachments`
--
ALTER TABLE `worcbox_syaq_order_attachments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_syaq_services`
--
ALTER TABLE `worcbox_syaq_services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_syaq_speech_formats`
--
ALTER TABLE `worcbox_syaq_speech_formats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_syaq_title_fields`
--
ALTER TABLE `worcbox_syaq_title_fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_syaq_typing_modes`
--
ALTER TABLE `worcbox_syaq_typing_modes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `backend_access_log`
--
ALTER TABLE `backend_access_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `backend_users`
--
ALTER TABLE `backend_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `backend_user_groups`
--
ALTER TABLE `backend_user_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `backend_user_preferences`
--
ALTER TABLE `backend_user_preferences`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `backend_user_roles`
--
ALTER TABLE `backend_user_roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `backend_user_throttle`
--
ALTER TABLE `backend_user_throttle`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `cms_theme_data`
--
ALTER TABLE `cms_theme_data`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cms_theme_logs`
--
ALTER TABLE `cms_theme_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deferred_bindings`
--
ALTER TABLE `deferred_bindings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `flynsarmy_sociallogin_user_providers`
--
ALTER TABLE `flynsarmy_sociallogin_user_providers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rainlab_user_mail_blockers`
--
ALTER TABLE `rainlab_user_mail_blockers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_event_logs`
--
ALTER TABLE `system_event_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=397;

--
-- AUTO_INCREMENT for table `system_files`
--
ALTER TABLE `system_files`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `system_mail_layouts`
--
ALTER TABLE `system_mail_layouts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `system_mail_partials`
--
ALTER TABLE `system_mail_partials`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `system_mail_templates`
--
ALTER TABLE `system_mail_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `system_parameters`
--
ALTER TABLE `system_parameters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `system_plugin_history`
--
ALTER TABLE `system_plugin_history`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=359;

--
-- AUTO_INCREMENT for table `system_plugin_versions`
--
ALTER TABLE `system_plugin_versions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `system_request_logs`
--
ALTER TABLE `system_request_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_revisions`
--
ALTER TABLE `system_revisions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_throttle`
--
ALTER TABLE `user_throttle`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `worcbox_features_items`
--
ALTER TABLE `worcbox_features_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `worcbox_packages_items`
--
ALTER TABLE `worcbox_packages_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `worcbox_staticdata_lookups`
--
ALTER TABLE `worcbox_staticdata_lookups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `worcbox_syaq_audience_genders`
--
ALTER TABLE `worcbox_syaq_audience_genders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `worcbox_syaq_fields`
--
ALTER TABLE `worcbox_syaq_fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `worcbox_syaq_orders`
--
ALTER TABLE `worcbox_syaq_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `worcbox_syaq_order_attachments`
--
ALTER TABLE `worcbox_syaq_order_attachments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `worcbox_syaq_services`
--
ALTER TABLE `worcbox_syaq_services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `worcbox_syaq_speech_formats`
--
ALTER TABLE `worcbox_syaq_speech_formats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `worcbox_syaq_title_fields`
--
ALTER TABLE `worcbox_syaq_title_fields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `worcbox_syaq_typing_modes`
--
ALTER TABLE `worcbox_syaq_typing_modes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
