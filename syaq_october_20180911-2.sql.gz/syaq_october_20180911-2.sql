-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 13, 2018 at 01:40 PM
-- Server version: 5.7.24-0ubuntu0.16.04.1
-- PHP Version: 7.0.32-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `syaq_october_20180911-2`
--

-- --------------------------------------------------------

--
-- Table structure for table `backend_access_log`
--

CREATE TABLE `backend_access_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `backend_users`
--

CREATE TABLE `backend_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activation_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `persist_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_password_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `is_activated` tinyint(1) NOT NULL DEFAULT '0',
  `role_id` int(10) UNSIGNED DEFAULT NULL,
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backend_users`
--

INSERT INTO `backend_users` (`id`, `first_name`, `last_name`, `login`, `email`, `password`, `activation_code`, `persist_code`, `reset_password_code`, `permissions`, `is_activated`, `role_id`, `activated_at`, `last_login`, `created_at`, `updated_at`, `is_superuser`) VALUES
(1, 'Mostafa', 'El-Gazzar', 'admin', 'mostafa@worcbox.com', '$2y$10$jP9Cs9hJ1zBXxUyRSQjCbuKZAPUMGZ3nal2GsIEiXqeODivFD47bq', NULL, '$2y$10$hsfJIBER0KvVwtNwOuorZOhLhi2CGMeiPYndZcpk/f0dxZQYptIIu', NULL, '', 1, 2, NULL, '2018-09-10 12:34:37', '2018-08-14 08:42:05', '2018-09-10 12:34:37', 1),
(2, 'mm', 'mm', 'mmmm', 'mmm@mmm.mmm', '$2y$10$meMcNFRaDz1ZHcJe9uHn8uqT38G1MHMGTuBbc7Bd2dgCHuTl48XSG', NULL, NULL, NULL, '', 0, 4, NULL, '2018-09-11 08:59:09', '2018-09-03 10:52:31', '2018-09-11 08:59:17', 0),
(3, 'Aly', 'El-Degwy', 'aly', 'aly@mailinator.com', '$2y$10$0ik/6O/R9jQlD0qPft6iMuPBJBkW98bwNksUugXnyrkWr7k0QVH6S', NULL, NULL, NULL, '', 0, 5, NULL, '2018-09-11 09:00:06', '2018-09-05 11:28:56', '2018-09-11 09:04:05', 0),
(4, 'Mostafa', 'El-Gazzar', 'mostafa', 'mostafa@mailinator.com', '$2y$10$PqfwMIyof4U1psSgZeKq1ugtTxwhwqhu.8t48cG1rprjMwCQCQOkG', NULL, NULL, NULL, '', 0, 4, NULL, '2018-09-11 08:59:21', '2018-09-05 11:29:33', '2018-09-11 09:00:02', 0),
(5, 'Sally', 'Mohamed', 'manager', 'manager@mailinator.com', '$2y$10$9XA5slAS80L33cSyYjAlnua1smvVdirsxxMOl.Igsnz0EDHfdmg1.', NULL, '$2y$10$iy9TJGxcI0F.L7GiI3Lp3uDupbBDI6ousJvWLxZeydQswRPOm3a.e', NULL, '', 0, 6, NULL, '2018-09-11 09:04:13', '2018-09-06 11:54:51', '2018-09-11 09:04:13', 0),
(6, 'CMS', 'Manager', 'cms', 'cms@syaq.com', '$2y$10$evojVOO49miDlWLUuQ0Fse.FKz/HQcVunHtzYCwM73U0mzoefYzIW', NULL, NULL, NULL, '', 0, 7, NULL, '2018-09-11 08:33:55', '2018-09-11 08:33:34', '2018-09-11 08:57:41', 0);

-- --------------------------------------------------------

--
-- Table structure for table `backend_users_groups`
--

CREATE TABLE `backend_users_groups` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `user_group_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backend_users_groups`
--

INSERT INTO `backend_users_groups` (`user_id`, `user_group_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `backend_user_groups`
--

CREATE TABLE `backend_user_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_new_user_default` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backend_user_groups`
--

INSERT INTO `backend_user_groups` (`id`, `name`, `created_at`, `updated_at`, `code`, `description`, `is_new_user_default`) VALUES
(1, 'Owners', '2018-08-14 08:42:04', '2018-08-14 08:42:04', 'owners', 'Default group for website owners.', 0);

-- --------------------------------------------------------

--
-- Table structure for table `backend_user_preferences`
--

CREATE TABLE `backend_user_preferences` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `namespace` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backend_user_preferences`
--

INSERT INTO `backend_user_preferences` (`id`, `user_id`, `namespace`, `group`, `item`, `value`) VALUES
(1, 1, 'backend', 'backend', 'preferences', '{\"locale\":\"en\",\"fallback_locale\":\"en\",\"timezone\":\"UTC\",\"editor_font_size\":\"16\",\"editor_word_wrap\":\"fluid\",\"editor_code_folding\":\"markbeginend\",\"editor_tab_size\":\"4\",\"editor_theme\":\"chrome\",\"editor_show_invisibles\":\"0\",\"editor_highlight_active_line\":\"1\",\"editor_use_hard_tabs\":\"1\",\"editor_show_gutter\":\"1\",\"editor_auto_closing\":\"1\",\"editor_autocompletion\":\"live\",\"editor_enable_snippets\":\"0\",\"editor_display_indent_guides\":\"0\",\"editor_show_print_margin\":\"0\",\"user_id\":\"1\"}'),
(2, 1, 'backend', 'reportwidgets', 'dashboard', '{\"welcome\":{\"class\":\"Backend\\\\ReportWidgets\\\\Welcome\",\"sortOrder\":\"73\",\"configuration\":{\"ocWidgetWidth\":6}},\"systemStatus\":{\"class\":\"System\\\\ReportWidgets\\\\Status\",\"sortOrder\":\"74\",\"configuration\":{\"ocWidgetWidth\":6}},\"activeTheme\":{\"class\":\"Cms\\\\ReportWidgets\\\\ActiveTheme\",\"sortOrder\":\"75\",\"configuration\":{\"title\":\"Website\",\"ocWidgetWidth\":4,\"ocWidgetNewRow\":null}},\"report_container_dashboard_5\":{\"class\":\"Worcbox\\\\Syaq\\\\Widgets\\\\RunningOrders\",\"configuration\":{\"type\":\"new\",\"ocWidgetWidth\":\"3\",\"ocWidgetNewRow\":null},\"sortOrder\":\"50\"},\"report_container_dashboard_6\":{\"class\":\"Worcbox\\\\Syaq\\\\Widgets\\\\RunningOrders\",\"configuration\":{\"type\":\"running\",\"ocWidgetWidth\":\"3\",\"ocWidgetNewRow\":null},\"sortOrder\":\"60\"},\"report_container_dashboard_7\":{\"class\":\"Worcbox\\\\Syaq\\\\Widgets\\\\RunningOrders\",\"configuration\":{\"type\":\"finished\",\"ocWidgetWidth\":\"3\",\"ocWidgetNewRow\":null},\"sortOrder\":\"70\"},\"report_container_dashboard_8\":{\"class\":\"Worcbox\\\\Syaq\\\\Widgets\\\\RunningOrders\",\"configuration\":{\"type\":\"archived\",\"ocWidgetWidth\":\"3\",\"ocWidgetNewRow\":null},\"sortOrder\":\"72\"}}'),
(3, 6, 'backend', 'reportwidgets', 'dashboard', '{\"welcome\":{\"class\":\"Backend\\\\ReportWidgets\\\\Welcome\",\"sortOrder\":50,\"configuration\":{\"ocWidgetWidth\":6}},\"systemStatus\":{\"class\":\"System\\\\ReportWidgets\\\\Status\",\"sortOrder\":60,\"configuration\":{\"ocWidgetWidth\":6}}}');

-- --------------------------------------------------------

--
-- Table structure for table `backend_user_roles`
--

CREATE TABLE `backend_user_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `is_system` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backend_user_roles`
--

INSERT INTO `backend_user_roles` (`id`, `name`, `code`, `description`, `permissions`, `is_system`, `created_at`, `updated_at`) VALUES
(1, 'Publisher', 'publisher', 'Site editor with access to publishing tools.', '', 1, '2018-08-14 08:42:04', '2018-08-14 08:42:04'),
(2, 'Developer', 'developer', 'Site administrator with access to developer tools.', '', 1, '2018-08-14 08:42:04', '2018-08-14 08:42:04'),
(3, 'mmmm', 'mmm', '', '{\"rainlab.pages.manage_pages\":\"1\",\"rainlab.pages.manage_menus\":\"1\",\"rainlab.pages.access_snippets\":\"1\",\"rainlab.pages.manage_content\":\"1\",\"worcbox.feature.list\":\"1\",\"worcbox.syaq.orders.implementer\":\"1\",\"worcbox.syaq.orders.edit\":\"1\"}', 0, '2018-09-03 10:51:51', '2018-09-04 08:19:50'),
(4, 'Implementer', 'orders-implementer', '', '{\"worcbox.syaq.orders.createAttachment\":\"1\",\"worcbox.syaq.orders.list.running\":\"1\"}', 0, '2018-09-04 07:15:56', '2018-09-11 08:58:15'),
(5, 'Reveiewer', 'reviewer', '', '{\"worcbox.syaq.orders.addAttachmentNote\":\"1\",\"worcbox.syaq.orders.list.running\":\"1\"}', 0, '2018-09-05 11:26:14', '2018-09-11 09:01:36'),
(6, 'Content Manager', 'content-manager', '', '{\"worcbox.syaq.orders.createAttachment\":\"1\",\"worcbox.syaq.orders.addAttachmentNote\":\"1\",\"worcbox.syaq.orders.list.finished\":\"1\",\"worcbox.syaq.orders.edit\":\"1\",\"worcbox.syaq.orders.list.new\":\"1\",\"worcbox.syaq.orders.list.running\":\"1\",\"worcbox.syaq.orders.list.archived\":\"1\"}', 0, '2018-09-06 11:53:52', '2018-09-11 09:03:57'),
(7, 'CMS Manager', 'cms-manager', '', '{\"rainlab.pages.access_snippets\":\"1\",\"rainlab.pages.manage_content\":\"1\",\"rainlab.pages.manage_menus\":\"1\",\"rainlab.pages.manage_pages\":\"1\",\"worcbox.staticData.list\":\"1\",\"worcbox.staticData.create\":\"1\",\"worcbox.packages.list\":\"1\",\"worcbox.packages.create\":\"1\",\"worcbox.feature.list\":\"1\",\"worcbox.feature.create\":\"1\",\"backend.access_dashboard\":\"1\",\"system.manage_mail_settings\":\"1\",\"system.manage_mail_templates\":\"1\",\"rainlab.users.access_users\":\"1\",\"rainlab.users.access_groups\":\"1\",\"rainlab.users.access_settings\":\"1\",\"rainlab.users.impersonate_user\":\"1\",\"worcbox.syaq.orderSettings.edit\":\"1\",\"vojtasvoboda.reviews.reviews\":\"1\",\"vojtasvoboda.reviews.categories\":\"1\"}', 0, '2018-09-11 08:32:50', '2018-09-11 08:55:57');

-- --------------------------------------------------------

--
-- Table structure for table `backend_user_throttle`
--

CREATE TABLE `backend_user_throttle` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `is_suspended` tinyint(1) NOT NULL DEFAULT '0',
  `suspended_at` timestamp NULL DEFAULT NULL,
  `is_banned` tinyint(1) NOT NULL DEFAULT '0',
  `banned_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backend_user_throttle`
--

INSERT INTO `backend_user_throttle` (`id`, `user_id`, `ip_address`, `attempts`, `last_attempt_at`, `is_suspended`, `suspended_at`, `is_banned`, `banned_at`) VALUES
(1, 1, '127.0.0.1', 0, NULL, 0, NULL, 0, NULL),
(2, 1, '192.168.1.130', 0, NULL, 0, NULL, 0, NULL),
(3, 2, '192.168.1.130', 0, NULL, 0, NULL, 0, NULL),
(4, 3, '192.168.1.130', 0, NULL, 0, NULL, 0, NULL),
(5, 4, '192.168.1.130', 0, NULL, 0, NULL, 0, NULL),
(6, 5, '192.168.1.130', 0, NULL, 0, NULL, 0, NULL),
(7, 4, '127.0.0.1', 0, NULL, 0, NULL, 0, NULL),
(8, 3, '::1', 0, NULL, 0, NULL, 0, NULL),
(9, 1, '::1', 0, NULL, 0, NULL, 0, NULL),
(10, 1, '192.168.1.108', 0, NULL, 0, NULL, 0, NULL),
(11, 5, '192.168.1.108', 0, NULL, 0, NULL, 0, NULL),
(12, 4, '192.168.1.108', 0, NULL, 0, NULL, 0, NULL),
(13, 3, '192.168.1.108', 0, NULL, 0, NULL, 0, NULL),
(14, 5, '::1', 0, NULL, 0, NULL, 0, NULL),
(15, 1, '192.168.1.106', 0, NULL, 0, NULL, 0, NULL),
(16, 6, '::1', 0, NULL, 0, NULL, 0, NULL),
(17, 2, '::1', 0, NULL, 0, NULL, 0, NULL),
(18, 4, '::1', 0, NULL, 0, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_theme_data`
--

CREATE TABLE `cms_theme_data` (
  `id` int(10) UNSIGNED NOT NULL,
  `theme` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_theme_logs`
--

CREATE TABLE `cms_theme_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `theme` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `old_content` longtext COLLATE utf8mb4_unicode_ci,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deferred_bindings`
--

CREATE TABLE `deferred_bindings` (
  `id` int(10) UNSIGNED NOT NULL,
  `master_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `master_field` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slave_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slave_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_bind` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `deferred_bindings`
--

INSERT INTO `deferred_bindings` (`id`, `master_type`, `master_field`, `slave_type`, `slave_id`, `session_key`, `is_bind`, `created_at`, `updated_at`) VALUES
(3, 'Worcbox\\Features\\Models\\Item', 'icon', 'System\\Models\\File', '3', '9cTRe5hdwZxDkdklB6cucDwfHOiP9pK67arnEfdH', 1, '2018-09-02 11:39:10', '2018-09-02 11:39:10'),
(4, 'Worcbox\\Features\\Models\\Item', 'icon', 'System\\Models\\File', '4', 'prkSOnpntY573AV0iYyyCdzP6WJoyPJ206VDwdKx', 1, '2018-09-02 11:41:46', '2018-09-02 11:41:46');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` int(10) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci,
  `failed_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `flynsarmy_sociallogin_user_providers`
--

CREATE TABLE `flynsarmy_sociallogin_user_providers` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `provider_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `provider_token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `flynsarmy_sociallogin_user_providers`
--

INSERT INTO `flynsarmy_sociallogin_user_providers` (`id`, `user_id`, `provider_id`, `provider_token`) VALUES
(2, 7, 'Facebook', 'EAAKjaoReoUkBAFQfaRatFZAXMcXB3e7avZB3opA8Bw5ertNfw1Hwsp40aFOHKWoaoA4dZBCgJADdH3JOCDxzFSpZB1qUoe5oFTwMDCHFvAZC8zPYuHjqRhIs6SxLpeNlVyxeCtH6KbV5DKMsPQZBR7Iuc5M1TMNEEIvKUHveuZBEwZDZD');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2013_10_01_000001_Db_Deferred_Bindings', 1),
(2, '2013_10_01_000002_Db_System_Files', 1),
(3, '2013_10_01_000003_Db_System_Plugin_Versions', 1),
(4, '2013_10_01_000004_Db_System_Plugin_History', 1),
(5, '2013_10_01_000005_Db_System_Settings', 1),
(6, '2013_10_01_000006_Db_System_Parameters', 1),
(7, '2013_10_01_000007_Db_System_Add_Disabled_Flag', 1),
(8, '2013_10_01_000008_Db_System_Mail_Templates', 1),
(9, '2013_10_01_000009_Db_System_Mail_Layouts', 1),
(10, '2014_10_01_000010_Db_Jobs', 1),
(11, '2014_10_01_000011_Db_System_Event_Logs', 1),
(12, '2014_10_01_000012_Db_System_Request_Logs', 1),
(13, '2014_10_01_000013_Db_System_Sessions', 1),
(14, '2015_10_01_000014_Db_System_Mail_Layout_Rename', 1),
(15, '2015_10_01_000015_Db_System_Add_Frozen_Flag', 1),
(16, '2015_10_01_000016_Db_Cache', 1),
(17, '2015_10_01_000017_Db_System_Revisions', 1),
(18, '2015_10_01_000018_Db_FailedJobs', 1),
(19, '2016_10_01_000019_Db_System_Plugin_History_Detail_Text', 1),
(20, '2016_10_01_000020_Db_System_Timestamp_Fix', 1),
(21, '2017_08_04_121309_Db_Deferred_Bindings_Add_Index_Session', 1),
(22, '2017_10_01_000021_Db_System_Sessions_Update', 1),
(23, '2017_10_01_000022_Db_Jobs_FailedJobs_Update', 1),
(24, '2017_10_01_000023_Db_System_Mail_Partials', 1),
(25, '2013_10_01_000001_Db_Backend_Users', 2),
(26, '2013_10_01_000002_Db_Backend_User_Groups', 2),
(27, '2013_10_01_000003_Db_Backend_Users_Groups', 2),
(28, '2013_10_01_000004_Db_Backend_User_Throttle', 2),
(29, '2014_01_04_000005_Db_Backend_User_Preferences', 2),
(30, '2014_10_01_000006_Db_Backend_Access_Log', 2),
(31, '2014_10_01_000007_Db_Backend_Add_Description_Field', 2),
(32, '2015_10_01_000008_Db_Backend_Add_Superuser_Flag', 2),
(33, '2016_10_01_000009_Db_Backend_Timestamp_Fix', 2),
(34, '2017_10_01_000010_Db_Backend_User_Roles', 2),
(35, '2014_10_01_000001_Db_Cms_Theme_Data', 3),
(36, '2016_10_01_000002_Db_Cms_Timestamp_Fix', 3),
(37, '2017_10_01_000003_Db_Cms_Theme_Logs', 3);

-- --------------------------------------------------------

--
-- Table structure for table `rainlab_user_mail_blockers`
--

CREATE TABLE `rainlab_user_mail_blockers` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci,
  `last_activity` int(11) DEFAULT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_event_logs`
--

CREATE TABLE `system_event_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `level` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `details` mediumtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_files`
--

CREATE TABLE `system_files` (
  `id` int(10) UNSIGNED NOT NULL,
  `disk_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int(11) NOT NULL,
  `content_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_files`
--

INSERT INTO `system_files` (`id`, `disk_name`, `file_name`, `file_size`, `content_type`, `title`, `description`, `field`, `attachment_id`, `attachment_type`, `is_public`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, '5b8bd4bd0869d480499582.png', 'logo-syaq.png', 20181, 'image/png', NULL, NULL, 'logo', '1', 'Backend\\Models\\BrandSetting', 1, 1, '2018-09-02 10:17:01', '2018-09-02 10:17:20'),
(6, '5b8bf754a7b01365387590.png', 'shape@2x-1.png', 1392, 'image/png', NULL, NULL, 'icon', '2', 'Worcbox\\Features\\Models\\Item', 1, 6, '2018-09-02 12:44:36', '2018-09-02 12:44:37'),
(7, '5b8bf76b221a9522281692.png', 'power@2x-1.png', 2622, 'image/png', NULL, NULL, 'icon', '3', 'Worcbox\\Features\\Models\\Item', 1, 7, '2018-09-02 12:44:59', '2018-09-02 12:45:00'),
(8, '5b8bf77fd61f1604909012.png', 'target-2-2@2x-1.png', 6701, 'image/png', NULL, NULL, 'icon', '4', 'Worcbox\\Features\\Models\\Item', 1, 8, '2018-09-02 12:45:19', '2018-09-02 12:45:20'),
(9, '5b8bf7a3c4172064231692.png', 'add-anchor-point@2x-1.png', 1710, 'image/png', NULL, NULL, 'icon', '5', 'Worcbox\\Features\\Models\\Item', 1, 9, '2018-09-02 12:45:55', '2018-09-02 12:45:56'),
(10, '5b8bf7b309e8a534225531.png', 'time@2x-1.png', 3420, 'image/png', NULL, NULL, 'icon', '6', 'Worcbox\\Features\\Models\\Item', 1, 10, '2018-09-02 12:46:11', '2018-09-02 12:46:11'),
(11, '5b8bf7c5ba790432220240.png', 'shape_2@2x-1.png', 3098, 'image/png', NULL, NULL, 'icon', '7', 'Worcbox\\Features\\Models\\Item', 1, 11, '2018-09-02 12:46:29', '2018-09-02 12:46:30'),
(12, '5b8d126f1be3e627420569.png', 'group-2@2x.png', 127149, 'image/png', NULL, NULL, 'icon', '8', 'Worcbox\\Features\\Models\\Item', 1, 12, '2018-09-03 08:52:31', '2018-09-03 08:52:35'),
(13, '5b8d1ae74cbda375337558.png', 'group-2@2x.png', 127149, 'image/png', NULL, NULL, 'icon', '9', 'Worcbox\\Features\\Models\\Item', 1, 13, '2018-09-03 09:28:39', '2018-09-03 09:28:40'),
(14, '5b95252522d66834199847.jpg', 'man-629062_960_720.jpg', 73564, 'image/jpeg', NULL, NULL, 'icon', '10', 'Worcbox\\Features\\Models\\Item', 1, 14, '2018-09-09 11:50:29', '2018-09-09 11:50:31'),
(15, '5b9527fb94f90896697648.xlsx', 'PHP Course Content.xlsx', 6299, 'application/octet-stream', NULL, NULL, 'content', '1', 'Worcbox\\Syaq\\Models\\OrderAttachment', 1, 15, '2018-09-09 12:02:35', '2018-09-09 12:02:38'),
(16, '5b952a8b08234681638579.jpg', 'ben-knapen-906550_960_720.jpg', 104691, 'image/jpeg', NULL, NULL, 'icon', '11', 'Worcbox\\Features\\Models\\Item', 1, 16, '2018-09-09 12:13:31', '2018-09-09 12:13:32'),
(17, '5b952c2aa0ee3882106302.docx', 'RoboMind_syllabus.docx', 12819, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', NULL, NULL, 'content', '2', 'Worcbox\\Syaq\\Models\\OrderAttachment', 1, 17, '2018-09-09 12:20:26', '2018-09-09 12:20:28'),
(18, '5b952def00ed5976671076.docx', 'RoboMind_syllabus.docx', 12819, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', NULL, NULL, 'content', '3', 'Worcbox\\Syaq\\Models\\OrderAttachment', 1, 18, '2018-09-09 12:27:59', '2018-09-09 12:28:00'),
(19, '5b9530393fe09326092196.docx', 'Clear goals-technical.docx', 13145, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', NULL, NULL, 'content', '5', 'Worcbox\\Syaq\\Models\\OrderAttachment', 1, 19, '2018-09-09 12:37:45', '2018-09-09 12:37:47'),
(20, '5b965cde0da13511634656.jpg', 'user_id_7_avatar1wsORG.jpg', 523201, 'image/jpeg', NULL, NULL, 'avatar', '7', 'RainLab\\User\\Models\\User', 1, 20, '2018-09-10 10:00:30', '2018-09-10 10:00:30');

-- --------------------------------------------------------

--
-- Table structure for table `system_mail_layouts`
--

CREATE TABLE `system_mail_layouts` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_html` text COLLATE utf8mb4_unicode_ci,
  `content_text` text COLLATE utf8mb4_unicode_ci,
  `content_css` text COLLATE utf8mb4_unicode_ci,
  `is_locked` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_mail_layouts`
--

INSERT INTO `system_mail_layouts` (`id`, `name`, `code`, `content_html`, `content_text`, `content_css`, `is_locked`, `created_at`, `updated_at`) VALUES
(1, 'Default layout', 'default', '<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n</head>\n<body>\n    <style type=\"text/css\" media=\"screen\">\n        {{ brandCss|raw }}\n        {{ css|raw }}\n    </style>\n\n    <table class=\"wrapper layout-default\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n\n        <!-- Header -->\n        {% partial \'header\' body %}\n            {{ subject|raw }}\n        {% endpartial %}\n\n        <tr>\n            <td align=\"center\">\n                <table class=\"content\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                    <!-- Email Body -->\n                    <tr>\n                        <td class=\"body\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                            <table class=\"inner-body\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\">\n                                <!-- Body content -->\n                                <tr>\n                                    <td class=\"content-cell\">\n                                        {{ content|raw }}\n                                    </td>\n                                </tr>\n                            </table>\n                        </td>\n                    </tr>\n                </table>\n            </td>\n        </tr>\n\n        <!-- Footer -->\n        {% partial \'footer\' body %}\n            &copy; {{ \"now\"|date(\"Y\") }} {{ appName }}. All rights reserved.\n        {% endpartial %}\n\n    </table>\n\n</body>\n</html>', '{{ content|raw }}', '@media only screen and (max-width: 600px) {\n    .inner-body {\n        width: 100% !important;\n    }\n\n    .footer {\n        width: 100% !important;\n    }\n}\n\n@media only screen and (max-width: 500px) {\n    .button {\n        width: 100% !important;\n    }\n}', 1, '2018-08-14 08:42:04', '2018-08-14 08:42:04'),
(2, 'System layout', 'system', '<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n</head>\n<body>\n    <style type=\"text/css\" media=\"screen\">\n        {{ brandCss|raw }}\n        {{ css|raw }}\n    </style>\n\n    <table class=\"wrapper layout-system\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n        <tr>\n            <td align=\"center\">\n                <table class=\"content\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                    <!-- Email Body -->\n                    <tr>\n                        <td class=\"body\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                            <table class=\"inner-body\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\">\n                                <!-- Body content -->\n                                <tr>\n                                    <td class=\"content-cell\">\n                                        {{ content|raw }}\n\n                                        <!-- Subcopy -->\n                                        {% partial \'subcopy\' body %}\n                                            **This is an automatic message. Please do not reply to it.**\n                                        {% endpartial %}\n                                    </td>\n                                </tr>\n                            </table>\n                        </td>\n                    </tr>\n                </table>\n            </td>\n        </tr>\n    </table>\n\n</body>\n</html>', '{{ content|raw }}\n\n\n---\nThis is an automatic message. Please do not reply to it.', '@media only screen and (max-width: 600px) {\n    .inner-body {\n        width: 100% !important;\n    }\n\n    .footer {\n        width: 100% !important;\n    }\n}\n\n@media only screen and (max-width: 500px) {\n    .button {\n        width: 100% !important;\n    }\n}', 1, '2018-08-14 08:42:04', '2018-08-14 08:42:04');

-- --------------------------------------------------------

--
-- Table structure for table `system_mail_partials`
--

CREATE TABLE `system_mail_partials` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_html` text COLLATE utf8mb4_unicode_ci,
  `content_text` text COLLATE utf8mb4_unicode_ci,
  `is_custom` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_mail_partials`
--

INSERT INTO `system_mail_partials` (`id`, `name`, `code`, `content_html`, `content_text`, `is_custom`, `created_at`, `updated_at`) VALUES
(1, 'Header', 'header', '<tr>\n    <td class=\"header\">\n        {% if url %}\n            <a href=\"{{ url }}\">\n                {{ body }}\n            </a>\n        {% else %}\n            <span>\n                {{ body }}\n            </span>\n        {% endif %}\n    </td>\n</tr>', '*** {{ body|trim }} <{{ url }}>', 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(2, 'Footer', 'footer', '<tr>\n    <td>\n        <table class=\"footer\" align=\"center\" width=\"570\" cellpadding=\"0\" cellspacing=\"0\">\n            <tr>\n                <td class=\"content-cell\" align=\"center\">\n                    {{ body|md_safe }}\n                </td>\n            </tr>\n        </table>\n    </td>\n</tr>', '-------------------\n{{ body|trim }}', 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(3, 'Button', 'button', '<table class=\"action\" align=\"center\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n    <tr>\n        <td align=\"center\">\n            <table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n                <tr>\n                    <td align=\"center\">\n                        <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n                            <tr>\n                                <td>\n                                    <a href=\"{{ url }}\" class=\"button button-{{ type ?: \'primary\' }}\" target=\"_blank\">\n                                        {{ body }}\n                                    </a>\n                                </td>\n                            </tr>\n                        </table>\n                    </td>\n                </tr>\n            </table>\n        </td>\n    </tr>\n</table>', '{{ body|trim }} <{{ url }}>', 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(4, 'Panel', 'panel', '<table class=\"panel\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n    <tr>\n        <td class=\"panel-content\">\n            <table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n                <tr>\n                    <td class=\"panel-item\">\n                        {{ body|md_safe }}\n                    </td>\n                </tr>\n            </table>\n        </td>\n    </tr>\n</table>', '{{ body|trim }}', 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(5, 'Table', 'table', '<div class=\"table\">\n    {{ body|md_safe }}\n</div>', '{{ body|trim }}', 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(6, 'Subcopy', 'subcopy', '<table class=\"subcopy\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n    <tr>\n        <td>\n            {{ body|md_safe }}\n        </td>\n    </tr>\n</table>', '-----\n{{ body|trim }}', 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(7, 'Promotion', 'promotion', '<table class=\"promotion\" align=\"center\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\n    <tr>\n        <td align=\"center\">\n            {{ body|md_safe }}\n        </td>\n    </tr>\n</table>', '{{ body|trim }}', 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08');

-- --------------------------------------------------------

--
-- Table structure for table `system_mail_templates`
--

CREATE TABLE `system_mail_templates` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `content_html` text COLLATE utf8mb4_unicode_ci,
  `content_text` text COLLATE utf8mb4_unicode_ci,
  `layout_id` int(11) DEFAULT NULL,
  `is_custom` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_mail_templates`
--

INSERT INTO `system_mail_templates` (`id`, `code`, `subject`, `description`, `content_html`, `content_text`, `layout_id`, `is_custom`, `created_at`, `updated_at`) VALUES
(1, 'rainlab.user::mail.activate', NULL, 'Activate a new user', NULL, NULL, 1, 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(2, 'rainlab.user::mail.welcome', NULL, 'User confirmed their account', NULL, NULL, 1, 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(3, 'rainlab.user::mail.restore', NULL, 'User requests a password reset', NULL, NULL, 1, 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(4, 'rainlab.user::mail.new_user', NULL, 'Notify admins of a new sign up', NULL, NULL, 2, 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(5, 'rainlab.user::mail.reactivate', NULL, 'User has reactivated their account', NULL, NULL, 1, 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(6, 'rainlab.user::mail.invite', NULL, 'Invite a new user to the website', NULL, NULL, 1, 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(7, 'backend::mail.invite', NULL, 'Invite new admin to the site', NULL, NULL, 2, 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(8, 'backend::mail.restore', NULL, 'Reset an admin password', NULL, NULL, 2, 0, '2018-09-02 12:01:08', '2018-09-02 12:01:08'),
(9, 'worcbox.orders.confirm::mail.message', 'تم استلام الطلب', 'Message of confirming order through email.', '{{ name }}\r\n\r\nتم استلام طلبكم وجارى العمل عليه', '', 1, 1, '2018-09-09 08:08:34', '2018-09-09 08:09:34'),
(10, 'worcbox.syaq.contact::mail.message', '{{ subject }}', 'A message sent from contact us form', 'الاسم\r\n{{ name }}\r\n\r\nالبريد الإلكترونى\r\n{{ email }}\r\n\r\nعنوان الرسالة\r\n{{ subject }}\r\n\r\nنص الرسالة\r\n{{ body }}', '', 1, 1, '2018-09-09 09:14:36', '2018-09-09 09:14:36'),
(11, 'worcbox.orders.finished::mail.message', 'تم الانتهاء من الطلب', 'Sending attachment with the finished order', 'تم الانتهاء من طلبكم .. يرجى تحميله من الملحقات', '', 1, 1, '2018-09-09 12:59:25', '2018-09-09 12:59:25');

-- --------------------------------------------------------

--
-- Table structure for table `system_parameters`
--

CREATE TABLE `system_parameters` (
  `id` int(10) UNSIGNED NOT NULL,
  `namespace` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_parameters`
--

INSERT INTO `system_parameters` (`id`, `namespace`, `group`, `item`, `value`) VALUES
(1, 'system', 'update', 'count', '0'),
(2, 'system', 'core', 'hash', '\"d4a4e1f641e333ff5c26037f86cfe619\"'),
(3, 'system', 'core', 'build', '\"437\"'),
(4, 'system', 'update', 'retry', '1536664723'),
(5, 'cms', 'theme', 'active', '\"syaq\"');

-- --------------------------------------------------------

--
-- Table structure for table `system_plugin_history`
--

CREATE TABLE `system_plugin_history` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_plugin_history`
--

INSERT INTO `system_plugin_history` (`id`, `code`, `type`, `version`, `detail`, `created_at`) VALUES
(1, 'October.Demo', 'comment', '1.0.1', 'First version of Demo', '2018-08-14 08:42:04'),
(45, 'RainLab.Pages', 'comment', '1.0.1', 'Implemented the static pages management and the Static Page component.', '2018-09-02 09:23:18'),
(46, 'RainLab.Pages', 'comment', '1.0.2', 'Fixed the page preview URL.', '2018-09-02 09:23:18'),
(47, 'RainLab.Pages', 'comment', '1.0.3', 'Implemented menus.', '2018-09-02 09:23:18'),
(48, 'RainLab.Pages', 'comment', '1.0.4', 'Implemented the content block management and placeholder support.', '2018-09-02 09:23:18'),
(49, 'RainLab.Pages', 'comment', '1.0.5', 'Added support for the Sitemap plugin.', '2018-09-02 09:23:18'),
(50, 'RainLab.Pages', 'comment', '1.0.6', 'Minor updates to the internal API.', '2018-09-02 09:23:18'),
(51, 'RainLab.Pages', 'comment', '1.0.7', 'Added the Snippets feature.', '2018-09-02 09:23:18'),
(52, 'RainLab.Pages', 'comment', '1.0.8', 'Minor improvements to the code.', '2018-09-02 09:23:18'),
(53, 'RainLab.Pages', 'comment', '1.0.9', 'Fixes issue where Snippet tab is missing from the Partials form.', '2018-09-02 09:23:18'),
(54, 'RainLab.Pages', 'comment', '1.0.10', 'Add translations for various locales.', '2018-09-02 09:23:18'),
(55, 'RainLab.Pages', 'comment', '1.0.11', 'Fixes issue where placeholders tabs were missing from Page form.', '2018-09-02 09:23:18'),
(56, 'RainLab.Pages', 'comment', '1.0.12', 'Implement Media Manager support.', '2018-09-02 09:23:18'),
(57, 'RainLab.Pages', 'script', '1.1.0', 'snippets_rename_viewbag_properties.php', '2018-09-02 09:23:18'),
(58, 'RainLab.Pages', 'comment', '1.1.0', 'Adds meta title and description to pages. Adds |staticPage filter.', '2018-09-02 09:23:18'),
(59, 'RainLab.Pages', 'comment', '1.1.1', 'Add support for Syntax Fields.', '2018-09-02 09:23:18'),
(60, 'RainLab.Pages', 'comment', '1.1.2', 'Static Breadcrumbs component now respects the hide from navigation setting.', '2018-09-02 09:23:18'),
(61, 'RainLab.Pages', 'comment', '1.1.3', 'Minor back-end styling fix.', '2018-09-02 09:23:18'),
(62, 'RainLab.Pages', 'comment', '1.1.4', 'Minor fix to the StaticPage component API.', '2018-09-02 09:23:18'),
(63, 'RainLab.Pages', 'comment', '1.1.5', 'Fixes bug when using syntax fields.', '2018-09-02 09:23:18'),
(64, 'RainLab.Pages', 'comment', '1.1.6', 'Minor styling fix to the back-end UI.', '2018-09-02 09:23:18'),
(65, 'RainLab.Pages', 'comment', '1.1.7', 'Improved menu item form to include CSS class, open in a new window and hidden flag.', '2018-09-02 09:23:18'),
(66, 'RainLab.Pages', 'comment', '1.1.8', 'Improved the output of snippet partials when saved.', '2018-09-02 09:23:18'),
(67, 'RainLab.Pages', 'comment', '1.1.9', 'Minor update to snippet inspector internal API.', '2018-09-02 09:23:18'),
(68, 'RainLab.Pages', 'comment', '1.1.10', 'Fixes a bug where selecting a layout causes permanent unsaved changes.', '2018-09-02 09:23:18'),
(69, 'RainLab.Pages', 'comment', '1.1.11', 'Add support for repeater syntax field.', '2018-09-02 09:23:18'),
(70, 'RainLab.Pages', 'comment', '1.2.0', 'Added support for translations, UI updates.', '2018-09-02 09:23:18'),
(71, 'RainLab.Pages', 'comment', '1.2.1', 'Use nice titles when listing the content files.', '2018-09-02 09:23:18'),
(72, 'RainLab.Pages', 'comment', '1.2.2', 'Minor styling update.', '2018-09-02 09:23:19'),
(73, 'RainLab.Pages', 'comment', '1.2.3', 'Snippets can now be moved by dragging them.', '2018-09-02 09:23:19'),
(74, 'RainLab.Pages', 'comment', '1.2.4', 'Fixes a bug where the cursor is misplaced when editing text files.', '2018-09-02 09:23:19'),
(75, 'RainLab.Pages', 'comment', '1.2.5', 'Fixes a bug where the parent page is lost upon changing a page layout.', '2018-09-02 09:23:19'),
(76, 'RainLab.Pages', 'comment', '1.2.6', 'Shared view variables are now passed to static pages.', '2018-09-02 09:23:19'),
(77, 'RainLab.Pages', 'comment', '1.2.7', 'Fixes issue with duplicating properties when adding multiple snippets on the same page.', '2018-09-02 09:23:19'),
(78, 'RainLab.Pages', 'comment', '1.2.8', 'Fixes a bug where creating a content block without extension doesn\'t save the contents to file.', '2018-09-02 09:23:19'),
(79, 'RainLab.Pages', 'comment', '1.2.9', 'Add conditional support for translating page URLs.', '2018-09-02 09:23:19'),
(80, 'RainLab.Pages', 'comment', '1.2.10', 'Streamline generation of URLs to use the new Cms::url helper.', '2018-09-02 09:23:19'),
(81, 'RainLab.Pages', 'comment', '1.2.11', 'Implements repeater usage with translate plugin.', '2018-09-02 09:23:19'),
(82, 'RainLab.Pages', 'comment', '1.2.12', 'Fixes minor issue when using snippets and switching the application locale.', '2018-09-02 09:23:19'),
(83, 'RainLab.Pages', 'comment', '1.2.13', 'Fixes bug when AJAX is used on a page that does not yet exist.', '2018-09-02 09:23:19'),
(84, 'RainLab.Pages', 'comment', '1.2.14', 'Add theme logging support for changes made to menus.', '2018-09-02 09:23:19'),
(85, 'RainLab.Pages', 'comment', '1.2.15', 'Back-end navigation sort order updated.', '2018-09-02 09:23:19'),
(86, 'RainLab.Pages', 'comment', '1.2.16', 'Fixes a bug when saving a template that has been modified outside of the CMS (mtime mismatch).', '2018-09-02 09:23:19'),
(87, 'RainLab.Pages', 'comment', '1.2.17', 'Changes locations of custom fields to secondary tabs instead of the primary Settings area. New menu search ability on adding menu items', '2018-09-02 09:23:19'),
(88, 'RainLab.Pages', 'comment', '1.2.18', 'Fixes cache-invalidation issues when RainLab.Translate is not installed. Added Greek & Simplified Chinese translations. Removed deprecated calls. Allowed saving HTML in snippet properties. Added support for the MediaFinder in menu items.', '2018-09-02 09:23:19'),
(171, 'RainLab.Builder', 'comment', '1.0.1', 'Initialize plugin.', '2018-09-02 11:21:40'),
(172, 'RainLab.Builder', 'comment', '1.0.2', 'Fixes the problem with selecting a plugin. Minor localization corrections. Configuration files in the list and form behaviors are now autocomplete.', '2018-09-02 11:21:40'),
(173, 'RainLab.Builder', 'comment', '1.0.3', 'Improved handling of the enum data type.', '2018-09-02 11:21:40'),
(174, 'RainLab.Builder', 'comment', '1.0.4', 'Added user permissions to work with the Builder.', '2018-09-02 11:21:40'),
(175, 'RainLab.Builder', 'comment', '1.0.5', 'Fixed permissions registration.', '2018-09-02 11:21:40'),
(176, 'RainLab.Builder', 'comment', '1.0.6', 'Fixed front-end record ordering in the Record List component.', '2018-09-02 11:21:40'),
(177, 'RainLab.Builder', 'comment', '1.0.7', 'Builder settings are now protected with user permissions. The database table column list is scrollable now. Minor code cleanup.', '2018-09-02 11:21:40'),
(178, 'RainLab.Builder', 'comment', '1.0.8', 'Added the Reorder Controller behavior.', '2018-09-02 11:21:40'),
(179, 'RainLab.Builder', 'comment', '1.0.9', 'Minor API and UI updates.', '2018-09-02 11:21:40'),
(180, 'RainLab.Builder', 'comment', '1.0.10', 'Minor styling update.', '2018-09-02 11:21:40'),
(181, 'RainLab.Builder', 'comment', '1.0.11', 'Fixed a bug where clicking placeholder in a repeater would open Inspector. Fixed a problem with saving forms with repeaters in tabs. Minor style fix.', '2018-09-02 11:21:40'),
(182, 'RainLab.Builder', 'comment', '1.0.12', 'Added support for the Trigger property to the Media Finder widget configuration. Names of form fields and list columns definition files can now contain underscores.', '2018-09-02 11:21:40'),
(183, 'RainLab.Builder', 'comment', '1.0.13', 'Minor styling fix on the database editor.', '2018-09-02 11:21:40'),
(184, 'RainLab.Builder', 'comment', '1.0.14', 'Added support for published_at timestamp field', '2018-09-02 11:21:40'),
(185, 'RainLab.Builder', 'comment', '1.0.15', 'Fixed a bug where saving a localization string in Inspector could cause a JavaScript error. Added support for Timestamps and Soft Deleting for new models.', '2018-09-02 11:21:40'),
(186, 'RainLab.Builder', 'comment', '1.0.16', 'Fixed a bug when saving a form with the Repeater widget in a tab could create invalid fields in the form\'s outside area. Added a check that prevents creating localization strings inside other existing strings.', '2018-09-02 11:21:40'),
(187, 'RainLab.Builder', 'comment', '1.0.17', 'Added support Trigger attribute support for RecordFinder and Repeater form widgets.', '2018-09-02 11:21:40'),
(188, 'RainLab.Builder', 'comment', '1.0.18', 'Fixes a bug where \'::class\' notations in a model class definition could prevent the model from appearing in the Builder model list. Added emptyOption property support to the dropdown form control.', '2018-09-02 11:21:40'),
(189, 'RainLab.Builder', 'comment', '1.0.19', 'Added a feature allowing to add all database columns to a list definition. Added max length validation for database table and column names.', '2018-09-02 11:21:40'),
(190, 'RainLab.Builder', 'comment', '1.0.20', 'Fixes a bug where form the builder could trigger the \"current.hasAttribute is not a function\" error.', '2018-09-02 11:21:40'),
(191, 'RainLab.Builder', 'comment', '1.0.21', 'Back-end navigation sort order updated.', '2018-09-02 11:21:40'),
(192, 'RainLab.Builder', 'comment', '1.0.22', 'Added scopeValue property to the RecordList component.', '2018-09-02 11:21:40'),
(206, 'RainLab.User', 'script', '1.0.1', 'create_users_table.php', '2018-09-02 11:24:49'),
(207, 'RainLab.User', 'script', '1.0.1', 'create_throttle_table.php', '2018-09-02 11:24:49'),
(208, 'RainLab.User', 'comment', '1.0.1', 'Initialize plugin.', '2018-09-02 11:24:49'),
(209, 'RainLab.User', 'comment', '1.0.2', 'Seed tables.', '2018-09-02 11:24:49'),
(210, 'RainLab.User', 'comment', '1.0.3', 'Translated hard-coded text to language strings.', '2018-09-02 11:24:49'),
(211, 'RainLab.User', 'comment', '1.0.4', 'Improvements to user-interface for Location manager.', '2018-09-02 11:24:49'),
(212, 'RainLab.User', 'comment', '1.0.5', 'Added contact details for users.', '2018-09-02 11:24:49'),
(213, 'RainLab.User', 'script', '1.0.6', 'create_mail_blockers_table.php', '2018-09-02 11:24:50'),
(214, 'RainLab.User', 'comment', '1.0.6', 'Added Mail Blocker utility so users can block specific mail templates.', '2018-09-02 11:24:50'),
(215, 'RainLab.User', 'comment', '1.0.7', 'Add back-end Settings page.', '2018-09-02 11:24:50'),
(216, 'RainLab.User', 'comment', '1.0.8', 'Updated the Settings page.', '2018-09-02 11:24:50'),
(217, 'RainLab.User', 'comment', '1.0.9', 'Adds new welcome mail message for users and administrators.', '2018-09-02 11:24:50'),
(218, 'RainLab.User', 'comment', '1.0.10', 'Adds administrator-only activation mode.', '2018-09-02 11:24:50'),
(219, 'RainLab.User', 'script', '1.0.11', 'users_add_login_column.php', '2018-09-02 11:24:50'),
(220, 'RainLab.User', 'comment', '1.0.11', 'Users now have an optional login field that defaults to the email field.', '2018-09-02 11:24:50'),
(221, 'RainLab.User', 'script', '1.0.12', 'users_rename_login_to_username.php', '2018-09-02 11:24:50'),
(222, 'RainLab.User', 'comment', '1.0.12', 'Create a dedicated setting for choosing the login mode.', '2018-09-02 11:24:50'),
(223, 'RainLab.User', 'comment', '1.0.13', 'Minor fix to the Account sign in logic.', '2018-09-02 11:24:50'),
(224, 'RainLab.User', 'comment', '1.0.14', 'Minor improvements to the code.', '2018-09-02 11:24:50'),
(225, 'RainLab.User', 'script', '1.0.15', 'users_add_surname.php', '2018-09-02 11:24:50'),
(226, 'RainLab.User', 'comment', '1.0.15', 'Adds last name column to users table (surname).', '2018-09-02 11:24:50'),
(227, 'RainLab.User', 'comment', '1.0.16', 'Require permissions for settings page too.', '2018-09-02 11:24:50'),
(228, 'RainLab.User', 'comment', '1.1.0', '!!! Profile fields and Locations have been removed.', '2018-09-02 11:24:50'),
(229, 'RainLab.User', 'script', '1.1.1', 'create_user_groups_table.php', '2018-09-02 11:24:50'),
(230, 'RainLab.User', 'script', '1.1.1', 'seed_user_groups_table.php', '2018-09-02 11:24:50'),
(231, 'RainLab.User', 'comment', '1.1.1', 'Users can now be added to groups.', '2018-09-02 11:24:50'),
(232, 'RainLab.User', 'comment', '1.1.2', 'A raw URL can now be passed as the redirect property in the Account component.', '2018-09-02 11:24:50'),
(233, 'RainLab.User', 'comment', '1.1.3', 'Adds a super user flag to the users table, reserved for future use.', '2018-09-02 11:24:50'),
(234, 'RainLab.User', 'comment', '1.1.4', 'User list can be filtered by the group they belong to.', '2018-09-02 11:24:50'),
(235, 'RainLab.User', 'comment', '1.1.5', 'Adds a new permission to hide the User settings menu item.', '2018-09-02 11:24:50'),
(236, 'RainLab.User', 'script', '1.2.0', 'users_add_deleted_at.php', '2018-09-02 11:24:50'),
(237, 'RainLab.User', 'comment', '1.2.0', 'Users can now deactivate their own accounts.', '2018-09-02 11:24:50'),
(238, 'RainLab.User', 'comment', '1.2.1', 'New feature for checking if a user is recently active/online.', '2018-09-02 11:24:50'),
(239, 'RainLab.User', 'comment', '1.2.2', 'Add bulk action button to user list.', '2018-09-02 11:24:50'),
(240, 'RainLab.User', 'comment', '1.2.3', 'Included some descriptive paragraphs in the Reset Password component markup.', '2018-09-02 11:24:50'),
(241, 'RainLab.User', 'comment', '1.2.4', 'Added a checkbox for blocking all mail sent to the user.', '2018-09-02 11:24:50'),
(242, 'RainLab.User', 'script', '1.2.5', 'update_timestamp_nullable.php', '2018-09-02 11:24:50'),
(243, 'RainLab.User', 'comment', '1.2.5', 'Database maintenance. Updated all timestamp columns to be nullable.', '2018-09-02 11:24:50'),
(244, 'RainLab.User', 'script', '1.2.6', 'users_add_last_seen.php', '2018-09-02 11:24:51'),
(245, 'RainLab.User', 'comment', '1.2.6', 'Add a dedicated last seen column for users.', '2018-09-02 11:24:51'),
(246, 'RainLab.User', 'comment', '1.2.7', 'Minor fix to user timestamp attributes.', '2018-09-02 11:24:51'),
(247, 'RainLab.User', 'comment', '1.2.8', 'Add date range filter to users list. Introduced a logout event.', '2018-09-02 11:24:51'),
(248, 'RainLab.User', 'comment', '1.2.9', 'Add invitation mail for new accounts created in the back-end.', '2018-09-02 11:24:51'),
(249, 'RainLab.User', 'script', '1.3.0', 'users_add_guest_flag.php', '2018-09-02 11:24:51'),
(250, 'RainLab.User', 'script', '1.3.0', 'users_add_superuser_flag.php', '2018-09-02 11:24:51'),
(251, 'RainLab.User', 'comment', '1.3.0', 'Introduced guest user accounts.', '2018-09-02 11:24:51'),
(252, 'RainLab.User', 'comment', '1.3.1', 'User notification variables can now be extended.', '2018-09-02 11:24:51'),
(253, 'RainLab.User', 'comment', '1.3.2', 'Minor fix to the Auth::register method.', '2018-09-02 11:24:51'),
(254, 'RainLab.User', 'comment', '1.3.3', 'Allow prevention of concurrent user sessions via the user settings.', '2018-09-02 11:24:51'),
(255, 'RainLab.User', 'comment', '1.3.4', 'Added force secure protocol property to the account component.', '2018-09-02 11:24:51'),
(256, 'RainLab.User', 'comment', '1.4.0', '!!! The Notifications tab in User settings has been removed.', '2018-09-02 11:24:51'),
(257, 'RainLab.User', 'comment', '1.4.1', 'Added support for user impersonation.', '2018-09-02 11:24:51'),
(258, 'RainLab.User', 'comment', '1.4.2', 'Fixes security bug in Password Reset component.', '2018-09-02 11:24:51'),
(259, 'RainLab.User', 'comment', '1.4.3', 'Fixes session handling for AJAX requests.', '2018-09-02 11:24:51'),
(260, 'RainLab.User', 'comment', '1.4.4', 'Fixes bug where impersonation touches the last seen timestamp.', '2018-09-02 11:24:51'),
(261, 'RainLab.User', 'comment', '1.4.5', 'Added token fallback process to Account / Reset Password components when parameter is missing.', '2018-09-02 11:24:51'),
(262, 'RainLab.User', 'comment', '1.4.6', 'Fixes Auth::register method signature mismatch with core OctoberCMS Auth library', '2018-09-02 11:24:51'),
(265, 'Worcbox.Features', 'comment', '1.0.1', 'Initialize plugin.', '2018-09-02 11:26:26'),
(266, 'Worcbox.Features', 'script', '1.0.2', 'builder_table_create_worcbox_features_.php', '2018-09-02 11:26:58'),
(267, 'Worcbox.Features', 'comment', '1.0.2', 'Created table worcbox_features_', '2018-09-02 11:26:58'),
(268, 'Worcbox.Features', 'script', '1.0.3', 'builder_table_update_worcbox_features_items.php', '2018-09-02 11:27:45'),
(269, 'Worcbox.Features', 'comment', '1.0.3', 'Updated table worcbox_features_', '2018-09-02 11:27:45'),
(270, 'Worcbox.Features', 'script', '1.0.4', 'builder_table_update_worcbox_features_items_2.php', '2018-09-02 11:37:42'),
(271, 'Worcbox.Features', 'comment', '1.0.4', 'Updated table worcbox_features_items', '2018-09-02 11:37:42'),
(272, 'Worcbox.Features', 'script', '1.0.5', 'builder_table_update_worcbox_features_items_3.php', '2018-09-02 11:45:55'),
(273, 'Worcbox.Features', 'comment', '1.0.5', 'Updated table worcbox_features_items', '2018-09-02 11:45:55'),
(274, 'Worcbox.Syaq', 'comment', '1.0.1', 'Initialize plugin.', '2018-09-02 13:52:25'),
(275, 'Worcbox.Syaq', 'script', '1.0.2', 'builder_table_create_worcbox_syaq_services.php', '2018-09-02 14:00:35'),
(276, 'Worcbox.Syaq', 'comment', '1.0.2', 'Created table worcbox_syaq_services', '2018-09-02 14:00:35'),
(278, 'Worcbox.Features', 'script', '1.0.6', 'builder_table_update_worcbox_features_items_4.php', '2018-09-03 08:27:58'),
(279, 'Worcbox.Features', 'comment', '1.0.6', 'Updated table worcbox_features_items', '2018-09-03 08:27:58'),
(280, 'Worcbox.Packages', 'comment', '1.0.1', 'Initialize plugin.', '2018-09-03 10:18:44'),
(281, 'Worcbox.Packages', 'script', '1.0.2', 'builder_table_create_worcbox_packages_items.php', '2018-09-03 10:22:25'),
(282, 'Worcbox.Packages', 'comment', '1.0.2', 'Created table worcbox_packages_items', '2018-09-03 10:22:25'),
(283, 'Worcbox.Syaq', 'script', '1.0.3', 'builder_table_create_worcbox_syaq_orders.php', '2018-09-03 10:40:21'),
(284, 'Worcbox.Syaq', 'comment', '1.0.3', 'Created table worcbox_syaq_orders', '2018-09-03 10:40:21'),
(285, 'Worcbox.Syaq', 'script', '1.0.4', 'builder_table_create_worcbox_syaq_fields.php', '2018-09-03 10:41:13'),
(286, 'Worcbox.Syaq', 'comment', '1.0.4', 'Created table worcbox_syaq_fields', '2018-09-03 10:41:13'),
(287, 'Worcbox.Syaq', 'script', '1.0.5', 'builder_table_update_worcbox_syaq_orders.php', '2018-09-03 10:41:25'),
(288, 'Worcbox.Syaq', 'comment', '1.0.5', 'Updated table worcbox_syaq_orders', '2018-09-03 10:41:25'),
(289, 'Worcbox.Syaq', 'script', '1.0.6', 'builder_table_create_worcbox_syaq_audience_genders.php', '2018-09-03 10:42:05'),
(290, 'Worcbox.Syaq', 'comment', '1.0.6', 'Created table worcbox_syaq_audience_genders', '2018-09-03 10:42:05'),
(291, 'Worcbox.Syaq', 'script', '1.0.7', 'builder_table_update_worcbox_syaq_fields.php', '2018-09-03 10:42:11'),
(292, 'Worcbox.Syaq', 'comment', '1.0.7', 'Updated table worcbox_syaq_fields', '2018-09-03 10:42:11'),
(293, 'Worcbox.Syaq', 'script', '1.0.8', 'builder_table_create_worcbox_syaq_.php', '2018-09-03 10:42:40'),
(294, 'Worcbox.Syaq', 'comment', '1.0.8', 'Created table worcbox_syaq_', '2018-09-03 10:42:40'),
(295, 'Worcbox.Syaq', 'script', '1.0.9', 'builder_table_create_worcbox_syaq_title_fields.php', '2018-09-03 10:43:09'),
(296, 'Worcbox.Syaq', 'comment', '1.0.9', 'Created table worcbox_syaq_title_fields', '2018-09-03 10:43:09'),
(297, 'Worcbox.Syaq', 'script', '1.0.10', 'builder_table_create_worcbox_syaq_typing_modes.php', '2018-09-03 10:43:39'),
(298, 'Worcbox.Syaq', 'comment', '1.0.10', 'Created table worcbox_syaq_typing_modes', '2018-09-03 10:43:39'),
(299, 'Worcbox.Syaq', 'script', '1.0.11', 'builder_table_update_worcbox_syaq_speech_formats.php', '2018-09-03 10:44:12'),
(300, 'Worcbox.Syaq', 'comment', '1.0.11', 'Updated table worcbox_syaq_', '2018-09-03 10:44:12'),
(301, 'Worcbox.Syaq', 'script', '1.0.12', 'builder_table_update_worcbox_syaq_orders_2.php', '2018-09-03 10:45:02'),
(302, 'Worcbox.Syaq', 'comment', '1.0.12', 'Updated table worcbox_syaq_orders', '2018-09-03 10:45:02'),
(303, 'Worcbox.Syaq', 'script', '1.0.13', 'builder_table_update_worcbox_syaq_orders_3.php', '2018-09-03 10:58:28'),
(304, 'Worcbox.Syaq', 'comment', '1.0.13', 'Updated table worcbox_syaq_orders', '2018-09-03 10:58:28'),
(305, 'Worcbox.Syaq', 'script', '1.0.14', 'builder_table_update_worcbox_syaq_services.php', '2018-09-03 12:35:33'),
(306, 'Worcbox.Syaq', 'comment', '1.0.14', 'Updated table worcbox_syaq_services', '2018-09-03 12:35:33'),
(307, 'Worcbox.Features', 'script', '1.0.7', 'builder_table_update_worcbox_features_items_5.php', '2018-09-04 08:04:50'),
(308, 'Worcbox.Features', 'comment', '1.0.7', 'Updated table worcbox_features_items', '2018-09-04 08:04:50'),
(309, 'Worcbox.Features', 'script', '1.0.8', 'builder_table_update_worcbox_features_items_6.php', '2018-09-04 08:07:27'),
(310, 'Worcbox.Features', 'comment', '1.0.8', 'Updated table worcbox_features_items', '2018-09-04 08:07:27'),
(311, 'Worcbox.Syaq', 'script', '1.0.15', 'builder_table_update_worcbox_syaq_orders_4.php', '2018-09-04 08:56:54'),
(312, 'Worcbox.Syaq', 'comment', '1.0.15', 'Updated table worcbox_syaq_orders', '2018-09-04 08:56:54'),
(313, 'Worcbox.Syaq', 'script', '1.0.16', 'builder_table_update_worcbox_syaq_orders_5.php', '2018-09-05 08:47:29'),
(314, 'Worcbox.Syaq', 'comment', '1.0.16', 'Updated table worcbox_syaq_orders', '2018-09-05 08:47:29'),
(315, 'Worcbox.Syaq', 'script', '1.0.17', 'builder_table_update_worcbox_syaq_orders_6.php', '2018-09-05 08:49:20'),
(316, 'Worcbox.Syaq', 'comment', '1.0.17', 'Updated table worcbox_syaq_orders', '2018-09-05 08:49:20'),
(317, 'Worcbox.Syaq', 'script', '1.0.18', 'builder_table_update_worcbox_syaq_orders_7.php', '2018-09-05 09:33:42'),
(318, 'Worcbox.Syaq', 'comment', '1.0.18', 'Updated table worcbox_syaq_orders', '2018-09-05 09:33:42'),
(319, 'Worcbox.Syaq', 'script', '1.0.19', 'builder_table_create_worcbox_syaq_order_attachments.php', '2018-09-05 12:23:22'),
(320, 'Worcbox.Syaq', 'comment', '1.0.19', 'Created table worcbox_syaq_order_attachments', '2018-09-05 12:23:22'),
(321, 'Worcbox.Syaq', 'script', '1.0.20', 'builder_table_update_worcbox_syaq_orders_8.php', '2018-09-05 13:43:20'),
(322, 'Worcbox.Syaq', 'comment', '1.0.20', 'Updated table worcbox_syaq_orders', '2018-09-05 13:43:20'),
(323, 'Worcbox.Syaq', 'script', '1.0.21', 'builder_table_update_worcbox_syaq_order_attachments.php', '2018-09-06 08:20:42'),
(324, 'Worcbox.Syaq', 'comment', '1.0.21', 'Updated table worcbox_syaq_order_attachments', '2018-09-06 08:20:42'),
(325, 'Worcbox.Packages', 'script', '1.0.3', 'builder_table_update_worcbox_packages_items.php', '2018-09-06 14:29:53'),
(326, 'Worcbox.Packages', 'comment', '1.0.3', 'Updated table worcbox_packages_items', '2018-09-06 14:29:53'),
(327, 'Worcbox.StaticData', 'comment', '1.0.1', 'Initialize plugin.', '2018-09-09 09:36:41'),
(328, 'Worcbox.StaticData', 'script', '1.0.2', 'builder_table_create_worcbox_staticdata_lookups.php', '2018-09-09 09:38:02'),
(329, 'Worcbox.StaticData', 'comment', '1.0.2', 'Created table worcbox_staticdata_lookups', '2018-09-09 09:38:02'),
(330, 'Worcbox.StaticData', 'script', '1.0.3', 'builder_table_update_worcbox_staticdata_lookups.php', '2018-09-09 09:38:50'),
(331, 'Worcbox.StaticData', 'comment', '1.0.3', 'Updated table worcbox_staticdata_lookups', '2018-09-09 09:38:50'),
(332, 'Flynsarmy.SocialLogin', 'script', '1.0.1', 'create_flynsarmy_sociallogin_user_providers.php', '2018-09-09 15:41:37'),
(333, 'Flynsarmy.SocialLogin', 'comment', '1.0.1', 'First version of SocialLogin', '2018-09-09 15:41:37'),
(334, 'Flynsarmy.SocialLogin', 'comment', '1.0.2', 'Require RainLab.User', '2018-09-09 15:41:37'),
(335, 'Flynsarmy.SocialLogin', 'comment', '1.0.3', 'Fixed RainLab.User integration', '2018-09-09 15:41:37'),
(336, 'Flynsarmy.SocialLogin', 'comment', '1.0.4', 'User registration bug fix', '2018-09-09 15:41:37'),
(337, 'Flynsarmy.SocialLogin', 'comment', '1.0.5', 'Fix password confirmation error', '2018-09-09 15:41:37'),
(338, 'Flynsarmy.SocialLogin', 'comment', '1.0.6', 'Add login details when registering users', '2018-09-09 15:41:37'),
(339, 'Flynsarmy.SocialLogin', 'comment', '1.0.7', 'Rename login to username to match RainLab.Users latest update', '2018-09-09 15:41:37'),
(340, 'Flynsarmy.SocialLogin', 'comment', '1.0.8', 'RC compatibility update', '2018-09-09 15:41:37'),
(341, 'Flynsarmy.SocialLogin', 'comment', '1.0.9', 'Google login fix', '2018-09-09 15:41:37'),
(342, 'Flynsarmy.SocialLogin', 'comment', '1.0.10', 'Don\'t add multiple Google associations to users', '2018-09-09 15:41:37'),
(343, 'Flynsarmy.SocialLogin', 'comment', '1.0.11', 'Modified table key name', '2018-09-09 15:41:37'),
(344, 'Flynsarmy.SocialLogin', 'comment', '1.0.12', 'Update login providers', '2018-09-09 15:41:37'),
(345, 'Flynsarmy.SocialLogin', 'comment', '1.0.13', 'Deprecated code fix, settings page fix', '2018-09-09 15:41:37'),
(346, 'Flynsarmy.SocialLogin', 'comment', '1.0.14', 'Singleton trait fix', '2018-09-09 15:41:37'),
(347, 'Flynsarmy.SocialLogin', 'comment', '1.0.15', 'Compatibility fix with RainLab.GoogleAnalytics', '2018-09-09 15:41:37'),
(348, 'Flynsarmy.SocialLogin', 'script', '1.0.16', 'update_provider_settings_locations_1016.php', '2018-09-09 15:41:37'),
(349, 'Flynsarmy.SocialLogin', 'comment', '1.0.16', '!!! Important update with breaking changes.', '2018-09-09 15:41:37'),
(350, 'Flynsarmy.SocialLogin', 'comment', '1.0.17', 'Fixed issue registering new users', '2018-09-09 15:41:37'),
(351, 'Flynsarmy.SocialLogin', 'comment', '1.0.18', '!!! Requires October build 420 or higher.', '2018-09-09 15:41:37'),
(352, 'Flynsarmy.SocialLogin', 'comment', '1.0.19', 'Add backend permission requirement', '2018-09-09 15:41:37'),
(353, 'Flynsarmy.SocialLogin', 'script', '1.0.20', 'Prevent users from registering when Allow user registration is OFF (Thanks to Kurt Jensen)', '2018-09-09 15:41:37'),
(354, 'Flynsarmy.SocialLogin', 'script', '1.0.20', 'Grab user profile picture on account registration (Thanks to kdoonboli)', '2018-09-09 15:41:37'),
(355, 'Flynsarmy.SocialLogin', 'script', '1.0.20', 'Fix redirects on custom login (Thanks to kdoonboli)', '2018-09-09 15:41:37'),
(356, 'Flynsarmy.SocialLogin', 'comment', '1.0.20', 'Upgrade to latest socialite', '2018-09-09 15:41:37'),
(357, 'Flynsarmy.SocialLogin', 'script', '1.0.21', 'Remove deprecated Facebook scope', '2018-09-09 15:41:37'),
(358, 'Flynsarmy.SocialLogin', 'comment', '1.0.21', 'Update socialite', '2018-09-09 15:41:37'),
(359, 'VojtaSvoboda.Reviews', 'script', '1.0.1', 'create_reviews_table.php', '2018-09-10 08:58:17'),
(360, 'VojtaSvoboda.Reviews', 'comment', '1.0.1', 'First version of Reviews', '2018-09-10 08:58:17'),
(361, 'VojtaSvoboda.Reviews', 'comment', '1.0.2', 'Fix getting value from empty rating', '2018-09-10 08:58:17'),
(362, 'VojtaSvoboda.Reviews', 'script', '1.0.3', 'create_categories_table.php', '2018-09-10 08:58:17'),
(363, 'VojtaSvoboda.Reviews', 'script', '1.0.3', 'create_review_category_table.php', '2018-09-10 08:58:18'),
(364, 'VojtaSvoboda.Reviews', 'comment', '1.0.3', 'Add review categories', '2018-09-10 08:58:18'),
(365, 'VojtaSvoboda.Reviews', 'comment', '1.0.4', 'Add support for RainLab.Translate', '2018-09-10 08:58:18'),
(366, 'VojtaSvoboda.Reviews', 'comment', '1.0.5', 'Add category permissions', '2018-09-10 08:58:18');

-- --------------------------------------------------------

--
-- Table structure for table `system_plugin_versions`
--

CREATE TABLE `system_plugin_versions` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `is_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `is_frozen` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_plugin_versions`
--

INSERT INTO `system_plugin_versions` (`id`, `code`, `version`, `created_at`, `is_disabled`, `is_frozen`) VALUES
(1, 'October.Demo', '1.0.1', '2018-08-14 08:42:04', 0, 1),
(3, 'RainLab.Pages', '1.2.18', '2018-09-02 09:23:19', 0, 1),
(7, 'RainLab.Builder', '1.0.22', '2018-09-02 11:21:40', 0, 1),
(9, 'RainLab.User', '1.4.6', '2018-09-02 11:24:51', 0, 1),
(10, 'Worcbox.Features', '1.0.8', '2018-09-04 08:07:27', 0, 1),
(11, 'Worcbox.Syaq', '1.0.21', '2018-09-06 08:20:42', 0, 1),
(13, 'Worcbox.Packages', '1.0.3', '2018-09-06 14:29:53', 0, 1),
(14, 'Worcbox.StaticData', '1.0.3', '2018-09-09 09:38:50', 0, 1),
(15, 'Flynsarmy.SocialLogin', '1.0.21', '2018-09-09 15:41:37', 0, 1),
(16, 'VojtaSvoboda.Reviews', '1.0.5', '2018-09-10 08:58:18', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `system_request_logs`
--

CREATE TABLE `system_request_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `status_code` int(11) DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer` text COLLATE utf8mb4_unicode_ci,
  `count` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_revisions`
--

CREATE TABLE `system_revisions` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cast` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_value` text COLLATE utf8mb4_unicode_ci,
  `new_value` text COLLATE utf8mb4_unicode_ci,
  `revisionable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revisionable_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `item` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `item`, `value`) VALUES
(1, 'backend_brand_settings', '{\"app_name\":\"Syaq\",\"app_tagline\":\"Syaq\",\"primary_color\":\"#34495e\",\"secondary_color\":\"#e67e22\",\"accent_color\":\"#3498db\",\"menu_mode\":\"inline\",\"custom_css\":\"\"}'),
(2, 'rainlab_builder_settings', '{\"author_name\":\"Worcbox\",\"author_namespace\":\"Worcbox\"}'),
(3, 'user_settings', '{\"require_activation\":\"1\",\"activate_mode\":\"auto\",\"use_throttle\":\"1\",\"block_persistence\":\"0\",\"allow_registration\":\"1\",\"login_attribute\":\"email\"}'),
(4, 'system_mail_settings', '{\"send_mode\":\"smtp\",\"sender_name\":\"Syaq\",\"sender_email\":\"noreply@syaq.com\",\"sendmail_path\":\"\\/usr\\/sbin\\/sendmail -bs\",\"smtp_address\":\"smtp.gmail.com\",\"smtp_port\":\"587\",\"smtp_user\":\"syaq.app@gmail.com\",\"smtp_password\":\"Syaq@pp2018\",\"smtp_authorization\":\"1\",\"smtp_encryption\":\"tls\",\"mailgun_domain\":\"\",\"mailgun_secret\":\"\",\"mandrill_secret\":\"\",\"ses_key\":\"\",\"ses_secret\":\"\",\"ses_region\":\"\"}'),
(5, 'flynsarmy_sociallogin_settings', '{\"providers\":{\"Google\":{\"enabled\":\"0\",\"enabledForBackend\":\"0\",\"app_name\":\"\",\"client_id\":\"\",\"client_secret\":\"\"},\"Twitter\":{\"enabled\":\"0\",\"identifier\":\"\",\"secret\":\"\"},\"Facebook\":{\"enabled\":\"1\",\"enabledForBackend\":\"0\",\"client_id\":\"742627836076361\",\"client_secret\":\"efdc044c0ed50b5e00e9b2fe4c4eec00\"}}}');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activation_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `persist_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_password_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `is_activated` tinyint(1) NOT NULL DEFAULT '0',
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surname` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `last_seen` timestamp NULL DEFAULT NULL,
  `is_guest` tinyint(1) NOT NULL DEFAULT '0',
  `is_superuser` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `activation_code`, `persist_code`, `reset_password_code`, `permissions`, `is_activated`, `activated_at`, `last_login`, `created_at`, `updated_at`, `username`, `surname`, `deleted_at`, `last_seen`, `is_guest`, `is_superuser`) VALUES
(1, 'مصطفى الجزار', 'mostafa@worcbox.com', '$2y$10$depXlZF2SimQT11XRLz5VOKlkCFkzEsCmrrOzr1dBj0r34LawkOPa', NULL, '$2y$10$P3FfWQ7hp2lbR74YPlcCx.QIog0ELTd9gWj//RVhTcBfAs43nkC3C', NULL, NULL, 1, '2018-09-02 11:36:39', '2018-09-09 16:40:19', '2018-09-02 11:36:00', '2018-09-09 16:40:19', 'mostafa@mailinator.com', '', NULL, '2018-09-09 16:40:19', 0, 0),
(2, 'Aly', 'aly@mailinator.com', '$2y$10$c74NFInXsF0rWYcJIuL7TuA.O.mZTc30vq8zIMlrA5VJTKHRfo7iy', NULL, NULL, NULL, NULL, 1, '2018-09-02 12:36:36', '2018-09-02 12:36:37', '2018-09-02 12:36:36', '2018-09-02 12:37:14', 'aly@mailinator.com', NULL, NULL, NULL, 0, 0),
(3, 'Ibraheem', 'ibraheem@mailinator.com', '$2y$10$ZWC7m7IaAvwO1iRMrA6K0el7ozlzbU8CtPEgJp/rFU3a6DGpgXqUC', NULL, NULL, NULL, NULL, 1, '2018-09-02 12:37:46', '2018-09-02 12:37:46', '2018-09-02 12:37:46', '2018-09-02 12:38:00', 'ibraheem@mailinator.com', NULL, NULL, NULL, 0, 0),
(4, 'Durra', 'durra@mailinator.com', '$2y$10$CSPhr7YQ0c1Ki0CiH4NZYOtK37OBxzCkYbbSEqFHt62gfGYndlTim', NULL, '$2y$10$/dZv3dT5DM3l5LmVcLcLke2UN1X32Tvao7h4N0Jae7rtrXOJYzzMO', NULL, NULL, 1, '2018-09-04 11:11:18', '2018-09-04 11:28:56', '2018-09-02 12:38:19', '2018-09-04 11:28:56', 'durra@mailinator.com', '', NULL, '2018-09-04 11:25:22', 0, 0),
(5, 'Aly El-Degwy', 'aly.eldegwy@gmail.com', '$2y$10$xtu5DioQVhZdrnL0IknvOepcXYuOQQvgXkhvxu5xCZ2Bnqp56EU/y', NULL, '$2y$10$A64DqB/Tfv6qp4c7zyLOROi4MVt8X6/sm5gFW6dN2f2olqDIsdF1S', NULL, NULL, 1, '2018-09-04 11:51:52', '2018-09-11 08:05:14', '2018-09-04 11:51:52', '2018-09-11 08:05:14', 'aly.eldegwy@gmail.com', NULL, NULL, '2018-09-11 08:10:36', 0, 0),
(6, '', 'root@sdfsdfss.ss', '$2y$10$5EcVlv8IlcV70JEo4A8jYeUxhw9VKxhExcGUZkDxJAV.BAUIeHJHC', NULL, NULL, NULL, NULL, 1, '2018-09-09 10:45:49', '2018-09-09 10:45:49', '2018-09-09 10:45:48', '2018-09-09 10:45:54', 'root@sdfsdfss.ss', NULL, NULL, NULL, 0, 0),
(7, 'Aly El-Degwy', 'aly.afifi@gmail.com', '$2y$10$7iK/mZWW5uwo08SK6F0a2.nlEqTCN5zXFnJC5EReXFGvK8u6Nz6R.', NULL, NULL, NULL, NULL, 1, '2018-09-10 10:00:26', '2018-09-10 10:11:33', '2018-09-10 10:00:26', '2018-09-10 10:11:35', 'aly.afifi@gmail.com', NULL, NULL, '2018-09-10 10:11:08', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `user_group_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE `user_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`id`, `name`, `code`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Guest', 'guest', 'Default group for guest users.', '2018-09-02 11:24:50', '2018-09-02 11:24:50'),
(2, 'Registered', 'registered', 'Default group for registered users.', '2018-09-02 11:24:50', '2018-09-02 11:24:50');

-- --------------------------------------------------------

--
-- Table structure for table `user_throttle`
--

CREATE TABLE `user_throttle` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `is_suspended` tinyint(1) NOT NULL DEFAULT '0',
  `suspended_at` timestamp NULL DEFAULT NULL,
  `is_banned` tinyint(1) NOT NULL DEFAULT '0',
  `banned_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_throttle`
--

INSERT INTO `user_throttle` (`id`, `user_id`, `ip_address`, `attempts`, `last_attempt_at`, `is_suspended`, `suspended_at`, `is_banned`, `banned_at`) VALUES
(1, 1, '127.0.0.1', 0, NULL, 0, NULL, 0, NULL),
(2, 2, '127.0.0.1', 0, NULL, 0, NULL, 0, NULL),
(3, 3, '127.0.0.1', 0, NULL, 0, NULL, 0, NULL),
(4, 4, '127.0.0.1', 0, NULL, 0, NULL, 0, NULL),
(5, 5, '192.168.1.130', 0, NULL, 0, NULL, 0, NULL),
(6, 5, '::1', 0, NULL, 0, NULL, 0, NULL),
(7, 1, '192.168.1.108', 0, '2018-09-09 16:16:20', 0, NULL, 0, NULL),
(8, 6, '::1', 0, NULL, 0, NULL, 0, NULL),
(9, 7, '::1', 0, NULL, 0, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vojtasvoboda_reviews_categories`
--

CREATE TABLE `vojtasvoboda_reviews_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` smallint(6) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vojtasvoboda_reviews_reviews`
--

CREATE TABLE `vojtasvoboda_reviews_reviews` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` smallint(6) DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `approved` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` tinyint(1) DEFAULT NULL,
  `hash` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locale` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_forwarded` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vojtasvoboda_reviews_review_category`
--

CREATE TABLE `vojtasvoboda_reviews_review_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `review_id` int(10) UNSIGNED DEFAULT NULL,
  `category_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_features_items`
--

CREATE TABLE `worcbox_features_items` (
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_features_items`
--

INSERT INTO `worcbox_features_items` (`title`, `description`, `id`, `type`, `sort_order`) VALUES
('جودة محتوى عالية', 'احصل على محتوى أصلي وضع بأسلوب وعناوين مثيرة للاهتمام تجعل القراء يتشوقون إلى معرفة المزيد عنك وعن شركتك.', 2, 'feature', 2),
('السرعة', 'سلم الطلب الان وسيعمل عليه فريقنا لتسليمه بسرعة البرق.', 3, 'feature', 3),
('التحرير مرارا بدون عدد محصور', 'نحن نحترم أنك تعرف عملاءك بشكل أفضل من أي شخص آخر، والتفاصيل الصغيرة التي تجعل نشاطك التجاري فريدًا. إذا كنت تشعر أن المحتوى الذي كتبناه يحتاج إلى تحرير جيد، فكل ما عليك هو إعلامنا وسنستمر في تحسينه حتى تصبح راضيًا.', 4, 'feature', 4),
('بالعمل معنا دون عقود او التزامات وحرية أكبر', 'مع عدم وجود التزامات تعاقدية تأتي حرية إنشاء محتوى من الدرجة الأولى عندما تريد، بالطريقة التي تريدها. لا توجد التزامات ولا تكاليف خفية مع الخدمات لدينا. نحن دائما هنا لنبهر جمهورك المستهدف عندما تحتاجنا.', 5, 'feature', 5),
('متوفرين للخدمة على مدار الساعة', 'نعمل على مدار الساعة وستجدنا عندما تحتاجنا دائما.', 6, 'feature', 6),
('كتاب محتوى مؤهلين', 'فريقنا محترف في فن التقاط الكلمات المكتوبة بشكل صحيح وتحويلها إلى زخرفة نصية ترتبط بالمستهلكين وتقنعهم بخدماتك.', 7, 'feature', 7),
('كتابة التدوينات', 'تتيح لك المدونات المكتوبة ببراعة التفاعل مع القراء في موضوعك. سواء كانت تحاورية أو تثقيفية أو تعليمية أو حتى مدفوعة بالمبيعات وترويجية، نعي المفهوم الذي تريد قوله ونساعدك في تقديمه\r\nعلى ماذا تحصل مع كل تدوين؟\r\n\r\nإدارة كاملة للمدونة: البحث والكتابة والصور والنشر-\r\nتدوينات مكتوبة من قبل خبراء متخصصين في كتابة التدوينات-\r\nالأسلوب المناسب والنغمة-\r\nالمحتوى الذي سيتواصل ويقنع جمهورك المستهدف-\r\nمحتوى صحيح نحويًا-\r\nمحتوى محسن بمحرك البحث باستخدام الكلمات الرئيسية المناسبة-\r\nتنسيق المحتوى السليم-\r\nالتسليم في وقت المحدد بأي شكل تحتاجه (.doc ، .pdf ، إلخ.)', 8, 'tab', 8),
('كتابة المقالات', 'لوريم إيبسوم(Lorem Ipsum) هو ببساطة نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر. كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر عندما قامت مطبعة مجهولة برص مجموعة من الأحرف بشكل عشوائي أخذتها من نص، لتكوّن كتيّب بمثابة دليل أو مرجع شكلي لهذه الأحرف. خمسة قرون من الزمن لم تقضي على هذا النص، بل انه حتى صار مستخدماً وبشكله الأصلي في الطباعة والتنضيد الإلكتروني. انتشر بشكل كبير في ستينيّات هذا القرن مع إصدار رقائق \"ليتراسيت\" (Letraset) البلاستيكية تحوي مقاطع من هذا النص، وعاد لينتشر مرة أخرى مؤخراَ مع ظهور برامج النشر الإلكتروني مثل \"ألدوس بايج مايكر\" (Aldus PageMaker) والتي حوت أيضاً على نسخ من نص لوريم إيبسوم.', 9, 'tab', 1),
('على الدجوى', 'محرر', 10, 'team', 10),
('شخص جديد', 'مراجع', 11, 'team', 11);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_packages_items`
--

CREATE TABLE `worcbox_packages_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `line_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_packages_items`
--

INSERT INTO `worcbox_packages_items` (`id`, `title`, `description`, `price`, `line_1`, `line_2`, `line_3`) VALUES
(1, 'باقة احترافية', 'هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام \"هنا يوجد محتوى نصي، هنا يوجد محتوى نصي\" فتجعلها تبدو (أي الأحرف) وكأنها نص مقروء. العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل إفتراضي كنموذج عن النص، وإذا قمت بإدخال \"lorem ipsum\" في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.', 550, 'عشرة تدوينات اسبوعية', 'اوصف منتجاتك بإحترافية', 'بدون عقود'),
(2, 'باقة الشركات', 'هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام \"هنا يوجد محتوى نصي، هنا يوجد محتوى نصي\" فتجعلها تبدو (أي الأحرف) وكأنها نص مقروء. العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل إفتراضي كنموذج عن النص، وإذا قمت بإدخال \"lorem ipsum\" في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.', 248, 'تدوينتين اسبوعيتين لموقعك', 'اوصف منتجاتك بإحترافية', 'ابرز الجمل الدعائية الجديدة'),
(3, 'باقة الرياديين', 'هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام \"هنا يوجد محتوى نصي، هنا يوجد محتوى نصي\" فتجعلها تبدو (أي الأحرف) وكأنها نص مقروء. العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل إفتراضي كنموذج عن النص، وإذا قمت بإدخال \"lorem ipsum\" في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.', 150, 'محتوى اخترافى لشركتك', 'اوصف منتجاتك بإحترافية', 'ابرز الجمل الدعائية الجديدة');

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_staticdata_lookups`
--

CREATE TABLE `worcbox_staticdata_lookups` (
  `id` int(11) NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `key` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_staticdata_lookups`
--

INSERT INTO `worcbox_staticdata_lookups` (`id`, `code`, `key`, `value`) VALUES
(2, 'contact.ksa.address', 'الرذايا، المملكة العربية السعودية', 'الرذايا، المملكة العربية السعودية'),
(3, 'contact.ksa.phone', '+9715422222', '+9715422222'),
(4, 'contact.ksa.fax', '+96655555', '+96655555'),
(5, 'contact.ksa.email', 'contact@siyaq.com', 'contact@siyaq.com'),
(6, 'contact.egypt.address', 'جامعة الدول العربية، الدقى، الجيزة', 'جامعة الدول العربية، الدقى، الجيزة'),
(7, 'contact.egypt.phone', '+20102456587', '+20102456587'),
(8, 'contact.egypt.fax', '+2025642155', '+2025642155'),
(9, 'contact.egypt.email', 'info@siyaq.com', 'info@siyaq.com'),
(10, 'footer.links.facebook', 'http://facebook.com', 'http://facebook.com'),
(11, 'footer.links.twitter', 'http://twitter.com', 'http://twitter.com'),
(12, 'footer.links.google', 'http://google.com', 'http://google.com'),
(13, 'footer.links.tumblr', 'https://www.tumblr.com/', 'https://www.tumblr.com/'),
(14, 'footer.about', 'عن سياق', 'سياق هو اول منصة عربية لتقديم خدمات انشاء المحتوى بشكل احترافى، سواءً تريد ان محتوى لمدونتك، لموقعك أو تفضل المقالات لأغراض التسويق');

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_syaq_audience_genders`
--

CREATE TABLE `worcbox_syaq_audience_genders` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_syaq_audience_genders`
--

INSERT INTO `worcbox_syaq_audience_genders` (`id`, `name`, `active`) VALUES
(1, 'ذكور', 1);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_syaq_fields`
--

CREATE TABLE `worcbox_syaq_fields` (
  `id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_syaq_fields`
--

INSERT INTO `worcbox_syaq_fields` (`id`, `name`, `active`) VALUES
(1, 'تكنولوجيا', 1);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_syaq_orders`
--

CREATE TABLE `worcbox_syaq_orders` (
  `id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `words_count` int(11) NOT NULL,
  `days_count` int(11) NOT NULL,
  `high_quality` tinyint(1) NOT NULL,
  `topic` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_id` int(11) NOT NULL,
  `audience_gender_id` int(11) DEFAULT NULL,
  `speech_format_id` int(11) DEFAULT NULL,
  `title_field_id` int(11) DEFAULT NULL,
  `typing_mode_id` int(11) DEFAULT NULL,
  `audience_identification` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewer_user_id` int(11) DEFAULT NULL,
  `implementer_user_id` int(11) DEFAULT NULL,
  `express` tinyint(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total` double NOT NULL DEFAULT '0',
  `test` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_syaq_orders`
--

INSERT INTO `worcbox_syaq_orders` (`id`, `service_id`, `quantity`, `words_count`, `days_count`, `high_quality`, `topic`, `field_id`, `audience_gender_id`, `speech_format_id`, `title_field_id`, `typing_mode_id`, `audience_identification`, `notes`, `created_at`, `updated_at`, `status`, `reviewer_user_id`, `implementer_user_id`, `express`, `user_id`, `total`, `test`) VALUES
(1, 2, 1, 200, 12, 0, 'dfgdfg', 1, 1, 2, 2, 1, 'dfg', 'dfgdfg', '2018-09-09 08:25:18', '2018-09-09 12:30:42', 'finished', NULL, NULL, 0, 5, 10, NULL),
(2, 2, 1, 200, 12, 0, 'موضوع', 1, 1, 2, 2, 2, 'هوية الجمهور المخاطب', 'بجانب نافذة لإضافة أي تعليقات او ملاحظات', '2018-09-09 08:51:39', '2018-09-09 16:38:14', 'archived', 3, NULL, 0, 1, 10, NULL),
(3, 2, 1, 200, 12, 0, 'موضوع', 1, 1, 2, 2, 1, 'هوية الجمهور المخاطب', 'بجانب نافذة لإضافة أي تعليقات او ملاحظات', '2018-09-09 08:58:38', '2018-09-09 12:22:53', 'finished', NULL, NULL, 0, 1, 10, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_syaq_order_attachments`
--

CREATE TABLE `worcbox_syaq_order_attachments` (
  `id` int(10) UNSIGNED NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `implementer_user_id` int(11) NOT NULL,
  `reviewer_user_id` int(11) DEFAULT NULL,
  `order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_syaq_order_attachments`
--

INSERT INTO `worcbox_syaq_order_attachments` (`id`, `note`, `created_at`, `updated_at`, `implementer_user_id`, `reviewer_user_id`, `order_id`) VALUES
(1, 'notes', '2018-09-09 12:02:38', '2018-09-09 12:03:27', 4, 3, 4),
(2, 'NOtes', '2018-09-09 12:20:28', '2018-09-09 12:21:33', 4, 3, 3),
(3, NULL, '2018-09-09 12:28:00', '2018-09-09 12:28:00', 4, NULL, 2),
(4, NULL, '2018-09-09 12:37:47', '2018-09-09 12:37:47', 4, NULL, 4),
(5, NULL, '2018-09-09 12:48:24', '2018-09-09 12:48:24', 4, NULL, 4);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_syaq_services`
--

CREATE TABLE `worcbox_syaq_services` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `minimum_words_count` int(10) UNSIGNED NOT NULL,
  `basic_cost` double NOT NULL,
  `basic_duration_in_days` int(10) UNSIGNED NOT NULL,
  `express_cost` double DEFAULT NULL,
  `express_duration_in_days` int(10) UNSIGNED DEFAULT NULL,
  `high_quality_cost` double DEFAULT NULL,
  `extra_block_words_count` int(10) UNSIGNED DEFAULT NULL,
  `extra_block_cost` double DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_syaq_services`
--

INSERT INTO `worcbox_syaq_services` (`id`, `name`, `description`, `minimum_words_count`, `basic_cost`, `basic_duration_in_days`, `express_cost`, `express_duration_in_days`, `high_quality_cost`, `extra_block_words_count`, `extra_block_cost`, `active`) VALUES
(1, 'وصف منتج', 'وصف وصف منتج', 300, 50, 21, 10, 10, 15, 10, 13, 1),
(2, 'مقال صحفى', 'وصف مقال صحفى', 200, 10, 12, 15, 5, 8, 25, 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_syaq_speech_formats`
--

CREATE TABLE `worcbox_syaq_speech_formats` (
  `id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_syaq_speech_formats`
--

INSERT INTO `worcbox_syaq_speech_formats` (`id`, `name`, `active`) VALUES
(1, 'عربية فصحى', 1),
(2, 'عامية', 1);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_syaq_title_fields`
--

CREATE TABLE `worcbox_syaq_title_fields` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_syaq_title_fields`
--

INSERT INTO `worcbox_syaq_title_fields` (`id`, `name`, `active`) VALUES
(1, 'عنوان نصى', 1),
(2, 'تعبئة جماهير', 1);

-- --------------------------------------------------------

--
-- Table structure for table `worcbox_syaq_typing_modes`
--

CREATE TABLE `worcbox_syaq_typing_modes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worcbox_syaq_typing_modes`
--

INSERT INTO `worcbox_syaq_typing_modes` (`id`, `name`, `active`) VALUES
(1, 'كتابة حرة', 1),
(2, 'عمودية', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `backend_access_log`
--
ALTER TABLE `backend_access_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `backend_users`
--
ALTER TABLE `backend_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login_unique` (`login`),
  ADD UNIQUE KEY `email_unique` (`email`),
  ADD KEY `act_code_index` (`activation_code`),
  ADD KEY `reset_code_index` (`reset_password_code`),
  ADD KEY `admin_role_index` (`role_id`);

--
-- Indexes for table `backend_users_groups`
--
ALTER TABLE `backend_users_groups`
  ADD PRIMARY KEY (`user_id`,`user_group_id`);

--
-- Indexes for table `backend_user_groups`
--
ALTER TABLE `backend_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name_unique` (`name`),
  ADD KEY `code_index` (`code`);

--
-- Indexes for table `backend_user_preferences`
--
ALTER TABLE `backend_user_preferences`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_item_index` (`user_id`,`namespace`,`group`,`item`);

--
-- Indexes for table `backend_user_roles`
--
ALTER TABLE `backend_user_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `role_unique` (`name`),
  ADD KEY `role_code_index` (`code`);

--
-- Indexes for table `backend_user_throttle`
--
ALTER TABLE `backend_user_throttle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `backend_user_throttle_user_id_index` (`user_id`),
  ADD KEY `backend_user_throttle_ip_address_index` (`ip_address`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD UNIQUE KEY `cache_key_unique` (`key`);

--
-- Indexes for table `cms_theme_data`
--
ALTER TABLE `cms_theme_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cms_theme_data_theme_index` (`theme`);

--
-- Indexes for table `cms_theme_logs`
--
ALTER TABLE `cms_theme_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cms_theme_logs_type_index` (`type`),
  ADD KEY `cms_theme_logs_theme_index` (`theme`),
  ADD KEY `cms_theme_logs_user_id_index` (`user_id`);

--
-- Indexes for table `deferred_bindings`
--
ALTER TABLE `deferred_bindings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deferred_bindings_master_type_index` (`master_type`),
  ADD KEY `deferred_bindings_master_field_index` (`master_field`),
  ADD KEY `deferred_bindings_slave_type_index` (`slave_type`),
  ADD KEY `deferred_bindings_slave_id_index` (`slave_id`),
  ADD KEY `deferred_bindings_session_key_index` (`session_key`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flynsarmy_sociallogin_user_providers`
--
ALTER TABLE `flynsarmy_sociallogin_user_providers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `provider_id_token_index` (`provider_id`,`provider_token`),
  ADD KEY `flynsarmy_sociallogin_user_providers_user_id_index` (`user_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_reserved_at_index` (`queue`,`reserved_at`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rainlab_user_mail_blockers`
--
ALTER TABLE `rainlab_user_mail_blockers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rainlab_user_mail_blockers_email_index` (`email`),
  ADD KEY `rainlab_user_mail_blockers_template_index` (`template`),
  ADD KEY `rainlab_user_mail_blockers_user_id_index` (`user_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `system_event_logs`
--
ALTER TABLE `system_event_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `system_event_logs_level_index` (`level`);

--
-- Indexes for table `system_files`
--
ALTER TABLE `system_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `system_files_field_index` (`field`),
  ADD KEY `system_files_attachment_id_index` (`attachment_id`),
  ADD KEY `system_files_attachment_type_index` (`attachment_type`);

--
-- Indexes for table `system_mail_layouts`
--
ALTER TABLE `system_mail_layouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_mail_partials`
--
ALTER TABLE `system_mail_partials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_mail_templates`
--
ALTER TABLE `system_mail_templates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `system_mail_templates_layout_id_index` (`layout_id`);

--
-- Indexes for table `system_parameters`
--
ALTER TABLE `system_parameters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_index` (`namespace`,`group`,`item`);

--
-- Indexes for table `system_plugin_history`
--
ALTER TABLE `system_plugin_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `system_plugin_history_code_index` (`code`),
  ADD KEY `system_plugin_history_type_index` (`type`);

--
-- Indexes for table `system_plugin_versions`
--
ALTER TABLE `system_plugin_versions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `system_plugin_versions_code_index` (`code`);

--
-- Indexes for table `system_request_logs`
--
ALTER TABLE `system_request_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_revisions`
--
ALTER TABLE `system_revisions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `system_revisions_revisionable_id_revisionable_type_index` (`revisionable_id`,`revisionable_type`),
  ADD KEY `system_revisions_user_id_index` (`user_id`),
  ADD KEY `system_revisions_field_index` (`field`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `system_settings_item_index` (`item`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_login_unique` (`username`),
  ADD KEY `users_activation_code_index` (`activation_code`),
  ADD KEY `users_reset_password_code_index` (`reset_password_code`),
  ADD KEY `users_login_index` (`username`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`user_id`,`user_group_id`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_groups_code_index` (`code`);

--
-- Indexes for table `user_throttle`
--
ALTER TABLE `user_throttle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_throttle_user_id_index` (`user_id`),
  ADD KEY `user_throttle_ip_address_index` (`ip_address`);

--
-- Indexes for table `vojtasvoboda_reviews_categories`
--
ALTER TABLE `vojtasvoboda_reviews_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vojtasvoboda_reviews_reviews`
--
ALTER TABLE `vojtasvoboda_reviews_reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vojtasvoboda_reviews_review_category`
--
ALTER TABLE `vojtasvoboda_reviews_review_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vojtasvoboda_reviews_review_category_review_id_category_id_index` (`review_id`,`category_id`),
  ADD KEY `vojtasvoboda_reviews_review_category_category_id_foreign` (`category_id`);

--
-- Indexes for table `worcbox_features_items`
--
ALTER TABLE `worcbox_features_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_packages_items`
--
ALTER TABLE `worcbox_packages_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_staticdata_lookups`
--
ALTER TABLE `worcbox_staticdata_lookups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_syaq_audience_genders`
--
ALTER TABLE `worcbox_syaq_audience_genders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_syaq_fields`
--
ALTER TABLE `worcbox_syaq_fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_syaq_orders`
--
ALTER TABLE `worcbox_syaq_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_syaq_order_attachments`
--
ALTER TABLE `worcbox_syaq_order_attachments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_syaq_services`
--
ALTER TABLE `worcbox_syaq_services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_syaq_speech_formats`
--
ALTER TABLE `worcbox_syaq_speech_formats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_syaq_title_fields`
--
ALTER TABLE `worcbox_syaq_title_fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worcbox_syaq_typing_modes`
--
ALTER TABLE `worcbox_syaq_typing_modes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `backend_access_log`
--
ALTER TABLE `backend_access_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `backend_users`
--
ALTER TABLE `backend_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `backend_user_groups`
--
ALTER TABLE `backend_user_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `backend_user_preferences`
--
ALTER TABLE `backend_user_preferences`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `backend_user_roles`
--
ALTER TABLE `backend_user_roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `backend_user_throttle`
--
ALTER TABLE `backend_user_throttle`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `cms_theme_data`
--
ALTER TABLE `cms_theme_data`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cms_theme_logs`
--
ALTER TABLE `cms_theme_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deferred_bindings`
--
ALTER TABLE `deferred_bindings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `flynsarmy_sociallogin_user_providers`
--
ALTER TABLE `flynsarmy_sociallogin_user_providers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `rainlab_user_mail_blockers`
--
ALTER TABLE `rainlab_user_mail_blockers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_event_logs`
--
ALTER TABLE `system_event_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_files`
--
ALTER TABLE `system_files`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `system_mail_layouts`
--
ALTER TABLE `system_mail_layouts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `system_mail_partials`
--
ALTER TABLE `system_mail_partials`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `system_mail_templates`
--
ALTER TABLE `system_mail_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `system_parameters`
--
ALTER TABLE `system_parameters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `system_plugin_history`
--
ALTER TABLE `system_plugin_history`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=367;

--
-- AUTO_INCREMENT for table `system_plugin_versions`
--
ALTER TABLE `system_plugin_versions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `system_request_logs`
--
ALTER TABLE `system_request_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_revisions`
--
ALTER TABLE `system_revisions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_throttle`
--
ALTER TABLE `user_throttle`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `vojtasvoboda_reviews_categories`
--
ALTER TABLE `vojtasvoboda_reviews_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vojtasvoboda_reviews_reviews`
--
ALTER TABLE `vojtasvoboda_reviews_reviews`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vojtasvoboda_reviews_review_category`
--
ALTER TABLE `vojtasvoboda_reviews_review_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `worcbox_features_items`
--
ALTER TABLE `worcbox_features_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `worcbox_packages_items`
--
ALTER TABLE `worcbox_packages_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `worcbox_staticdata_lookups`
--
ALTER TABLE `worcbox_staticdata_lookups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `worcbox_syaq_audience_genders`
--
ALTER TABLE `worcbox_syaq_audience_genders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `worcbox_syaq_fields`
--
ALTER TABLE `worcbox_syaq_fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `worcbox_syaq_orders`
--
ALTER TABLE `worcbox_syaq_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `worcbox_syaq_order_attachments`
--
ALTER TABLE `worcbox_syaq_order_attachments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `worcbox_syaq_services`
--
ALTER TABLE `worcbox_syaq_services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `worcbox_syaq_speech_formats`
--
ALTER TABLE `worcbox_syaq_speech_formats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `worcbox_syaq_title_fields`
--
ALTER TABLE `worcbox_syaq_title_fields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `worcbox_syaq_typing_modes`
--
ALTER TABLE `worcbox_syaq_typing_modes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `vojtasvoboda_reviews_review_category`
--
ALTER TABLE `vojtasvoboda_reviews_review_category`
  ADD CONSTRAINT `vojtasvoboda_reviews_review_category_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `vojtasvoboda_reviews_categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `vojtasvoboda_reviews_review_category_review_id_foreign` FOREIGN KEY (`review_id`) REFERENCES `vojtasvoboda_reviews_reviews` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
