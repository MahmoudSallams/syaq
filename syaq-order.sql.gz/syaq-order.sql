-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 13, 2018 at 01:41 PM
-- Server version: 5.7.24-0ubuntu0.16.04.1
-- PHP Version: 7.0.32-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `syaq-order`
--

-- --------------------------------------------------------

--
-- Table structure for table `followup`
--

CREATE TABLE `followup` (
  `followupid` int(11) NOT NULL,
  `Request` int(11) DEFAULT NULL,
  `FromUser` text,
  `DRequest` varchar(255) DEFAULT NULL,
  `DForward` datetime DEFAULT NULL,
  `DDone` text,
  `DChecking` datetime DEFAULT NULL,
  `DManager` datetime DEFAULT NULL,
  `DSent` datetime DEFAULT NULL,
  `DReview` datetime DEFAULT NULL,
  `Comment` text,
  `File` text,
  `ToUser` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `followup`
--

INSERT INTO `followup` (`followupid`, `Request`, `FromUser`, `DRequest`, `DForward`, `DDone`, `DChecking`, `DManager`, `DSent`, `DReview`, `Comment`, `File`, `ToUser`) VALUES
(9, 26, '1', NULL, '2018-06-25 20:47:53', NULL, NULL, NULL, NULL, NULL, 'الرجاء الاهتمام بالمحتوى', '', '5'),
(10, 32, '1', NULL, '2018-06-26 06:05:46', NULL, NULL, NULL, NULL, NULL, 'Hhj', '', '5'),
(11, 32, '1', NULL, '2018-06-26 06:05:56', NULL, NULL, NULL, NULL, NULL, NULL, '', '5'),
(12, 29, '1', NULL, '2018-06-26 07:46:21', NULL, NULL, NULL, NULL, NULL, 'testy ', '', '5'),
(13, 33, '1', NULL, '2018-06-26 07:52:14', NULL, NULL, NULL, NULL, NULL, 'asdfsadfasdf', '', '5'),
(14, 33, '1', NULL, '2018-06-26 07:52:14', NULL, NULL, NULL, NULL, NULL, 'asdfsadfasdf', '', '5'),
(15, 33, '1', NULL, '2018-06-26 07:54:15', NULL, NULL, NULL, NULL, NULL, 'dsfgsfgsdf', '', '5');

-- --------------------------------------------------------

--
-- Table structure for table `information`
--

CREATE TABLE `information` (
  `info_id` int(11) NOT NULL,
  `Text` varchar(255) DEFAULT NULL,
  `Type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `information`
--

INSERT INTO `information` (`info_id`, `Text`, `Type`) VALUES
(2, 'تكنولوجيا', 'mgal'),
(3, 'عربية فصحى', 'sega'),
(4, 'عامية', 'sega'),
(5, 'ذكور', 'gendar'),
(6, 'عنوان نصى', 'mgaltitle'),
(7, 'تعبئة جماهير', 'mgaltitle'),
(8, 'كتابة حرة', 'ktaba'),
(9, 'عمودية', 'ktaba');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `request_id` int(11) NOT NULL,
  `Topic` text,
  `Category` text,
  `Language` text,
  `Gendar` text,
  `Audience` text,
  `TitleCategory` text,
  `PreferedTyping` text,
  `Notes` text,
  `ServiceType` text,
  `Count` text,
  `Quantity` text,
  `Price` text,
  `DType` text,
  `QType` text,
  `User` int(11) DEFAULT NULL,
  `Date` varchar(255) DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL,
  `Closed` int(11) DEFAULT NULL,
  `File` varchar(255) DEFAULT NULL,
  `Session` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`request_id`, `Topic`, `Category`, `Language`, `Gendar`, `Audience`, `TitleCategory`, `PreferedTyping`, `Notes`, `ServiceType`, `Count`, `Quantity`, `Price`, `DType`, `QType`, `User`, `Date`, `IP`, `Status`, `Closed`, `File`, `Session`) VALUES
(26, 'test', '2', '3', '5', 'asdfsadf', '6', '8', 'asfdsafasdf', '3', '200', '1', '10', '0', '0', 4, '2018-06-25', '197.38.254.116', 0, NULL, NULL, '0'),
(29, 'olio', '2', '3', '5', NULL, '6', '8', NULL, '4', '310', '3', '264', '1', '1', 5, '2018-06-25', '196.140.7.231', 0, NULL, NULL, '0'),
(30, NULL, '2', '3', '5', NULL, '6', '8', NULL, NULL, NULL, NULL, NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, '82c8d4fb19dc196639c9aa9c69a9efc1'),
(31, 'hjj', '2', '3', '5', NULL, '6', '8', NULL, '3', '225', '2', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, '6588cb86e5dfdb0330ba33380b000ba5'),
(32, 'hh', '2', '3', '5', NULL, '6', '8', NULL, '3', '225', '1', '28', '0', '1', 5, '2018-06-26', '196.141.5.109', 0, NULL, NULL, '0'),
(33, 'test', '2', '3', '5', 'test', '6', '8', NULL, '3', '200', '1', '10', '0', '0', 4, '2018-06-26', '197.39.187.181', 0, NULL, NULL, '0'),
(34, 'kl;l', '2', '3', '5', 'oppo', '6', '8', NULL, '3', '250', '1', '53', '1', '1', 5, '2018-06-26', '41.235.164.73', 0, NULL, NULL, '0'),
(37, 'dfhdfgh', '2', '3', '5', 'dfhdf', '6', '8', NULL, '3', '275', '1', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, 'a6798763b4927aa583196911b4a9e63b'),
(39, 'dfgh', '2', '3', '5', 'sdfgdsfg', '6', '8', 'sdgsdfg', '3', '200', '1', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, 'c6bc5916b40a572909ef8865a0359f41'),
(40, 'l', '2', '3', '5', ';', '6', '8', NULL, '3', '200', '1', NULL, '0', '1', NULL, NULL, NULL, NULL, NULL, NULL, '07a05aa5247601cf138adfe129643e03'),
(42, 'kk', '2', '3', '5', 'll', '6', '8', NULL, '3', '200', '1', '33', '1', '1', 5, '2018-06-26', '41.235.164.73', 0, NULL, NULL, '0'),
(43, 'kk', '2', '3', '5', '\'', '6', '8', NULL, '3', '200', '4', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, '909aa3a3dd36f313aff74f6ef4d60bb7'),
(44, 'kik', '2', '3', '5', ',,m,m,', '6', '8', NULL, '3', '300', '1', NULL, '0', '0', NULL, NULL, NULL, NULL, NULL, NULL, 'a1676ff3c0a7b068b0316f80f3b4b5df');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `iservice` int(11) NOT NULL,
  `ServiceName` varchar(255) DEFAULT NULL,
  `DStandard` varchar(255) DEFAULT NULL,
  `DExpress` varchar(255) DEFAULT NULL,
  `QPremium` varchar(255) DEFAULT NULL,
  `Extra` varchar(255) DEFAULT NULL,
  `SDays` varchar(255) DEFAULT NULL,
  `QDays` varchar(255) DEFAULT NULL,
  `MinWords` varchar(255) DEFAULT NULL,
  `ExtraNumber` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`iservice`, `ServiceName`, `DStandard`, `DExpress`, `QPremium`, `Extra`, `SDays`, `QDays`, `MinWords`, `ExtraNumber`) VALUES
(3, 'مقال صحفى', '10', '15', '8', '10', '12', '5', '200', '25'),
(4, 'وصف منتج', '50', '10', '15', '13', '21', '10', '300', '10');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `iuser` int(11) NOT NULL,
  `Name` text,
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Session` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`iuser`, `Name`, `Email`, `Password`, `Session`) VALUES
(4, 'بيتر جابر', 'peter@nzamk.net', 'e10adc3949ba59abbe56e057f20f883e', '8ba32ef7bbcc13f4a053c3c063efc9ab'),
(5, 'sally', 'sally@worcbox.com', '25d55ad283aa400af464c76d713c07ad', 'd99fcbfc3335dca99689314d22295896'),
(6, 'اختبار تحويل', 'redirect@yahoo.com', 'e10adc3949ba59abbe56e057f20f883e', 'c6bc5916b40a572909ef8865a0359f41');

-- --------------------------------------------------------

--
-- Table structure for table `writers`
--

CREATE TABLE `writers` (
  `iwriter` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Username` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Privilage` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `writers`
--

INSERT INTO `writers` (`iwriter`, `Name`, `Username`, `Password`, `Privilage`) VALUES
(1, 'Administrator', 'admin', 'e10adc3949ba59abbe56e057f20f883e', '1'),
(5, 'Ahmed Writer', 'writer', 'e10adc3949ba59abbe56e057f20f883e', '2'),
(6, 'Mohamed Audit', 'mo', 'e10adc3949ba59abbe56e057f20f883e', '3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `followup`
--
ALTER TABLE `followup`
  ADD PRIMARY KEY (`followupid`);

--
-- Indexes for table `information`
--
ALTER TABLE `information`
  ADD PRIMARY KEY (`info_id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`iservice`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`iuser`);

--
-- Indexes for table `writers`
--
ALTER TABLE `writers`
  ADD PRIMARY KEY (`iwriter`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `followup`
--
ALTER TABLE `followup`
  MODIFY `followupid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `information`
--
ALTER TABLE `information`
  MODIFY `info_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `iservice` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `iuser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `writers`
--
ALTER TABLE `writers`
  MODIFY `iwriter` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
